import csv

import pandas as pd
import numpy as np
import os
import pickle
from sklearn.tree import DecisionTreeClassifier
from Experiment.Main_Experiment.main.muilt_label.FLML import FLML_result
from Experiment.Main_Experiment.main.muilt_label.casual.causal_Inference import causal_inference, causal_inference_PSM
from Experiment.Main_Experiment.main.muilt_label.casual.causal_Inference import getAncestors
from Experiment.Main_Experiment.utils.data import read_data as rd
from sklearn.metrics import recall_score, precision_score, f1_score, zero_one_loss, hamming_loss, accuracy_score
SOURCE_PATH = "D:\ECG\第一篇小论文实验\Experiment"
import matplotlib

matplotlib.rcParams['font.sans-serif'] = ['SimHei']     # 显示中文
# 为了坐标轴负号正常显示。matplotlib默认不支持中文，设置中文字体后，负号会显示异常。需要手动将坐标轴负号设为False才能正常显示负号。
matplotlib.rcParams['axes.unicode_minus'] = False
def turn_list_01_arr(label_dict, ln):
    """标签字典转换为01矩阵"""
    arr_res = np.zeros((len(label_dict), len(ln)))
    ln = list(ln)
    for i, one_res in enumerate(label_dict):
        for label in one_res.keys():
            index = ln.index(label)
            arr_res[i, index] = 1
    return arr_res

def turn_dict_01_arr(label_dict, ln):
    """标签字典转换为01矩阵"""
    arr_res = np.zeros((len(label_dict), len(ln)))
    ln = list(ln)
    for i, one_res in enumerate(label_dict):

        for label in one_res.keys():
            index = ln.index(label)
            arr_res[i, index] = 1

    return arr_res

def turn_list_01_arr2(label_dict, ln):
    """标签字典转换为01矩阵"""
    arr_res = np.zeros((len(label_dict), len(ln)))
    ln = list(ln)
    for i, one_res in enumerate(label_dict):
        for label in one_res:
            index = ln.index(label)
            arr_res[i, index] = 1
    return arr_res

def trun_01_label_list(arr, ln):
    res = []
    for i in range(arr.shape[0]):
        one_res = []
        for j in range(arr.shape[1]):
            if arr[i, j] == 1:
                one_res.append(ln[j])
        res.append(one_res)
    return res

def evaluate(reallY, predY):
    """计算模型的各个评价指标"""
    results = []
    n = reallY.shape[1]
    HL = hamming_loss(reallY, predY)
    OE = zero_one_loss(reallY, predY)
    acc = accuracy_score(reallY, predY)
    # for i in range(n):
    #     recall = recall_score(reallY[:, i], predY[:, i])
    #     precision = precision_score(reallY[:, i], predY[:, i])
    #     f_score = f1_score(reallY[:, i], predY[:, i])
    #     results.append([precision, recall, f_score, HL, OE, acc])
    recall = recall_score(reallY, predY, average='weighted')
    precision = precision_score(reallY, predY, average='weighted')
    f_score = f1_score(reallY, predY, average='weighted')
    results.append([precision, recall, f_score, HL, OE, acc])
    return results

def get_ES_and_AS(one_predict_Y, relations, K=2, theta=0.8):
    """
    获取anchor_set、candidate_set，
    :param relations: 标签依赖
    :param one_predict_Y: {标签名：概率值或者置信度}
    :param K: 选择前K个为补充标签
    :param theta: ES选择阈值
    :return:
    """
    anchor_set = []  # 锚点集
    candidate_set = []  # 候选集
    # anchor_set、CS根据阈值初步筛选
    for key, val in one_predict_Y.items():
        if val >= theta:
            anchor_set.append(key)  # 大于阈值将其加入锚点集
        else:
            candidate_set.append(key)  # 否则加入候选集？
    if not anchor_set and not candidate_set:
        return anchor_set, candidate_set

    # CS关联标签筛选
    relation_dict = {}
    for label in anchor_set:
        for key, val in relations[label].items():
            if key in anchor_set or key in candidate_set:  # 已经存在AS、CS的标签跳过
                continue
            if key in relation_dict.keys() and relation_dict[key] > val:  # 如果标签已经筛选过，那么更新相关值 val值越小，相关性越强
                relation_dict[key] = val
            else:
                relation_dict[key] = val

    # 排序，获取前K个标签作为补充
    clc = list(relation_dict.keys())
    clc.sort(key=lambda x: relation_dict[x])
    clc = clc[:K]
    candidate_set.extend(clc)  # 合并候选集和选出的标签
    # print("anchor_set:  ", anchor_set)
    # print("candidate_set:  ", candidate_set)
    return anchor_set, candidate_set

def correct_result(predict_Y, relations,really_label,ln, K=2,theta=0.8,threshold=0.5):
    """
    对预测标签进行修正
    :param alpha: 当全0改概率大于alpha时选择second_query，配合operation使用
    :param operation: default：False -- max_query 最大联合概率查询；True -- second_query
    :param K: 选择前K个为补充标签
    :param theta:anchor_set选择阈值
    :param predict_Y: [{标签名：概率值或者置信度}, {标签名：概率值或者置信度},....]
    :param relations:标签依赖性
    :param model:贝叶斯模型
    :return:
    """


    # 获取最终的修正结果
    correct_set = []
    Y_train = pd.read_csv("results/causal_graph/MECG/Y_train_MECG.csv")
    # 读取MECG数据因果图
    causal_graph = np.load("results\causal_graph\MECG\DAG.npy")

    # Y_train = pd.read_csv("results/causal_graph/MIT/Y_train_MIT.csv")
    # 读取MIT数据因果图
    # causal_graph = np.load("results\causal_graph\MIT\DAG.npy")

    # 读取公共祖先
    ancestors_dict = getAncestors(len(ln), causal_graph)


    for i, one_predict_Y in enumerate(predict_Y):
        print(f"=================================第{i}条样本开始===========================================")
        # 获取AS、candidate_set
        anchor_set, candidate_set = get_ES_and_AS(one_predict_Y, relations=relations,  K=K, theta=theta)

        print("锚点集：", anchor_set, "候选标签集：", candidate_set)
        if not anchor_set:  # 两个都为空
            correct_set.append([])
        elif not candidate_set:
            correct_set.append(anchor_set)
        else:
            # 因果效应估计
            # anchor_set = causal_inference(anchor_set, candidate_set, Y_train)
            anchor_set = causal_inference_PSM(anchor_set, candidate_set, Y_train, ancestors_dict, threshold)
            correct_set.append(anchor_set)

        print("第{}条样本的预测结果集：".format(i), correct_set[i])
        print("第{}条样本的真实标签集：".format(i), really_label[i])
        # print("============================================================================")

    return correct_set

def select_label(Y_pre,ln):
    labels_res = {}

    for i in range(len(ln)):
        labels_res[ln[i]] = Y_pre[:, i]
    res = []
    for i in range(Y_pre.shape[0]):
        one_res = {}
        for l in ln:
            if labels_res[l][i] >= 0.5:
                one_res[l] = labels_res[l][i]
        res.append(one_res)
    res_arr = turn_dict_01_arr(res, ln)
    return res, res_arr

def MLCL(X_train, Y_train, X_test, Y_test, Y_pre_5,Y_pre_7, ln, theta, threhold):
    """
    :param X_test: 测试集特征
    :param Y_test: 测试集标签
    :param Y_pre: 测试集预测的标签
    :param ln: 标签名称
    :return:
    """
    _, res_arr_5 = select_label(Y_pre_5, ln)
    res, res_arr_8 = select_label(Y_pre_7, ln)

    # 未进行因果关系的结果
    if Y_test.shape[0]>10000:
        cls = DecisionTreeClassifier()
        cls.fit(X_test, res_arr_5)
        y_new_test = cls.predict(X_train)
        init_result = evaluate(Y_train, y_new_test)
    else:
        init_result = evaluate(Y_test, res_arr_5)

    path1 = "results/without_casual_relation.csv"
    file = open(path1, 'a', newline='')
    with file as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(init_result[0])  # 这里的row是上一步读入数据代码的list
        csvfile.close()


    # 进行因果关系的结果
    really_label_list = trun_01_label_list(Y_test, ln)

    # MECG标签之间的关联
    label_relation = pickle.load(open(os.path.join(SOURCE_PATH,"Main_Experiment/main/muilt_label/casual/relate_ratation/MECG_statistical_data/label_relation.pkl"),'rb'))  # 病历与病历之间的关联关系

    # MIT标签之间的关联
    # label_relation = pickle.load(open(os.path.join(SOURCE_PATH, "Main_Experiment/main/muilt_label/casual/relate_ratation/MIT_statistical_data/label_relation.pkl"), 'rb'))  # 病历与病历之间的关联关系

    correct_label = correct_result(res, label_relation, really_label_list, ln=ln, K=2, theta=theta, threshold=threhold)

    correct_arr = turn_list_01_arr2(correct_label, ln)
    if correct_arr.shape[0] > 10000:
        cls = DecisionTreeClassifier()
        cls.fit(X_test, correct_arr)
        y_new_test2 = cls.predict(X_train)
        init_result2 = evaluate(Y_train, y_new_test2)
    else:
        init_result2 = evaluate(Y_test, correct_arr)
    path2 = "results/with_casual_relation.csv"
    file = open(path2, 'a', newline='')
    with file as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(init_result2[0])  # 这里的row是上一步读入数据代码的list
        csvfile.close()
    return correct_arr

def test_threhold():
    X_train, X_test, Y_train, Y_test, ln, Y_test_5, Y_test_10, Y_test_20, Y_test_30, Y_test_40 = rd.get_target_split_noise_data()
    noise_datas = [Y_test_5, Y_test_10, Y_test_20, Y_test_30, Y_test_40]
    noise_nums = ["5%", "10%", "20%", "30%", "40%"]
    threholds = [0.1,0.2,0.3,0.4,0.5,0.6,0.7]


    for i in range(len(noise_datas)):
        path2 = "results/with_casual_relation.csv"
        file = open(path2, 'a', newline='')
        with file as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(noise_nums[i])  # 这里的row是上一步读入数据代码的list
            csvfile.close()
        Y_test_predict5 = FLML_result(X_train, X_test, Y_train, Y_test, noise_datas[i], th=0.5)
        Y_test_predict75 = FLML_result(X_train, X_test, Y_train, Y_test, noise_datas[i], th=0.75)
        for threhold in threholds:
            print("#############################################{}噪声,threholds={}开始了##############################################".format(noise_nums[i],threhold))
            correct_arr = MLCL(X_train, Y_train, X_test, Y_test, Y_test_predict5, Y_test_predict75, ln, theta=0.75, threhold=threhold)  # ECG: theta = 0.8, MIT: theta = 0.7


if __name__ == '__main__':
    # X_train, X_test, Y_train, Y_test,ln = rd.get_target_split_data()  # 读取分割好的真实数据集

    #################################读取ECG模拟噪声数据集,后面的数字表示测试集噪声比例#################################
    # X_train, X_test, Y_train, Y_test, ln, Y_test_5, Y_test_10, Y_test_20, Y_test_30, Y_test_40 = rd.get_target_split_noise_data()
    #################################读取MIT拟噪声数据集,后面的数字表示测试集噪声比例#################################
    # X_train, X_test, Y_train, Y_test, ln, Y_test_5, Y_test_10, Y_test_20, Y_test_30, Y_test_40 = rd.get_MIT_noise_data()
    # noise_datas = [Y_test_5, Y_test_10, Y_test_20, Y_test_30, Y_test_40]
    # noise_nums = ["5%","10%","20%","30%","40%"]
    # thetas = [0.65,0.7,0.7,0.75,0.75]
    # for i in range(len(noise_datas)):
    #     print("#############################################{}噪声开始了##############################################".format(noise_nums[i]))
    #     path2 = "results/with_casual_relation.csv"
    #     file = open(path2, 'a', newline='')
    #     with file as csvfile:
    #         writer = csv.writer(csvfile)
    #         writer.writerow(noise_nums[i])  # 这里的row是上一步读入数据代码的list
    #         csvfile.close()
    #     Y_test_predict5 = FLML_result(X_train, X_test, Y_train, Y_test, noise_datas[i], th=0.5)
    #     Y_test_predict7 = FLML_result(X_train, X_test, Y_train, Y_test, noise_datas[i], th=thetas[i])
    #     correct_arr = MLCL(X_train, Y_train, X_test, Y_test, Y_test_predict5, Y_test_predict7, ln, theta=thetas[i], threhold=1.0)  # theta = 0.75, ECG:threhold=0.5,MIT:threhold=0.8



    #################################读取真实数据集(ed+wd)#################################
    X_train, Y_train, X_test, Y_test, ln = rd.get_all_scope_data()
    Y_test_predict5 = FLML_result(X_train, X_test, Y_train, Y_test,Y_test, th=0.5)
    Y_test_predict7 = FLML_result(X_train, X_test, Y_train, Y_test, Y_test, th=0.75)
    correct_arr = MLCL(X_train, Y_train, X_test, Y_test, Y_test_predict5, Y_test_predict7, ln, theta=0.75, threhold=0.5) # theta = 0.75



    # test_threhold()
