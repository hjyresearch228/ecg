import json
from itertools import combinations
from scipy.stats import norm
import numpy as np
import math
import networkx as nx
import pandas as pd
from typing import List, Optional
import matplotlib.pyplot as plt

def get_neighbors(G, x: int, y: int):
    return [i for i in range(len(G)) if G[x][i] == True and i != y]

def gauss_ci_test(suff_stat, x: int, y: int, K: List[int], cut_at: float = 0.9999999):
    """条件独立性检验"""
    C = suff_stat["C"]
    n = suff_stat["n"]

    # ------ 偏相关系数 ------
    if len(K) == 0:  # K 为空
        r = C[x, y]

    elif len(K) == 1:  # K 中只有一个点，即一阶偏相关系数
        k = K[0]
        r = (C[x, y] - C[x, k] * C[y, k]) / math.sqrt((1 - C[y, k] ** 2) * (1 - C[x, k] ** 2))

    else:  # 其实我没太明白这里是怎么求的，但 R 语言的 pcalg 包就是这样写的
        m = C[np.ix_([x] + [y] + K, [x] + [y] + K)]
        p = np.linalg.pinv(m)
        r = -p[0, 1] / math.sqrt(abs(p[0, 0] * p[1, 1]))

    r = min(cut_at, max(-cut_at, r))

    # Fisher's z-transform
    z = 0.5 * math.log1p((2 * r) / (1 - r))
    z_standard = z * math.sqrt(n - len(K) - 3)

    # Φ^{-1}(1-α/2)
    p_value = 2 * (1 - norm.cdf(abs(z_standard)))

    return p_value

def skeleton(suff_stat, alpha: float):
    n_nodes = suff_stat["C"].shape[0]

    # 分离集
    O = [[[] for _ in range(n_nodes)] for _ in range(n_nodes)]

    # 完全无向图
    G = [[i != j for i in range(n_nodes)] for j in range(n_nodes)]

    # 点对（不包括 i -- i）
    pairs = [(i, (n_nodes - j - 1)) for i in range(n_nodes) for j in range(n_nodes - i - 1)]

    done = False
    l = 0  # 节点数为 l 的子集

    while done != True and any(G):
        done = True

        # 遍历每个相邻点对
        for x, y in pairs:
            if G[x][y] == True:
                neighbors = get_neighbors(G, x, y)  # adj(C,x) \ {y}

                if len(neighbors) >= l:  # |adj(C, x) \ {y}| > l
                    done = False

                    # |adj(C, x) \ {y}| = l
                    for K in set(combinations(neighbors, l)):
                        # 节点 x, y 是否被节点数为 l 的子集 K d-seperation
                        # 条件独立性检验，返回 p-value
                        p_value = gauss_ci_test(suff_stat, x, y, list(K))

                        # 条件独立
                        if p_value >= alpha:
                            G[x][y] = G[y][x] = False  # 去掉边 x -- y
                            O[x][y] = O[y][x] = list(K)  # 把 K 加入分离集 O
                            break
        l += 1

    return np.asarray(G, dtype=int), O

def extend_cpdag(G, O):
    n_nodes = G.shape[0]

    def rule1(g):
        """Rule 1: 如果存在链 i -> j - k ，且 i, k 不相邻，则变为 i -> j -> k"""
        pairs = [(i, j) for i in range(n_nodes) for j in range(n_nodes) if g[i][j] == 1 and g[j][i] == 0]  # 所有 i - j 点对

        for i, j in pairs:
            all_k = [k for k in range(n_nodes) if (g[j][k] == 1 and g[k][j] == 1) and (g[i][k] == 0 and g[k][i] == 0)]

            if len(all_k) > 0:
                g[j][all_k] = 1
                g[all_k][j] = 0
        return g

    def rule2(g):
        """Rule 2: 如果存在链 i -> k -> j ，则把 i - j 变为 i -> j"""
        pairs = [(i, j) for i in range(n_nodes) for j in range(n_nodes) if g[i][j] == 1 and g[j][i] == 1]  # 所有 i - j 点对

        for i, j in pairs:
            all_k = [k for k in range(n_nodes) if (g[i][k] == 1 and g[k][i] == 0) and (g[k][j] == 1 and g[j][k] == 0)]

            if len(all_k) > 0:
                g[i][j] = 1
                g[j][1] = 0

        return g

    def rule3(g):
        """Rule 3: 如果存在 i - k1 -> j 和 i - k2 -> j ，且 k1, k2 不相邻，则把 i - j 变为 i -> j"""
        pairs = [(i, j) for i in range(n_nodes) for j in range(n_nodes) if g[i][j] == 1 and g[j][i] == 1]  # 所有 i - j 点对

        for i, j in pairs:
            all_k = [k for k in range(n_nodes) if (g[i][k] == 1 and g[k][i] == 1) and (g[k][j] == 1 and g[j][k] == 0)]

            if len(all_k) >= 2:
                for k1, k2 in combinations(all_k, 2):
                    if g[k1][k2] == 0 and g[k2][k1] == 0:
                        g[i][j] = 1
                        g[j][i] = 0
                        break
        return g

    # Rule 4: 如果仅仅存在链 i-j
    def rule4(g):
        """Rule 4:调用acid,验证离散变量的因果性"""
        from anm import anm, Entropy
        # file_path = 'results/causal_graph/MIT/Y_train_MIT.csv'
        file_path = 'results/causal_graph/MECG/Y_train_MECG.csv'

        data = pd.read_csv(file_path)
        data = np.array(data)
        pairs = [(i, j) for i in range(n_nodes) for j in range(n_nodes) if g[i][j] == 1 or g[j][i] == 1]  # 所有 i - j 点对

        for i, j in pairs:
            acid_score = anm(data[:,i], data[:,j], Entropy)
            if acid_score[0]>acid_score[1]:
                g[i][j]=1
                g[j][i]=0
            if acid_score[0]<acid_score[1]:
                g[i][j]=0
                g[j][i]=1
        return g
    # 相邻点对
    pairs = [(i, j) for i in range(n_nodes) for j in range(n_nodes) if G[i][j] == 1]

    # 把 x - y - z 变为 x -> y <- z
    for x, y in sorted(pairs, key=lambda x:(x[1], x[0])):
        all_z = [z for z in range(n_nodes) if G[y][z] == 1 and z != x]

        for z in all_z:
            if G[x][z] == 0 and y not in O[x][z]:
                G[x][y] = G[z][y] = 1
                G[y][x] = G[y][z] = 0

    # Orientation rule 1 - rule 3
    old_G = np.zeros((n_nodes, n_nodes))

    while not np.array_equal(old_G, G):
        old_G = G.copy()

        G = rule1(G)
        G = rule2(G)
        G = rule3(G)
        G = rule4(G)

    return np.array(G)

def pc(suff_stat, alpha: float = 0.05, verbose: bool = False):
    G, O = skeleton(suff_stat, alpha)  # 骨架
    cpdag = extend_cpdag(G, O)  # 扩展为 CPDAG
    return cpdag




def dfs(graph, k: int, chain: List[int], visit: List[bool]):
    """因果关系链深搜"""
    flag = False
    for i in range(len(graph)):
        if graph[i][k] == 1 and not visit[i]:
            flag = True
            visit[i] = True
            chain.append(i)

            dfs(graph, i, chain, visit)

            chain.pop()
            visit[i] = False

    if not flag:
        chains.append(chain.copy())


def get_causal_chains(graph, start: int, labels: List[str]):
    global chains
    chains = []

    visit = [False for _ in range(len(labels))]
    visit[start] = True

    chain = [start]

    dfs(graph, start, chain, visit)
    return "\n".join([" <- ".join(list(map(lambda x: labels[x] + f" ({x})", c))) for c in chains])

def plot(graph, labels: List[str], path: str = Optional[None]):
    """可视化学习出的因果网络"""
    G = nx.DiGraph()  # 创建空有向图

    for i in range(len(graph)):
        G.add_node(labels[i])
        for j in range(len(graph[i])):
            if graph[i][j] == 1:
                G.add_edge(labels[i], labels[j])

    nx.draw(G, with_labels=True)

    if path:
        plt.savefig(path)

    plt.show()



def npy_to_csv():
    """
    npy文件转csv文件
    :return:
    """
    from Experiment.Main_Experiment.utils.data import read_data as rd
    Xs, Ys, Xt, Yt, ln = rd.get_all_scope_data()
    # data = np.vstack((Y_train, Y_test))

    _,data,_ = rd.get_all_MIT_data()

    df = pd.DataFrame(data=data, columns=["A", "B", "C", "D", "E", "F","G","H"])
    df.to_csv("D:\ECG\第一篇小论文实验\Experiment\Main_Experiment\main\muilt_label\casual\Y_train_MIT.csv")

if __name__ == '__main__':
    # MIT数据集
    # file_path = 'results/causal_graph/MIT/Y_train_MIT.csv'
    # image_path = 'D:\ECG\第一篇小论文实验\Experiment\Main_Experiment\main\muilt_label\casual\\results\causal_graph\MIT\\因果关系图.png'
    # edgs_path = 'D:\ECG\第一篇小论文实验\Experiment\Main_Experiment\main\muilt_label\casual\\results\causal_graph\MIT\\DAG.npy'

    # MECG数据集
    file_path = 'results/causal_graph/MECG/Y_train_MECG.csv'
    image_path = 'D:\ECG\第一篇小论文实验\Experiment\Main_Experiment\main\muilt_label\casual\\results\causal_graph\MECG\\因果关系图.png'
    edgs_path = 'D:\ECG\第一篇小论文实验\Experiment\Main_Experiment\main\muilt_label\casual\\results\causal_graph\MECG\\DAG.npy'

    data = pd.read_csv(file_path)
    n_nodes = data.shape[1]
    labels = data.columns.to_list()

    graph = pc(suff_stat={"C": data.corr().values,  "n": data.shape[0]}, verbose=True)

    # DFS 因果关系链
    # DAG = get_causal_chains(p, start=2, labels=labels)
    print(graph)
    np.save(edgs_path, graph)

    # 画图
    plot(graph, labels, image_path)

    # 将npy文件转换为csv文件
    # npy_to_csv()