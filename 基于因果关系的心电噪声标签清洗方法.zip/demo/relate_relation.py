#!/usr/bin/python3
# -*- coding: UTF-8 -*-
import json
import os
import numpy as np
import pandas as pd
import pickle
from scipy.stats import chi2_contingency

from Experiment.Main_Experiment.main.muilt_label.bayesi.util import IO
from Experiment.Main_Experiment.utils.data import read_data as rd
# Y_train, Y_test, ln = rd.get_label_data()  # MECG:Ys:(6200,16)
X_train, Y_train, ln = rd.get_all_MIT_data()  # MIT:Ys:(3302,6)
SOURCE_PATH = "D:\ECG\第一篇小论文实验\Experiment\Main_Experiment\main\muilt_label\casual\\relate_ratation"

#!/usr/bin/python3
# -*- coding: UTF-8 -*-
import os
import numpy as np
import pandas as pd
import json
from Experiment.Main_Experiment.utils.data import read_data as rd
import Experiment.Main_Experiment.utils.IO


def label_cross_count():
    """统计标签之间的交叉个数"""
    label_name = ln
    print(label_name, len(label_name))
    label_data = Y_train
    # label_data_60000 = Xt
    n = len(label_name)
    num_arr = {}
    for i in range(n):
        for j in range(n):
            if i == j:
                continue
            res = {}
            # 1----1
            arr = label_data[label_data[:, i] == 1]
            tmp = arr[arr[:, j] == 1]
            res["11"] = tmp.shape[0]
            # 1 --- 0
            tmp = arr[arr[:, j] == 0]
            res["10"] = tmp.shape[0]

            # 0----1
            arr = label_data[label_data[:, i] == 0]
            tmp = arr[arr[:, j] == 1]
            res["01"] = tmp.shape[0]
            # 0 --- 0
            tmp = arr[arr[:, j] == 0]
            res["00"] = tmp.shape[0]

            num_arr[label_name[i] + "--" + label_name[j]] = res
    num_arr["total"] = label_data.shape[0]
    # print(num_arr)
    cp = pd.DataFrame(data=num_arr)
    cp = cp.T
    print(cp)

    cp.to_excel(os.path.join(SOURCE_PATH, "MIT_statistical_data", "label_cross_count.xlsx"))
    jsonObj = json.dumps(num_arr, ensure_ascii=False)
    # print(jsonObj)
    with open(os.path.join(SOURCE_PATH, "MIT_statistical_data", "label_cross_count.json"), "w") as file:
        file.write(jsonObj)


def calculate_chi_p():
    """计算标签之间的相关性和p值"""
    cf = pd.read_excel(os.path.join(SOURCE_PATH, "MIT_statistical_data/label_cross_count.xlsx"), index_col=0)
    print(cf)
    label_relation = {}
    for l1 in ln:
        one_label_relation = {}
        for l2 in ln:
            if l1 == l2:
                continue
            key = l1 + "--" + l2
            table = [[cf.loc[key, "00"], cf.loc[key, "01"]], [cf.loc[key, "10"], cf.loc[key, "11"]]]
            # print(table)
            chi, p, df, expx = chi2_contingency(table, lambda_="log-likelihood")
            # print("chi=" + str(chi)+"  ", "p=" + str(p))
            if p < 0.05:
                one_label_relation[l2] = p  # p越大独立性越高，反之越小相关性越强
        label_relation[l1] = one_label_relation
        # print(len((one_label_relation)))
    print(label_relation)
    pickle.dump(label_relation, open(os.path.join(SOURCE_PATH, "MIT_statistical_data/label_relation.pkl"), "wb"))


if __name__ == "__main__":

    label_cross_count()
    calculate_chi_p()
    pass
