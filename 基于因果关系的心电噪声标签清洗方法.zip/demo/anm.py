#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""This module implements the paper titled `Accurate Causal Inference on
Discrete Data`. We can also compute the total information content in the
sample by encoding the function and using the stochastic complexity on top of
regression model. For more detail, please refer to the manuscript at
http://people.mpi-inf.mpg.de/~kbudhath/manuscript/acid.pdf
"""
from collections import Counter
from math import log
import sys
import abc
from enum import Enum
from collections import defaultdict

import pandas as pd

def entropy(X):
    """Compute the entropy of a message.

    Args:
        X (sequence): a sequence of discrete outcomes

    Returns:
        (float): the entropy of X
    """
    res = 0
    n = len(X)
    counts = Counter(X).values()
    for count in counts:
        res -= (count / n) * (log(count, 2) - log(n, 2))
    return res


class ScoreType(Enum):
    PVAL = 1,
    INFO = 2

class DMType(Enum):
    NHST = 1  # Null Hypothesis Significance Testing
    INFO = 2  # Information-theoretic

class DependenceMeasure(abc.ABC):

    @property
    @abc.abstractmethod
    def type(self):
        pass

    @staticmethod
    @abc.abstractmethod
    def measure(seq1, seq2=None):
        pass

class Entropy(DependenceMeasure):
    type = DMType.INFO

    def measure(seq1, seq2=None):
        return entropy(seq1)


def choose(n, k):
    """Computes the binomial coefficient `n choose k`.
    """
    if 0 <= k <= n:
        ntok = 1
        ktok = 1
        for t in range(1, min(k, n - k) + 1):
            ntok *= n
            ktok *= t
            n -= 1
        return ntok // ktok
    else:
        return 0

def stratify(X, Y):
    """Stratifies Y based on unique values of X.

    Args:
        X (sequence): sequence of discrete outcomes
        Y (sequence): sequence of discrete outcomes

    Returns:
        (dict): list of Y-values for a X-value
    """
    Y_grps = defaultdict(list)
    for i, x in enumerate(X):
        Y_grps[x].append(Y[i])
    return Y_grps

def univ_enc(n):
    """Computes the universal code length of the given integer.
    Reference: J. Rissanen. A Universal Prior for Integers and Estimation by
    Minimum Description Length. Annals of Statistics 11(2) pp.416-431, 1983.
    """
    ucl = log(2.86504, 2)
    previous = n
    while True:
        previous = log(previous, 2)
        if previous < 1.0:
            break
        ucl += previous
    return ucl


def encode_func(f):
    """Encodes the function by enumerating the set of all possible functions.

    Args:
        ndom (int): number of elements in the domain of the function
        nimg (int): number of elements in the image of the function

    Returns:
        (float): encoded size of the function
    """
    # nones = len(set(f.values()))
    # return univ_enc(nones) + log(choose(ndom * nimg, nones), 2)
    ndom = len(f.keys())
    nimg = len(set(f.values()))
    return univ_enc(ndom) + univ_enc(nimg) + log(ndom ** nimg, 2)


def map_to_majority(X, Y):
    """Creates a function that maps y to the frequently co-occuring x.

    Args:
        X (sequence): sequence of discrete outcomes
        Y (sequence): sequence of discrete outcomes

    Returns:
        (dict): map from Y-values to frequently co-occuring X-values
    """
    f = dict()
    Y_grps = stratify(X, Y)
    for x, Ys in Y_grps.items():
        frequent_y, _ = Counter(Ys).most_common(1)[0]
        f[x] = frequent_y
    return f


def regress(X, Y, dep_measure, max_niterations, enc_func=False):
    """Performs discrete regression with Y as a dependent variable and X as
    an independent variable.

    Args:
        X (sequence): sequence of discrete outcomes
        Y (sequence): sequence of discrete outcomes
        dep_measure (DependenceMeasure): subclass of DependenceMeasure
        max_niterations (int): maximum number of iterations
        enc_func (bool): whether to encode the function or not

    Returns:
        (float): p-value (or information content) after fitting ANM from X->Y
    """
    # todo: make it work with chi-squared test of independence or G^2 test
    supp_X = list(set(X))
    supp_Y = list(set(Y))
    f = map_to_majority(X, Y)

    pair = list(zip(X, Y))
    res = [y - f[x] for x, y in pair]
    cur_res_inf = dep_measure.measure(res, X)

    j = 0
    minimized = True
    while j < max_niterations and minimized:
        minimized = False

        for x_to_map in supp_X:
            best_res_inf = sys.float_info.max
            best_y = None

            for cand_y in supp_Y:
                if cand_y == f[x_to_map]:
                    continue

                res = [y - f[x] if x != x_to_map else y -
                       cand_y for x, y in pair]
                res_inf = dep_measure.measure(res, X)

                if res_inf < best_res_inf:
                    best_res_inf = res_inf
                    best_y = cand_y

            if best_res_inf < cur_res_inf:
                cur_res_inf = best_res_inf
                f[x_to_map] = best_y
                minimized = True
        j += 1

    if dep_measure.type == DMType.INFO and not enc_func:
        return dep_measure.measure(X) + cur_res_inf
    elif dep_measure.type == DMType.INFO and enc_func:
        return dep_measure.measure(X) + encode_func(f) + cur_res_inf
    else:
        _, p_value = dep_measure.nhst([y - f[x] for x, y in pair], X)
        return p_value


def anm(X, Y, dep_measure, max_niterations=1000, enc_func=False):
    """Fits the Additive Noise Model from X to Y and vice versa.

    Args:
        X (sequence): sequence of discrete outcomes
        Y (sequence): sequence of discrete outcomes
        dep_measure (DependenceMeasure): subclass of DependenceMeasure
        max_niterations (int): maximum number of iterations
        enc_func (bool): whether to encode the function or not

    Returns:
        (float, float): p-value (or information content) after fitting ANM
        from X->Y and vice versa.
    """
    assert issubclass(dep_measure, DependenceMeasure), "dependence measure "\
        "must be a subclass of DependenceMeasure abstract class"
    xtoy = regress(X, Y, dep_measure, max_niterations, enc_func)
    ytox = regress(Y, X, dep_measure, max_niterations, enc_func)
    return (xtoy, ytox)

def pprint(method_name, score, score_type, llabel, rlabel):
    level = 0.05
    arrow = "~"
    if score_type == ScoreType.INFO:
        if score[0] < score[1]:
            arrow = "⇒"
        elif score[0] > score[1]:
            arrow = "⇐"
        conf = abs(score[0] - score[1])
        out_str = "%s:: %s %s %s\t Δ=%.2f" % (method_name,
                                              llabel, arrow, rlabel, conf)
    elif score_type == ScoreType.PVAL:
        if score[0] > level and score[1] < level:
            arrow = "⇒"
        elif score[0] < level and score[1] > level:
            arrow = "⇐"
        out_str = "%s:: %s %s %s" % (method_name, llabel, arrow, rlabel)
    print(out_str)


if __name__ == "__main__":
    import numpy as np
    data = pd.read_csv("D:\ECG\第一篇小论文实验\Experiment\Main_Experiment\main\muilt_label\casual\Y_train.csv")
    data = np.array(data)

    for i in range(16):
        X = data[:, i]
        for j in range(16):
            Y = data[:,j]

            acid_score = anm(X, Y, Entropy)
            pprint(" acid", acid_score, ScoreType.INFO, "abdomen", "surgical")

