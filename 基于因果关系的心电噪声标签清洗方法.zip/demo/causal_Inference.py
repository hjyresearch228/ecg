from collections import deque

from dowhy import CausalModel
import dowhy.plotter
import dowhy.datasets
import pandas as pd
import numpy as np
import psmatching.match as psm
import pytest
from psmatching.utilities import *
import statsmodels.api as sm
from cdt import SETTINGS


SETTINGS.verbose=True
#SETTINGS.NJOBS=16
#SETTINGS.GPU=1
import networkx as nx
import matplotlib.pyplot as plt
plt.axis('off')

from Experiment.Main_Experiment.utils.data import read_data as rd
from IPython.display import Image, display

# print(ln)
# ['左前分支阻滞' '左后分支阻滞' '前间壁心肌梗死' '窦性心动过缓' '不完全性右束支阻滞' '交界性期前收缩' '右心房肥大'
#  '前壁心肌梗死' '左心室肥厚' '下壁心肌梗死' '窦性心动过速' '心房颤动' 'I度房室传导阻滞' '完全性右束支阻滞' '窦性心律不齐'
#  '完全性左束支阻滞'] 分别对应下面
#  ['A' 'B' 'C' 'D' 'E' 'F' 'G' 'H' 'I' 'J' 'K' 'L' 'M' 'N' 'O' 'P']
change1 = {'左前分支阻滞':'A','左后分支阻滞': 'B', '前间壁心肌梗死': 'C', '窦性心动过缓':'D', '不完全性右束支阻滞':'E', '交界性期前收缩':'F', '右心房肥大':'G',
 '前壁心肌梗死':'H', '左心室肥厚':'I', '下壁心肌梗死':'J', '窦性心动过速': 'K', '心房颤动':'L', 'I度房室传导阻滞':'M', '完全性右束支阻滞':'N', '窦性心律不齐':'O',
 '完全性左束支阻滞':'P'}

change3 = {'Fusion of ventricular and normal beat':'A', 'Atrial premature contraction':'B', 'Left bundle branch block beat':'C',  'Aberrated atrial premature beat':'D',
 'Premature ventricular contraction':'E',  'Normal beat':'F', 'Right bundle branch block beat':'G',  'Nodal (junctional) escape beat':'H'}

def causal_inference(anchor_set, candidate_set,Y_train):
    """
    这里是调库实现的算法。
    :param anchor_set: 锚点集
    :param candidate_set: 候选集
    :param Y_train: 真实数据集
    :return:
    """
    causal_graph1 = """digraph {
    A->B;A->E;A-> I;A-> J;A->K;A->L;A->N;A->P
    B-> C;B-> D;B-> E;B->I;B->J;B->K;B->L;B->N;
    C-> E;C-> H;C-> K;C-> N;C-> P;
    D->G;D->H;D->J;D->K;D->L;D->O;
    E-> G;E-> H;E-> I;E-> J; E-> K;E-> L;E-> N;E-> P;
    F-> M;
    G-> J; 
    H-> N;H-> I;H-> P;
    I-> N;I-> K;
    J-> K;J ->M;J->N;J->P;
    K->L;K->M;K->N;K->O;
    L-> M;L-> N;L->O;L->P;
    M;
    N->0;
    O;
    P->N;
    }"""

    # 陈伟师兄数据集因果图
    causal_graph2 = """digraph {
        A->B;A-> C;A-> D;A->E;A->F;A->G;A->H;A->I;A-> J;A-> K;A->L;A->M;A->N;A->O;A->P;
        B->E;B->F;B->G;B->H;B->I;B->J;B->K;B->M;B->N;B->O;B->P;
        C->E;C->I;C->J;
        D->B;D->E;D->F;D->H;D->I;D->J;D->K;D->M;D->N;D->O;D->P;
        E-> H;E-> I;E-> J;E->L;E-> M;E-> N;E-> O;E->P;
        F-> G;F-> H;F->I;F-> J;F-> K;F->M;F-> O;F-> P;
        G-> H; G-> J; G-> K; G-> O; G-> P; 
        H->I;H->J;H->O;
        I-> J;I-> K;I-> N;I-> O;I-> P;
        J->K;J->O;
        K-> M;K->N;K-> O;K->P;
        L-> I;
        M-> N;M->O;
        N->P;
        O->P;
        P;
        }"""

    # MIT数据集因果图
    causal_graph3 = """digraph {
        A->E;A->F;
        B->E;B->C;B->G;B->H;
        C->F;C->G;
        D->E;D->F;
        E->G;E->H;
        F->E;F->G;
        G;
        H;
        }"""


    res = anchor_set
    # for reson in anchor_set:
    #     reson_change = change.get(reson)
    #     for outcome in candidate_set:
    #         outcome_change = change.get(outcome)


    # MIT数据集映射
    for reson in anchor_set:
        reson_change = change3.get(reson)
        for outcome in candidate_set:
            outcome_change = change3.get(outcome)
            # 创建因果模型
            model = dowhy.CausalModel(data=Y_train,
                                      treatment=reson_change,  # 因
                                      outcome=outcome_change,  # 果
                                      # common_causes=['A'],  # 会同时对因和结果产生影响的变量，混杂因子。
                                      # instruments=['A']  # 这些是不会直接影响结果，但是会影响原因。
                                      graph=causal_graph1.replace("\n", " ")
                                      )

            ################################################二、识别因果效应##############################################
            identified_estimand = model.identify_effect(proceed_when_unidentifiable=True)

            ################################################三、因果效应估计##############################################
            # 基于估计量，下面我们就可以根据实际数据进行因果效应的估计了。如之前所述，因果效应即干预进行单位改变时结果的变化程度。
            # 这里我们选择估计平均干预效应（ATE），也可以选择估计干预组（ATT）或对照组（ATC）的因果效应。估计方法选择的是「倾向得分匹配」
            try:
                estimate = model.estimate_effect(identified_estimand,  method_name="backdoor.propensity_score_stratification",  target_units="ate")
            except:
                estimate = model.estimate_effect(identified_estimand,
                                                 method_name="backdoor.linear_regression",
                                                 target_units="ate")

            print("Causal Estimate is " + str(estimate.value))


            ################################################四、反驳  本实验中不需要反驳####################################
            # 实际上，上述因果并不是基于数据，而是基于我们所做的假设（即提供的因果图），数据只是用于进行统计学的估计。因此，我们需要验证假设的正确性。
            # DoWhy 支持通过各种各样的鲁棒性检查方法来测试假设的正确性。下面进行其中几项测试

            # 1.「添加随机混杂因子」。如果假设正确，则添加随机的混杂因子后，因果效应不会变化太多。
            # if(estimate.value!=None and estimate.value>0.5):
            #     res.append(outcome)
            # refute1_results = model.refute_estimate(identified_estimand, estimate, method_name="random_common_cause")
            # print(refute1_results) # New effect:-0.02499783031140777 基本保持稳定

            # 2.「安慰剂干预」。将干预替换为随机变量，如果假设正确，因果效应应该接近 0。
            # refute2_results=model.refute_estimate(identified_estimand, estimate, method_name="placebo_treatment_refuter")
            # print(refute2_results)

            # 3.「数据子集验证」。在数据子集上估计因果效应，如果假设正确，因果效应应该变化不大。
            # refute3_results=model.refute_estimate(identified_estimand, estimate, method_name="data_subset_refuter")
            # print(refute3_results) # New effect:-0.027575533477689117

            if(estimate.value!=None and estimate.value>0.5):
                res.append(outcome)

    return res


def getAncestors(n, edges):
    """
    获得所有标签两两之间的祖先
    :param n: 标签数
    :param edges: 边，这里直接读取算法生成的因果图
    :return:
    """
    anc = [set() for _ in range(n)]  # 存储每个节点祖先的辅助数组
    e = [[] for _ in range(n)]  # 邻接表
    indeg = [0] * n  # 入度表
    # 预处理
    for u in range(edges.shape[0]):
        for v in range(edges.shape[1]):
            if(edges[u,v]==1):
                e[u].append(v)
                indeg[v] += 1
    # 广度优先搜索求解拓扑排序
    q = deque()
    for i in range(n):
        if indeg[i] == 0:
            q.append(i)
    while q:
        u = q.popleft()
        for v in e[u]:
            # 更新子节点的祖先哈希表
            anc[v].add(u)
            anc[v].update(anc[u])
            indeg[v] -= 1
            if indeg[v] == 0:
                q.append(v)
    # 转化为答案数组
    res = [sorted(anc[i]) for i in range(n)]
    ancestors_dict = {}
    # 求出两点的所用公共祖先
    for i in range(len(res)):
        if res[i] is None:
            continue
        for j in range(len(res)):
            if i!=j:
                tem_set = set(res[i]) & set(res[j])  # 获得公共祖先
                tem = chr(i+65)+'->'+chr(j+65)  # 转换为大写字母
                if tem_set == set():
                    ancestors_dict[tem] = " "  # 如果没有公共祖先，加入空字符创
                else:
                    tem_list = [chr(i + 65) for i in tem_set]
                    str = ' + '.join(tem_list)  # 公共祖先用加号连接，便于psm算法
                    ancestors_dict[tem] = chr(i+65)+' ~ ' + str  # 转化成"干预+混淆变量+混淆变量"
    return ancestors_dict


def causal_inference_PSM(anchor_set, candidate_set, Y_train, ancestors_dict, threshold):
    """
    不调库，计算清洗后的标签
    :param anchor_set: 瞄标签
    :param candidate_set: 候选标签
    :param Y_train: 数据
    :param ancestors_dict:混杂变量
    :param seta: 阈值
    :return: 清洗后的标签
    """

    res = anchor_set
    for i in range(len(anchor_set)):
        reson_change = change1.get(anchor_set[i])  # ecg数据用change1,mit用change3
        # reson_change = change3.get(anchor_set[i])  # ecg数据用change1,mit用change3
        for j in range(len(candidate_set)):
            if anchor_set[i] == candidate_set[j]:
                continue
            outcome_change = change1.get(candidate_set[j])
            # outcome_change = change3.get(candidate_set[j])

            tem = reson_change+'->'+outcome_change
            Confounding_Variable = ancestors_dict[tem]
            print("原因："+anchor_set[i]+" 结果："+candidate_set[j]+"  的混杂变量有："+Confounding_Variable)
            if Confounding_Variable == " ":
                continue
            else:
                ATT = PSM(reson_change, Confounding_Variable, Y_train, outcome_change)
                if ATT > threshold:
                    res.append(candidate_set[j])
                    break
    print(list(set(res)))
    return list(set(res))



def PSM(treatment, Confounding_Variable, Y_train, outcome):
    Y = Y_train[outcome]

    # 想要几个匹配项，如k=3，那一个push=1的用户就会匹配三个push=0的近似用户
    k = "1"

    ####获得倾向性匹配得分
    # print("\n计算倾向性匹配得分 ...", end=" ")
    # 利用逻辑回归框架计算倾向得分，即广义线性估计 + 二项式Binomial
    glm_binom = sm.formula.glm(formula=Confounding_Variable, data=Y_train, family=sm.families.Binomial())
    # 拟合拟合给定family的广义线性模型
    # https://www.w3cschool.cn/doc_statsmodels/statsmodels-generated-statsmodels-genmod-generalized_linear_model-glm-fit.html?lang=en
    result = glm_binom.fit()
    # 输出回归分析的摘要
    # print(result.summary)
    propensity_scores = result.fittedvalues
    # print("\n计算完成!")
    # 将倾向性匹配得分写入data
    Y_train["PROPENSITY"] = propensity_scores

    # 将PUSH替换成自己的干预项。groups是干预项，propensity是倾向性匹配得分，这里要分开干预与非干预，且确保n1<n2。
    groups = Y_train[treatment]

    propensity = Y_train.PROPENSITY
    # 把干预项替换成True和False
    groups == groups.unique()[1]
    n = len(groups)
    # 计算True和False的数量
    n1 = groups[groups == 1].sum()
    n2 = n - n1
    g1, g0 = propensity[groups == 1], propensity[groups == 0]

    # 确保n2>n1，,少的匹配多的，否则交换下
    # if n1 > n2:
    #     n1, n2, g1, g2 = n2, n1, g0, g1

    # 随机排序干预组，减少原始排序的影响
    # m_order = list(np.random.permutation(groups[groups == 1].index))
    m_order = groups[groups == 1].index

    ##### 根据倾向评分差异将干预组与对照组进行匹配 注意：caliper = None可以替换成自己想要的精度

    matches = {}
    k = int(k)
    # print("\n给每个干预组匹配 [" + str(k) + "] 个对照组 ... ", end=" ")
    for m in m_order:
        # 计算所有倾向得分差异,这里用了最粗暴的绝对值
        # 将propensity[groups==1]分别拿出来，每一个都与所有的propensity[groups==0]相减
        dist = abs(g1[m] - g0)
        array = np.array(dist)
        # 如果无放回地匹配，最后会出现要选取3个匹配对象，但是只有一个候选对照组的错误，故进行判断
        if k < len(array):
            # 在array里面选择K个最小的数字，并转换成列表
            k_smallest = np.partition(array, k)[:k].tolist()
            # 用卡尺做判断
            caliper = None
            if caliper:
                caliper = float(caliper)
                # 判断k_smallest是否在定义的卡尺范围
                keep_diffs = [i for i in k_smallest if i <= caliper]
                keep_ids = np.array(dist[dist.isin(keep_diffs)].index)
            else:
                # 如果不用标尺判断，那就直接上k_smallest了
                keep_ids = np.array(dist[dist.isin(k_smallest)].index)
            #  如果keep_ids比要匹配的数量多，那随机选择下，如要少，通过补NA配平数量
            if len(keep_ids) > k:
                matches[m] = list(np.random.choice(keep_ids, k, replace=False))
            elif len(keep_ids) < k:
                while len(matches[m]) <= k:
                    matches[m].append("NA")
            else:
                matches[m] = keep_ids.tolist()
            # 判断 replace 是否放回
            replace = True
            if not replace:
                g0 = g0.drop(matches[m])
    # print("\n匹配完成!")

    tem = Y.copy()
    for i in groups[groups == 1].index:
        tem[i] = Y[matches[i][0]]
    ATT = (sum(Y) - sum(tem))/n1  # 计算受到干预影响的个体因果效应平均值
    print("受到干预影响的个体因果效应平均值:", ATT)
    return ATT



if __name__ == '__main__':

    # Y_train = pd.read_csv("results/causal_graph/MECG/Y_train_MECG.csv")
    Y_train = pd.read_csv("results/causal_graph/MIT/Y_train_MIT.csv")

    # causal_grah(Y_train)
    # anchor_set = ['窦性心动过缓', '不完全性右束支阻滞']
    # candidate_set = ['窦性心律不齐', '完全性右束支阻滞']
    anchor_set = ['Atrial premature contraction', 'Nodal (junctional) escape beat']
    candidate_set =['Premature ventricular contraction', 'Normal beat']

    ecg_causal_graph = np.load("results\causal_graph\MIT\DAG.npy")  # 获得因果图边
    ancestors_dict = getAncestors(8, ecg_causal_graph)  # 获得所有的公共祖先
    causal_inference_PSM(anchor_set, candidate_set, Y_train, ancestors_dict, 0.5)