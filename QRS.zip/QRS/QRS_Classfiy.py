import numpy as np
import matplotlib.pyplot as plt
import scipy.signal as ss
import re
from scipy.stats import pearsonr
from common import tools as st
import copy
import random
import numpy as np
import time
import matplotlib.pyplot as plt
from common.wave_decom import *
ECG_SIGNER=[]
from matplotlib.ticker import  MultipleLocator
from matplotlib.ticker import  FormatStrFormatter
global Volume_scale #电压单位，若电压数据单位为mv则Volume_scale=1，若电压数据单位为uv,则Volume_scale=1000
global dx_ori #带通波形
global DX_MEAN #带通波形斜率均值
global plot_flag
Volume_scale=1
sampling_rate=500
plot_flag=True
A_Vol_Lim=0.45*Volume_scale    #波形大小写记号阈值
B_Vol_Lim=0.03 * Volume_scale  #波形判定电压阈值
judge_exist_area=int(0.006 * sampling_rate)#波形判定时间阈值

def DX_reCalibration(dx_ori=None,detect_R=None,peak=None,selected=0,Boun=False):
    '''
    在带通斜率波形上获取任意波形合理边界点
    :param dx_ori: 带通斜率
    :param detect_R: 边界值寻找边界
    :param peak: 波峰点
    :param selected: 选中由波峰到寻找边界的第n个斜率突变点
    :param Boun: 是否波群边界
    :return: 合理边界点
    '''
    if dx_ori is None:
        raise ValueError("Please specify an input dx_ori.")
    if detect_R is None or peak is None:
        raise ValueError("请检查输入！来自DX_reCalibration")
    if (peak > detect_R):

        dx_slice = dx_ori[detect_R:peak]
        dx_peaks_neg, _ = st.find_extrema(dx_slice, 'min')
        dx_peaks_pos, _ = st.find_extrema(dx_slice, 'max')


        if(selected!=0):
            try:
                b, _ = CutEnds(dx_slice, dx_peaks_pos[selected], 'pos')
            except:
                if(len(dx_peaks_pos)==0):
                    pass
                else:
                    b, _ = CutEnds(dx_slice, dx_peaks_pos[-1-selected], 'pos')
        else:
            try:
                temp = dx_peaks_pos[-1]
                dx_peaks_pos = dx_peaks_pos[dx_slice[dx_peaks_pos] > np.mean(dx_slice)]
                if (len(dx_peaks_pos) == 0):
                    dx_peaks_pos = [temp]
                if(len(dx_peaks_pos)>=2):
                    if(np.max(dx_slice[dx_peaks_pos])==dx_slice[dx_peaks_pos[-2]]):
                        dx_peaks_pos=np.delete(dx_peaks_pos,-1)
                b, _ = CutEnds(dx_slice, dx_peaks_pos[-1], 'pos')
                if(Boun):
                    b, _ = CutEnds(dx_slice, dx_peaks_pos[-1], 'pos')
                    i=2
                    while(dx_slice[b]>DX_MEAN):
                        if(len(dx_peaks_pos)-i>0):
                            b, _ = CutEnds(dx_slice, dx_peaks_pos[len(dx_peaks_pos)-i], 'pos')
                            i = i + 1
                        else:
                            break
            except:
                return detect_R
        return b + detect_R + 1
    else:
        dx_slice = dx_ori[peak:detect_R]
        dx_peaks_neg, _ = st.find_extrema(dx_slice, 'min')
        dx_peaks_pos, _ = st.find_extrema(dx_slice, 'max')
        if (selected != 0):
            _, c = CutEnds(dx_slice, dx_peaks_pos[0+selected], 'pos')
        else:
            try:
                temp=dx_peaks_pos[0]
                dx_peaks_pos = dx_peaks_pos[dx_slice[dx_peaks_pos] > np.mean(dx_slice)]
                if (len(dx_peaks_pos) >= 2):
                    if (np.max(dx_slice[dx_peaks_pos]) == dx_slice[dx_peaks_pos[1]]):
                        dx_peaks_pos = np.delete(dx_peaks_pos, 0)
                if(len(dx_peaks_pos)==0):
                    dx_peaks_pos=[temp]
                _, c = CutEnds(dx_slice, dx_peaks_pos[0], 'pos')
                if (Boun):
                    dx_peaks_pos = dx_peaks_pos[dx_slice[dx_peaks_pos] > DX_MEAN]
                    i = 1
                    while (dx_slice[c] > DX_MEAN):
                        if (len(dx_peaks_pos) - i > 0):
                            b, _ = CutEnds(dx_slice, dx_peaks_pos[i], 'pos')
                            i = i + 1
                        else:
                            break
            except:
                return detect_R
        return c + peak + 1

def CutEnds(signal=None,peak=None,Y_direction=None,error=False):
    '''
    寻找波形起始点
    :param signal: 输入信号
    :param peak: 需要切割的峰值点
    :param Y_direction: 波峰方向
    :param error: 是否弹出边界错误
    :return: 波形起点和终点
    '''
    if signal is None:
        raise ValueError("Please specify an input signal.")
    if Y_direction not in ['pos','neg']:
        raise ValueError("Unknwon Y_direction %r." % Y_direction)
    if(Y_direction=='pos'):
        a,_=st.find_extrema(signal=signal,mode='min')#a是极值点的位置列表、_是极值点的大小列表
        try:
            b=np.max(a[a<peak])
            # print("起点------------",b)
        except ValueError:
            b=0
        try:
            c=np.min(a[a>peak])
            # print("终点------------",c)
        except ValueError:
            c=len(signal)-1
    else:
        a, _ = st.find_extrema(signal=signal, mode='max')
        try:
            b = np.max(a[a < peak])
        except ValueError:
            b = 0
        try:
            c = np.min(a[a > peak])
        except ValueError:
            c = len(signal) - 1
    if(error):
        if(b==0 or c==len(signal)-1):
            raise ValueError('越界')
    return b,c


#56.4  point4000
#锯齿去除失败
def Cir_Anti_Aliasing(signal=None,PEAKS=None):
    '''
    锯齿波去除函数,不可单独调用
    :param signal: 输入信号
    :param PEAKS: 待处理的峰值点序列
    :return: 已完成去锯齿的峰值点
    '''
    if signal is None:
        raise ValueError("Please specify an input signal.")
    if PEAKS is None:
        raise ValueError("Please specify an input PEAKS.")
    for indice in range(1,len(PEAKS)):
        if (abs(signal[PEAKS[indice - 1]] - signal[PEAKS[indice]]) < 0.015 * Volume_scale
                and abs(PEAKS[indice] - PEAKS[indice - 1]) <= 2
        ):
            try:
                if (indice - 2 < 0):
                    vol_l=signal[0]
                else:
                    vol_l=signal[PEAKS[indice-2]]
                if(indice+1>=len(PEAKS)):
                    vol_r=signal[-1]
                else:
                    vol_r=signal[PEAKS[indice+1]]
                vol_m=signal[PEAKS[indice]]
                if(vol_r>vol_m and vol_l<vol_m):
                    PEAKS=np.delete(PEAKS,[indice,indice-1])
                elif(vol_r<vol_m and vol_l>vol_m):
                    PEAKS=np.delete(PEAKS,[indice,indice-1])
                else:
                    PEAKS = np.delete(PEAKS, [indice])
            except:
                PEAKS = np.delete(PEAKS, [indice])
            PEAKS=Cir_Anti_Aliasing(signal=signal,PEAKS=PEAKS)
            break
        else:
            pass
    return PEAKS
def Anti_Aliasing(signal=None,D_peaks=None,reverse=False):
    '''
    锯齿波去除函数
    :param signal: 输入信号
    :param D_peaks: 峰值点序列
    :param reverse: 是否转置
    :return: 已完成去锯齿的峰值点
    '''
    if signal is None:
        raise ValueError("Please specify an input signal.")

    if D_peaks is None:
        raise ValueError("Please specify an input D_peaks.")

    if(reverse):
        signal=signal.tolist()
        signal.reverse()
        signal=np.array(signal)
    PEAKS,_=st.find_extrema(signal, 'both') #找到输入信号的极大极小值
    PEAKS = Cir_Anti_Aliasing(signal=signal, PEAKS=PEAKS)

    if(reverse):
        PEAKS=len(signal)-PEAKS-1
    D_peaks=np.array(sorted(set(D_peaks).intersection(set(PEAKS))))
    return D_peaks
def contraction_area(signal=None,dx_ori=None,R_TEMP_PEAKS=None,detect_R=None,peak=None):
    '''
    矫正边界并返回有效峰值序列，以及双峰等特殊情况
    :param signal: 输入心电信号
    :param dx_ori: 输入带通斜率
    :param R_TEMP_PEAKS: 待选择的峰值点序列
    :param detect_R: 检测范围边界
    :param peak: 波群峰值点
    :return:
    detect_R：矫正后的边界值
    result_list：有效峰值序列
    '''
    if signal is None:
        raise ValueError("Please specify an input signal.")
    if dx_ori is None:
        raise ValueError("Please specify an input dx_ori.")
    if R_TEMP_PEAKS is None:
        raise ValueError("Please specify an input R_TEMP_PEAKS.")
    if detect_R is None:
        raise ValueError("Please specify an input detect_R.")
    if peak is None:
        raise ValueError("Please specify an input peak.")
    result_list=[]
    Double_R_details=[False,0]
    #修改输入参数，改为一定范围内计算
    direction_flag=True   #ture代表pos,false代表neg
    if(detect_R>peak):
        R_flag=True
    else:
        R_flag=False
    detect_R_temp=detect_R
    if (len(R_TEMP_PEAKS) == 0):
        try:
            detect_R=DX_reCalibration(dx_ori,detect_R,peak,Boun=True)
        except:
            pass
        result_list.append(detect_R)
        return detect_R,result_list,Double_R_details
        pass

    elif (len(R_TEMP_PEAKS) == 1):
        try:
            detect_R_Cal= DX_reCalibration(dx_ori,R_TEMP_PEAKS[0], peak,Boun=True)
            if(abs(detect_R_Cal-R_TEMP_PEAKS[0])<=2):
                pass
            else:
                R_TEMP_PEAKS[0]=detect_R_Cal
            detect_R = DX_reCalibration(dx_ori,detect_R_temp,R_TEMP_PEAKS[0],Boun=True)
            if(Minimum_wave_requirements(signal=signal,peak=R_TEMP_PEAKS[0],end=detect_R)):
                pass
            else:
                detect_R=R_TEMP_PEAKS[0]
        except:
             detect_R = R_TEMP_PEAKS[0]
        result_list.append(R_TEMP_PEAKS[0])
        if(R_TEMP_PEAKS[0]==detect_R):
            pass
        else:
            result_list.append(detect_R)

        return detect_R,result_list,Double_R_details

    else:
        pass_sum = 0
        for R_TEMP in range(1, len(R_TEMP_PEAKS)):
            if(pass_sum>0):
                pass_sum-=1
                continue
            if(Minimum_wave_requirements(signal=signal,peak=R_TEMP_PEAKS[R_TEMP-1],end=R_TEMP_PEAKS[R_TEMP])):
                detect_R=DX_reCalibration(dx_ori,R_TEMP_PEAKS[R_TEMP],R_TEMP_PEAKS[R_TEMP-1],selected=0)
                if(abs(detect_R-R_TEMP_PEAKS[R_TEMP])<=2):
                    detect_R=R_TEMP_PEAKS[R_TEMP]
                if(signal[R_TEMP_PEAKS[R_TEMP]]-signal[R_TEMP_PEAKS[R_TEMP-1]]<0):
                    direction_flag=False
                else:
                    direction_flag=True
                result_list.append(R_TEMP_PEAKS[R_TEMP-1])
                continue
            else:
                if(R_TEMP>=2):
                    vol_judge1=signal[R_TEMP_PEAKS[R_TEMP-1]]-signal[R_TEMP_PEAKS[R_TEMP-2]]
                    slope1=vol_judge1/(R_TEMP_PEAKS[R_TEMP-1]-R_TEMP_PEAKS[R_TEMP-2])
                else:
                    vol_judge1 = signal[R_TEMP_PEAKS[R_TEMP - 1]] - signal[peak]
                    slope1 = vol_judge1 / (R_TEMP_PEAKS[R_TEMP - 1] - peak)
                if(R_TEMP+1>=len(R_TEMP_PEAKS)):
                    vol_judge2=signal[detect_R_temp]-signal[R_TEMP_PEAKS[R_TEMP-1]]
                    slope2=vol_judge2/(detect_R_temp-R_TEMP_PEAKS[R_TEMP-1])
                else:
                    vol_judge2=signal[R_TEMP_PEAKS[R_TEMP + 1]] - signal[R_TEMP_PEAKS[R_TEMP - 1]]
                    slope2 = vol_judge2 / (R_TEMP_PEAKS[R_TEMP + 1] - R_TEMP_PEAKS[R_TEMP - 1])
                vol_judge3=signal[R_TEMP_PEAKS[R_TEMP]]-signal[R_TEMP_PEAKS[R_TEMP-1]]
                if(abs(slope1/slope2)<5 and abs(slope1/slope2)>1/5.0) :
                    if(vol_judge1*vol_judge2>0):
                        if(abs(vol_judge1+vol_judge2)>15*abs(vol_judge3) and abs(vol_judge2)>3*abs(vol_judge3) and abs(vol_judge1)>3*abs(vol_judge3)):
                            try:
                                if(R_TEMP-2<0):
                                    detect_R = DX_reCalibration(dx_ori, detect_R_temp, peak)
                                else:
                                    detect_R = R_TEMP_PEAKS[R_TEMP + 1]
                            except:
                                detect_R = detect_R_temp
                                try:
                                    detect_R = DX_reCalibration(dx_ori, detect_R_temp,R_TEMP_PEAKS[R_TEMP-2])

                                except:
                                    print('DX6', detect_R, peak)
                                    detect_R = DX_reCalibration(dx_ori, detect_R, peak)
                            pass_sum=1
                            result_list.append(detect_R)
                            continue
                    else:
                        if(abs(vol_judge2)<0.03*Volume_scale):
                            if(R_TEMP+1>=len(R_TEMP_PEAKS)):
                                vol_judge4=0
                            elif(R_TEMP+2>=len(R_TEMP_PEAKS)):
                                vol_judge4=signal[detect_R_temp]-signal[R_TEMP_PEAKS[R_TEMP-1]]
                            else:
                                vol_judge4 = signal[R_TEMP_PEAKS[R_TEMP + 2]] - signal[R_TEMP_PEAKS[R_TEMP - 1]]
                            if(abs(vol_judge4)>2.*abs(vol_judge2)):
                                continue
                else:
                    detect_R=R_TEMP_PEAKS[R_TEMP-1]
                #R双峰
                if(R_TEMP==1):
                    if(abs(R_TEMP_PEAKS[R_TEMP]-peak)<=0.03*sampling_rate):
                        if(abs(signal[detect_R_temp]-signal[peak])>20*abs(signal[peak]-signal[R_TEMP_PEAKS[0]])):
                            try:
                                detect_R=R_TEMP_PEAKS[2]
                                Double_R_details[0]=True
                                Double_R_details[1]=R_TEMP_PEAKS[1]
                                if (signal[R_TEMP_PEAKS[2]] - signal[R_TEMP_PEAKS[1]] < 0):
                                    direction_flag = False
                                else:
                                    direction_flag = True
                                pass_sum=1
                                continue
                            except:
                                detect_R=int((detect_R_temp+R_TEMP_PEAKS[1])/2)
                                break
                try:
                    if(R_TEMP-2>=0):
                        if (signal[R_TEMP_PEAKS[R_TEMP-1]]-signal[R_TEMP_PEAKS[R_TEMP - 2]]  < 0):
                            direction_flag = False
                        else:
                            direction_flag = True
                    else:
                        if (signal[R_TEMP_PEAKS[R_TEMP - 1]] - signal[peak] < 0):
                            direction_flag = False
                        else:
                            direction_flag = True
                    try:
                        if(R_TEMP>=2):
                            detect_R = DX_reCalibration(dx_ori, R_TEMP_PEAKS[R_TEMP-1], R_TEMP_PEAKS[R_TEMP-2],Boun=True)
                            if(Minimum_wave_requirements(signal=signal,peak=R_TEMP_PEAKS[R_TEMP-2],end=detect_R)):
                                if (signal[detect_R] - signal[R_TEMP_PEAKS[R_TEMP - 2]] < 0):
                                    direction_flag = False
                                else:
                                    direction_flag = True
                            else:
                                detect_R=R_TEMP_PEAKS[R_TEMP-1]
                        else:
                            #杂波双峰
                            if(R_TEMP+2<len(R_TEMP_PEAKS)):
                                vol_d=signal[R_TEMP_PEAKS[R_TEMP+2]]-signal[R_TEMP_PEAKS[R_TEMP+1]]
                            else:
                                vol_d=signal[R_TEMP_PEAKS[detect_R_temp]]-signal[R_TEMP_PEAKS[R_TEMP+1]]
                            if (abs(R_TEMP_PEAKS[R_TEMP+1] - R_TEMP_PEAKS[R_TEMP-1]) <= 0.03 * sampling_rate):
                                if (abs(vol_d) > 3 * abs(
                                    signal[R_TEMP_PEAKS[R_TEMP]] - signal[R_TEMP_PEAKS[R_TEMP-1]])):
                                    detect_R=R_TEMP_PEAKS[R_TEMP+2]
                                    if (signal[detect_R+2] - signal[R_TEMP_PEAKS[R_TEMP+1]] < 0):
                                        direction_flag = False
                                    else:
                                        direction_flag = True
                                    result_list.append(R_TEMP_PEAKS[R_TEMP-1])
                    except:
                        detect_R = R_TEMP_PEAKS[R_TEMP-1]
                    break
                except:
                    pass

    if(Minimum_wave_requirements(signal=signal,peak=detect_R,end=detect_R_temp)):
            detect_R_extend=detect_R_temp
            if(detect_R>peak):
                signal_redirect=signal[detect_R_extend-2:detect_R_extend+int(0.03*sampling_rate)]
            else:
                signal_redirect = signal[detect_R_extend - int(0.03 * sampling_rate):detect_R_extend + 2]
            redirect_peaks,_=st.find_extrema(signal_redirect,'both')
            redirect_peaks=Anti_Aliasing(signal_redirect,redirect_peaks)
            try:
                detect_R_extend=redirect_peaks[0]+detect_R_extend-2
            except:
                pass
            detect_R_Cal=DX_reCalibration(dx_ori,detect_R_extend,detect_R)
            vol_cal=signal[detect_R_Cal]-signal[detect_R]

            if (detect_R > peak):
                signal_cal = signal[peak:detect_R]
            else:
                signal_cal = signal[detect_R:peak]
            if(signal[peak]>signal[detect_R]):
                vol_r=np.max(signal_cal)-signal[detect_R]
                if(vol_cal>=0.6*vol_r and vol_cal<=vol_r):
                    pass
                else:
                    if(vol_cal>0):
                        vol_judge_finally=signal[detect_R_Cal]-signal[detect_R]
                        if(Minimum_wave_requirements(signal=signal,peak=detect_R,end=detect_R_Cal)):
                            if(direction_flag):
                                if(vol_judge_finally<0):
                                    detect_R = detect_R_Cal
                            else:
                                if (vol_judge_finally > 0):
                                    detect_R = detect_R_Cal
                    else:
                        if (abs(vol_cal) >  abs(vol_r)):
                            detect_R = detect_R_Cal
            else:
                vol_r = np.min(signal_cal)-signal[detect_R]
                if (abs(vol_cal) >= 0.6 * abs(vol_r) and abs(vol_cal)<abs(vol_r)):
                    pass
                else:
                    if(vol_cal<0):
                        vol_judge_finally=signal[detect_R_Cal] - signal[detect_R]
                        if (Minimum_wave_requirements(signal=signal, peak=detect_R, end=detect_R_Cal)):
                            if (direction_flag):
                                if (vol_judge_finally < 0):
                                    detect_R = detect_R_Cal
                            else:
                                if (vol_judge_finally > 0):
                                    detect_R = detect_R_Cal
                    else:
                        if(abs(vol_cal)>abs(vol_r)):
                            detect_R=detect_R_Cal
    else:
        pass
    result_list.append(detect_R)
    result_list=list(set(result_list))
    #print(detect_R,result_list,Double_R_details)
    return detect_R,result_list,Double_R_details
def Minimum_wave_requirements(signal=None,peak=None,end=None):
    '''
    判断是否为有效波形
    :param signal: 源信号
    :param peak: 波峰或波谷
    :param end: 起点或终点
    :return: 是否为有效波形
    '''
    if signal is None:
        raise ValueError("Please specify an input signal.")
    if peak is None:
        raise ValueError("Please specify an input peak.")
    if end is None:
        raise ValueError("Please specify an input end.")

    judge_exist_area = int(0.006 * sampling_rate)
    # 校验波形是否符合幅值、时域要求
    if (judge_exist_area > 1):
        signal_judge_slice = signal[peak - judge_exist_area + 1:peak + judge_exist_area]
        signal_judge_slice = signal_judge_slice[abs(signal_judge_slice - signal[end]) >= B_Vol_Lim]
        if (len(signal_judge_slice) >= judge_exist_area):
            return True
        else:
            return False
    else:
        if(abs(signal[peak]-signal[end])>B_Vol_Lim):
            return True
        else:
            return False
def Re_select_qrs_peaks(signal=None,PEAKS=None):
    judge_exist_area = int(0.006 * sampling_rate)
    #校验波形是否符合幅值、时域要求
    for indice in range(1,len(PEAKS)-1):
        if (judge_exist_area > 1):
            signal_judge_slice = signal[PEAKS[indice]- judge_exist_area + 1:PEAKS[indice] + judge_exist_area]
            signal_judge_slice = signal_judge_slice[abs(signal_judge_slice-signal[PEAKS[indice-1]]) >= B_Vol_Lim]
            if (len(signal_judge_slice) >= judge_exist_area):
                pass
            else:
                print('afsdgfhgnfiqwhefuihweuihgfuiwheguiheruighuiheruighugihueihguhuheruhguihierughier',PEAKS[indice])
def QRS_Classfiy_new(numpy_file=None):
    """
    对波形进行处理，并将波形及分类，整合。
    :param numpy_file:
    :return:
    """
    #print('**************************************************************')
    sampling_rate=float(500)
    beats=[]
    rpeaks=[]
    filtedDatas=[]
    '''先对原始心电信号进行小波变化去除噪声和基线漂移
    '''
    for i in range(12):
        dec = wave_decom("Symmlets" + str(1))
        clearSignal = dec.plot_I(numpy_file[i])

        filtedData = baseline_lowpass(clearSignal)
        filtedDatas.append(filtedData)

    '''对过滤后的信号filtedDatas提取出R波位置，beats是位置列表
    '''
    beats=Calibration_Major_Wave(signal=filtedDatas,strong_verification=True,sampling_rate=500)


    peaks=beats
    aas=[]
    qrs_detail_per_people = []
    for i in range(0,12):
        #print('j',i)
        ECG_SIGNER = numpy_file[i]
        ori_data = ECG_SIGNER
        RR_interval=np.diff(beats[i])
        sampling_rate = float(500)
        signal = filtedDatas[i]
        clearSignal=signal
        ECG_SIGNER=signal
        ori_data=signal
######################################################################################################################
        sm_size = int(0.08 * sampling_rate)
        # 这里对小波变换后的信号 低通高通滤波
        filtered, _, _ = st.filter_signal(signal=clearSignal,
                                          ftype='butter',
                                          band='lowpass',
                                          order=4,
                                          # frequency=25.,
                                          frequency=40.,
                                          sampling_rate=sampling_rate)
        filtered, _, _ = st.filter_signal(signal=filtered,
                                          ftype='butter',
                                          band='highpass',
                                          order=4,
                                          frequency=3.,
                                          sampling_rate=sampling_rate)
        dx = np.abs(np.diff(filtered, 1) * sampling_rate)
        # smoothing
        dx1=dx
        dx_ori=dx
        DX_MEAN=np.mean(dx)
        # 使用N点移动平均[MAvg]滤波器平滑信号
        dx, _ = st.smoother(signal=dx, kernel='hamming', size=sm_size, mirror=True)
#######################################################################################################################
        test_case=[]
        detection_range = []
        all_peaks=[]
        extrema=[]
        all_peak_result=[]
        qrs_detail_per_signal=[]
        for beat_index in range(1,len(beats[i])-1):
            slice_area=int(0.10*sampling_rate)
            beat_last=beats[i][beat_index-1]
            beat_now=beats[i][beat_index]
            beat_next = beats[i][beat_index+1]
            signal_per_beat=dx[beat_last+slice_area:beat_next-slice_area]
            max_point = (np.where(signal_per_beat==max(signal_per_beat))[0]+beat_last+slice_area)[0]
            all_peaks_per_beat,_=st.find_extrema(signal=signal_per_beat, mode='both')  #  定义位置
            all_pospeaks_per_beat, _ = st.find_extrema(signal=signal_per_beat, mode='max')
            all_peaks_per_beat=all_peaks_per_beat[signal_per_beat[all_peaks_per_beat]<np.mean(signal_per_beat)+0.2*max(signal_per_beat)]
            BOOL_L = all_peaks_per_beat < beat_now - beat_last - slice_area - 0.03 * sampling_rate
            BOOL_R = all_peaks_per_beat > beat_now - beat_last - slice_area + 0.03 * sampling_rate
            BOOL_A = []
            for xl, yl in zip(BOOL_L, BOOL_R):
                BOOL_A.append(xl or yl)
            # print(BOOL_L)
            # print(BOOL_R)
            # print(BOOL_A)
            all_peaks_per_beat = all_peaks_per_beat[BOOL_A]
            all_peaks_L=sorted(all_peaks_per_beat[all_peaks_per_beat<beat_now-beat_last-slice_area])
            all_peaks_R=sorted(all_peaks_per_beat[all_peaks_per_beat>beat_now-beat_last-slice_area])
            try:
                detect_L=all_peaks_L[-1]+beat_last+slice_area
            except:
                detect_L = beat_last + slice_area
            try:
                detect_R=all_peaks_R[0]+beat_last+slice_area
            except:
                detect_R = beat_next-slice_area
            test_case.append(detect_L)
            test_case.append(detect_R)

            # print('{}导联detect_L:'.format(i),detect_L)
            # print('{}导联beat now: '.format(i),beat_now)

            # 处理波峰前面？
            L_TEMP_PEAKS, _ = st.find_extrema(signal=signal[detect_L:beat_now], mode='both')

            #  锯齿波去除函数
            L_TEMP_PEAKS = Anti_Aliasing(signal[detect_L:beat_now], L_TEMP_PEAKS, reverse=True)
            L_TEMP_PEAKS = L_TEMP_PEAKS + detect_L
            L_TEMP_PEAKS = sorted(L_TEMP_PEAKS, reverse=True)

            # 矫正边界并返回有效峰值序列，以及双峰等特殊情况
            detect_L, result_L ,Double_R_Details_L= contraction_area(signal,dx_ori,L_TEMP_PEAKS, detect_L, beat_now)

            # print('纠正后{}导联detect_L: '.format(i) , detect_L)
            # print('纠正后{}导联detect_L的纵坐标:'.format(i) , signal[detect_L])

            # 处理波峰后面？
            R_TEMP_PEAKS, _ = st.find_extrema(signal=signal[beat_now:detect_R], mode='both')
            R_TEMP_PEAKS=Anti_Aliasing(signal[beat_now:detect_R],R_TEMP_PEAKS) #  锯齿波去除函数
            R_TEMP_PEAKS = R_TEMP_PEAKS + beat_now
            # 矫正边界并返回有效峰值序列，以及双峰等特殊情况
            #  detect_R :边界值，result_R:有效峰值序列
            detect_R ,result_R,Double_R_Details_R= contraction_area(signal,dx_ori,R_TEMP_PEAKS, detect_R,beat_now)

            result_L.append(beat_now)
            result_A=np.append(result_R,result_L)
            all_peak_result.append(result_A)
            result_A=sorted(result_A)
            # print('result_A', result_A,beat_now)
            # print(type(result_A), result_A)

            # 对于所得结果需进行进一步判断02
            WAVES_TYPES = ['QS', 'QR', 'QRS', 'QRSR', 'R', 'RS', 'RSR', 'RSRS']
            # print(np.where(np.array(result_A)>=beat_now),beat_now)
            # print(result_A.index(beat_now), beat_now)
            Wave_types = ['Q', 'R', 'S', 'R', 'S']
            result_len = len(result_A)
            # 形态判断
            signal_slice = signal[result_A[0]:result_A[-1]]
            baselines = ((signal[-1] - signal_slice[0]) / (len(signal_slice) - 1)) * np.linspace(0,
                    len(signal_slice) - 1, len(signal_slice)) + signal_slice[0]
            signal_QS_slice = signal_slice - baselines
            # print(signal_QS_slice)
            qrs_detail_l0 = []
            wave_type = ''
            START_POINT = result_A[0]
            END_POINT = result_A[-1]
            if (len(np.where(signal_QS_slice > 0)[0]) == 0):
                # print([beat_now, 'QS', result_A[0], beat_now, result_A[-1]])
                qrs_detail_l0 = [beat_now, 'QS', result_A[0], beat_now, result_A[-1]]
            else:
                Major_wave_indice = result_A.index(beat_now)
                if (result_len == 3):
                    wave_type = 'R'
                    if (abs(signal[beat_now] - signal[result_A[0]]) > A_Vol_Lim):
                        pass
                    else:
                        wave_type = wave_type.lower()
                    qrs_detail_l0.append(beat_now)
                    qrs_detail_l0.append(wave_type)
                    for result_indice in result_A:
                        qrs_detail_l0.append(result_indice)
                    #print(qrs_detail_l0)
                else:
                    # 区分正向主波和逆向主波
                    if (signal[beat_now] - signal[result_A[0]] > 0):
                        beat_now_pos=beat_now
                        classify_flag=True
                    else:
                        pass
                        if (Major_wave_indice == 1):
                            classify_flag = True
                            #print('Major_wave_indice==-1,第521行存在问题')
                            if (abs(signal[result_A[1]] - signal[result_A[0]]) > 2 * abs(
                                    signal[result_A[2]] - signal[result_A[0]])):
                                classify_flag = False
                                # 暂定为QS波
                                qrs_detail_l0 = [beat_now, 'QS', result_A[0], beat_now, result_A[2]]
                                #print(qrs_detail_l0)
                            else:
                                beat_now_pos=result_A[2]
                                #beat_now_pos = result_A[np.where(signal[result_A] == np.max(signal[result_A[Major_wave_indice:-1]]))[0][0]]

                            # exit(-1)
                        else:
                            classify_flag = True
                            # 前面填写主波还是R波有待考虑
                            try:
                                #beat_now_pos = result_A[np.where(signal[result_A] == np.max(signal[result_A[1:Major_wave_indice]]))[0][0]]
                                if(signal[result_A[Major_wave_indice-1]]>signal[result_A[Major_wave_indice+1]]):
                                    beat_now_pos=result_A[Major_wave_indice-1]
                                else:
                                    beat_now_pos=result_A[Major_wave_indice+1]
                            except:
                                #print(beat_now,i)
                                #print(result_A)
                                beat_now_pos=result_A[Major_wave_indice-1]
                            #print(result_A,signal[result_A],Major_wave_indice)#np.max(signal[result_A[1:Major_wave_indice]])
                            #由于前期主波检测及边界定位遗留的问题
                            #beat_now_pos = result_A[np.argmax(signal[result_A[1:-1]])+1]
                                #np.where(signal[result_A] == np.argmax(signal[result_A[1:Major_wave_indice]]))[0][0]]
                    if (classify_flag):
                        #print('beat_now_pos', beat_now_pos)
                        qrs_detail_l0.append(beat_now)
                        qrs_detail_l0.append('')
                        R_wave_indice = result_A.index((beat_now_pos))
                        R_type_indice = 1
                        if (R_wave_indice >= 2):
                            wave_indice_L = R_wave_indice - 1
                            type_indice_L = 0
                            if (result_len - 2 > R_wave_indice + 2):
                                wave_indice_R = R_wave_indice + 2
                                type_indice_R = R_type_indice + 2
                            else:
                                wave_indice_R = -1
                                type_indice_R = result_len - R_wave_indice + R_type_indice
                        else:
                            wave_indice_L = R_wave_indice
                            type_indice_L = 1
                            if (result_len - 2 > R_wave_indice + 3):
                                wave_indice_R = R_wave_indice + 4
                                type_indice_R = R_type_indice + 4
                            else:
                                wave_indice_R = -1
                                type_indice_R = result_len - R_wave_indice + R_type_indice
                        START_POINT = result_A[wave_indice_L - 1]
                        END_POINT = result_A[wave_indice_R]
                        wave_colony = result_A[wave_indice_L:wave_indice_R]
                        type_colony = Wave_types[type_indice_L:type_indice_R]
                        qrs_detail_l0.append(START_POINT)
                        for indice in range(len(wave_colony)):
                            if (abs(signal[wave_colony[indice]] - signal[result_A[0]]) > A_Vol_Lim):
                                wave_type = wave_type + type_colony[indice]
                            else:
                                wave_type = wave_type + type_colony[indice].lower()
                            qrs_detail_l0.append(wave_colony[indice])
                        qrs_detail_l0[1] = wave_type
                        qrs_detail_l0.append(END_POINT)
                        #print('wave_colony', wave_colony)
                        # for wave_indice in result_A[1:-1]:
                        #print(qrs_detail_l0)

            if(Double_R_Details_L[0]):
                qrs_detail_l1=Double_R_Details_L
            else:
                if(Double_R_Details_R[0]):
                    qrs_detail_l1=Double_R_Details_R
                else:
                    qrs_detail_l1=[False,0]

            Q_pathologic = False
           # print(wave_type,qrs_detail_l0)
            try:
                if(wave_type!='QS'and 'q' in wave_type.lower()):
                    points = np.argwhere(np.diff(
                        np.sign(signal[qrs_detail_l0[2]:qrs_detail_l0[0]] - signal[qrs_detail_l0[2]])) != 0).reshape(
                        -1) + 0
                    if(points[0]-qrs_detail_l0[2]>0.04*sampling_rate):
                        Q_pathologic = True
                    elif(abs(signal[qrs_detail_l0[0]]-signal[qrs_detail_l0[2]])<abs(4*(signal[qrs_detail_l0[2]]-signal[qrs_detail_l0[3]]))):
                        Q_pathologic = True
                    else:
                        Q_pathologic = False
            except:
                pass
            # R_wide=False
            # if(points[1]-points[0]>0.09*sampling_rate):
            #     R_wide=True
            qrs_detail_l2=[Q_pathologic,False,qrs_detail_l0[-1]-qrs_detail_l0[2]]
            #qrs_detail_l2 = [False, False, 0]

            qrs_detail_per_signal.append([qrs_detail_l0, qrs_detail_l1, qrs_detail_l2])
        qrs_detail_per_people.append(qrs_detail_per_signal)
    return qrs_detail_per_people
def find_Concave_Convex(signal):
    '''凹凸点检测
    :param signal:
    :return:
    '''
    signal = signal[::-1]
    diff1 = np.diff(signal)
    diff2 = np.diff(diff1)
    preflag = (diff2[0] > 0)
    a = []
    sum = 0
    sums = []
    for i in range(len(diff2)):
        if (preflag):
            if (diff2[i] > 0):
                pass
            else:
                preflag = False
                sum = sum + diff2[i]
        else:
            if (diff2[i] >= 0):
                sums.append(sum)
                sum = 0
                a.append(i)
                preflag = True
            else:
                sum = sum + diff2[i]
    if (len(a) == 0):
        return -1
    else:
        index = sums.index(min(sums))
        return a[index] - 1

def find_Concave_Convex1(signal):
    '''
    尚未整理的函数，用于凹凸点检测
    :param signal:
    :return:
    '''
    signal = signal[::-1]
    diff1 = np.diff(signal)
    diff2 = np.diff(diff1)
    preflag = (diff2[0] > 0)
    a0 = []
    a1 = []
    sum0 = 0
    sums0 = []
    sum1 = 0
    sums1 = []
    for i in range(len(diff2)):
        if (preflag):
            if (diff2[i] > 0):
                sum0 = sum0 + diff2[i]
            else:
                preflag = False
                sum1 = sum1 + diff2[i]
                sums0.append(sum0)
                sum0 = 0
                a0.append(i)
        else:
            if (diff2[i] >= 0):
                sum0 = sum0 + diff2[i]
                sums1.append(sum1)
                sum1 = 0
                a1.append(i)
                preflag = True
            else:
                sum1 = sum1 + diff2[i]
    if (len(sums0) == 0):
        if (len(sums1) == 0):
            return -1
        else:
            index = sums1.index(max(sums1))
            return a1[index] - 1
    else:
        if (len(sums1) == 0):
            index = sums0.index(max(sums0))
            return a0[index] - 1
        else:
            if (abs(max(sums0) > abs(max(sums1)))):
                index = sums0.index(max(sums0))
                return a0[index] - 1
            else:
                index = sums1.index(max(sums1))
                return a1[index] - 1
def find_Concave_Convex2(signal):
    '''
    尚未整理的函数，用于凹凸点检测
    :param signal:
    :return:
    '''
    signal = signal[::-1]
    diff1 = np.diff(signal)
    diff2 = np.diff(diff1)
    if(len(diff2)==0):
        return -1
    preflag = (diff2[0] > 0)
    a = []
    sum = 0
    sums = []
    for i in range(len(diff2)):
        if (preflag):
            if (diff2[i] > 0):
                sum = sum + diff2[i]
            else:
                preflag = False
                sums.append(sum)
                sum = 0
                a.append(i)
        else:
            if (diff2[i] >= 0):
                sum = sum + diff2[i]
                preflag = True
            else:
                pass
    if (len(a) == 0):
        return -1
    index = sums.index(min(sums))
    return a[index] - 1

def find_abrupt_point(signal=None, mode='min', slope=2.0, abss=True):
    '''寻找斜坡的拐点
        :param signal:array数组，输入的ECG信号
        :param model:str类型，极值，可以是max，也可以是min
        :param slope：float类型，斜坡
        :return:
    '''

    # check inputs
    if signal is None:
        raise TypeError("Please specify an input signal.")
    if mode not in ['max', 'min']:
        raise ValueError("Unknwon mode %r." % mode)
    x = signal
    y = np.diff(x)
    if (abss):
        z = np.nonzero(abs(y) < slope)[0]+1
    else:
        if (mode == 'min'):
            z = np.nonzero(y > slope)[0]+1
        else:
            z = np.nonzero(y < slope)[0]+1
    u = np.delete(x, z)
    if (u.size == 0):
        turn_back = -1
    else:
        signal = signal[::-1]
        if (mode == 'min'):
            turn_back = np.where(signal == min(u))[0][0]
        elif (mode == 'max'):
            turn_back = np.where(signal == max(u))[0][0]
        turn_back = len(signal) - turn_back
    return turn_back

def Classify_QRS(signal=None,sampling_rate=500,rpeaks=None):
    '''QRS波群的分类
            :param signal:array数组，输入的ECG信号
            :param sampling_rate：采样率
            :return:QRS波特征列表
    '''
    # check inputs
    if signal is None:
        raise TypeError("Please specify an input signal.")
    qrs_Wave_Feature_list = []
    # 区域自适应应根据心跳次数自适配
    select_area1 = int(0.09 * sampling_rate)
    select_area2 = int(0.07 * sampling_rate)
    select_area3 = int(0.05 * sampling_rate)
    select_area4 = int(0.03 * sampling_rate)
    pov_flag=True

    for rpeak in rpeaks:  # R_Peak需标定每个QRS波群第一个正向高峰
        #print(rpeak)
        if (signal[rpeak] > np.mean(signal[rpeak - 5:rpeak + 5])):
            pov_flag=True
        else:
            pov_flag=False
        if(pov_flag==False):
            pov_flag,parsam=single_QS_judge(signal=signal,sampling_rate=sampling_rate,neg_peak=rpeak)
            if(pov_flag):
                rpeak=parsam
        if(pov_flag==False):
            pass
        elif (rpeak - select_area1 < 0):
            continue
        else:
            QP_JUDGE = False
            SP_JUDGE = False
            ENDP_JUDGE = False

            Double_R_flag = False
            Double_R_indice = -1
            # QP
            # slope，应与取样率产生联系
            Q_limit0 = 2
            # amplitude
            Q_limit1 = 15
            # Distance,应与取样率产生联系
            Q_limit2 = 2
            redirect_flag=True
            while(redirect_flag):
                redirect_flag = False
                redirect_possible = False
                extrema_Q = find_extrema(signal[rpeak - select_area1: rpeak], 'min')
                if (len(extrema_Q) == 0):  # R左侧无可靠极值点
                    # print('rpeak',rpeak,'Q-staus1')
                    signal_Q0 = signal[rpeak - select_area1: rpeak]
                    signal_Q0 = signal_Q0[::-1]
                    wrong0 = find_abrupt_point(signal_Q0, 'min', 1)
                    if (wrong0 == -1):  # R峰基本没有幅度，排除
                        continue
                    QP = rpeak - wrong0
                    # 校准位置
                    QP_slope = 0.5 * (signal[rpeak] - signal[int((rpeak + QP) / 2)]) / (rpeak - QP)
                    if (QP_slope > 10):
                        QP_slope = 5
                    elif (QP_slope < 2):
                        QP_slope = 1
                    wrong0 = find_abrupt_point(signal_Q0, 'min', QP_slope)
                    if (wrong0 == -1):  # R峰基本没有幅度，排除
                        continue
                    if (QP_slope > 2):
                        QP = rpeak - wrong0
                        signal_cal_QP = signal[QP - 3:QP + 1]
                        cal_bra = find_extrema(signal_cal_QP, 'min')
                        signal_cal_QP = signal_cal_QP.tolist()
                        if (len(cal_bra) == 0):
                            QP = signal_cal_QP.index(min(signal_cal_QP)) + QP - 3
                        else:
                            QP = cal_bra[0] + QP - 3
                    QP_JUDGE = False
                elif (len(extrema_Q) == 1):  # R左侧存在一个极小值点
                    QP = extrema_Q[0] + rpeak - select_area1
                    signal_Q1 = signal[QP:rpeak]
                    signal_Q1 = signal_Q1[::-1]
                    wrong1 = find_abrupt_point(signal_Q1, 'min', 1)
                    if (wrong1 == -1):
                        pass
                    else:
                        QP = rpeak - wrong1
                    START = find_extrema(signal[QP - select_area2:QP], 'max')
                    if (len(START) == 0):
                        signal_Q_START = signal[QP - select_area2:QP]
                        signal_Q_START = signal_Q_START[::-1]
                        STARTP = QP - find_Concave_Convex(signal[QP - select_area2:QP])
                        if (STARTP == QP):
                            QP_JUDGE = False
                        elif ((signal[STARTP] - signal[QP]) / (QP - STARTP) > Q_limit0 and signal[STARTP] - signal[
                            QP] > Q_limit1 and QP - STARTP > Q_limit2):
                            QP_JUDGE = True
                            slope = (signal[STARTP] - signal[QP]) / (QP - STARTP)
                            if (slope < 10):
                                slope = 10
                            # 计量范围内幅度最大的满足Q波判别条件的波
                            judge_True = find_abrupt_point(signal_Q_START, 'max', slope=0.1 * slope, abss=False)
                            # print('juget', judge_True)
                            judge_True = QP - judge_True
                            if (judge_True >= STARTP):
                                pass
                            else:
                                if ((signal[judge_True] - signal[STARTP]) / (STARTP - judge_True) >= 0.1 * slope):
                                    if ((signal[judge_True] - signal[QP]) / (QP - judge_True) > Q_limit0 and signal[judge_True] -
                                          signal[QP] > Q_limit1 and QP - judge_True > Q_limit2):
                                        STARTP = judge_True
                        else:
                            QP_JUDGE = False
                    else:  # 如果Q左侧存在极大值点
                        i = len(START) - 1
                        # i=0
                        signal_Q_START = signal[QP - select_area2:QP]
                        signal_Q_START = signal_Q_START[::-1]
                        while (QP_JUDGE == False and i >= 0):
                            STARTP = START[i]
                            STARTP = STARTP + QP - select_area2
                            if (STARTP == QP):
                                QP_JUDGE = False
                            elif ((signal[STARTP] - signal[QP]) / (QP - STARTP) > Q_limit0 and signal[STARTP] - signal[
                                QP] > Q_limit1 and QP - STARTP > Q_limit2):
                                QP_JUDGE = True
                                slope = (signal[STARTP] - signal[QP]) / (QP - STARTP)
                                # 计量范围内幅度最大的满足Q波判别条件的波
                                judge_True = find_abrupt_point(signal_Q_START, 'max', slope=0.5 * slope, abss=False)
                                judge_True = QP - judge_True
                                if (judge_True >= STARTP):
                                    pass
                                else:
                                    if ((signal[judge_True] - signal[STARTP]) / (STARTP - judge_True) >= 0.5 * slope):
                                        if ((signal[judge_True] - signal[QP]) / (QP - judge_True) > Q_limit0 and signal[
                                            judge_True] -
                                                signal[QP] > Q_limit1 and QP - judge_True > Q_limit2):
                                            STARTP = judge_True
                            else:
                                QP_JUDGE = False
                            i = i - 1

                else:  # R左侧存在两个以上极小值点（需考虑P波倒置情况，暂未考虑）
                    # 可分辨出双峰R波
                    QP_pool = [[], []]
                    while (len(extrema_Q) > 0):
                        flag_wrong_detect = False
                        QP_Index = len(extrema_Q) - 1
                        QP = extrema_Q[QP_Index] + rpeak - select_area1
                        baseline = np.mean(signal[rpeak - 20:rpeak])
                        # 抗双峰
                        if (signal[QP] > baseline):
                            signal_Judge_Double_R = signal[QP - select_area3:QP]
                            diff_Double_R = max(signal_Judge_Double_R) - signal[QP]
                            judge_line = signal[QP] - np.mean(signal[QP - int(0.02 * sampling_rate):QP])
                            judge_condition_diff0 = diff_Double_R > 0.5 * (signal[rpeak] - signal[QP])
                            judge_condition_diff1 = judge_line > 2 * diff_Double_R
                            if (judge_condition_diff0 and judge_condition_diff1 and diff_Double_R > 15):
                                Double_R_flag = True
                                Double_R_indice = np.argmax(signal_Judge_Double_R) + QP - select_area3
                            if (signal[extrema_Q[QP_Index]]):
                                pass
                            extrema_Q = np.delete(extrema_Q, QP_Index)
                        else:
                            # 抗锯齿
                            signal_sawtooth = signal[QP - 5:QP]
                            signal_sawtooth_judge = signal[QP - 10:QP]
                            judge_sawtooth = find_extrema(signal=signal_sawtooth, mode='max')
                            judge__sawtooth_judge = min(signal_sawtooth_judge)
                            if (len(judge_sawtooth) == 0):
                                if ((max(signal_sawtooth) - signal[QP]) < 2):
                                    flag_wrong_detect = True
                                QP_pool[0].append(QP)
                                QP_pool[1].append(flag_wrong_detect)
                                extrema_Q = np.delete(extrema_Q, QP_Index)
                            else:
                                # 若幅度极低则认为其符合要求，只是误检为锯齿
                                a = max(signal_sawtooth)
                                b = np.argmax(signal_sawtooth) + QP - 5
                                if (QP - b > 3):
                                    QP_pool[0].append(QP)
                                    QP_pool[1].append(flag_wrong_detect)
                                    extrema_Q = np.delete(extrema_Q, QP_Index)
                                elif (a - signal[QP] > 1 / 2 * (a - judge__sawtooth_judge)):
                                    QP_pool[0].append(QP)
                                    QP_pool[1].append(flag_wrong_detect)
                                    extrema_Q = np.delete(extrema_Q, QP_Index)
                                elif (a - signal[QP] < 2):
                                    flag_wrong_detect = True
                                    QP_pool[0].append(QP)
                                    QP_pool[1].append(flag_wrong_detect)
                                    extrema_Q = np.delete(extrema_Q, QP_Index)
                                else:
                                    extrema_Q = np.delete(extrema_Q, QP_Index)
                    try:
                        QP_pool_index = QP_pool[1].index(False)
                        QP = QP_pool[0][QP_pool_index]
                        flag_tns = False
                        if (QP_pool_index > 0):
                            for True_index in range(QP_pool_index):
                                QP_True_index = QP_pool_index - True_index - 1
                                QP_True = QP_pool[0][QP_True_index]
                                if ((signal[QP_True] - signal[QP]) < 20):
                                    flag_tns=True
                                    QP = QP_True
                        if (flag_tns):
                            extrema_Q = np.insert(extrema_Q, 0, QP)
                            flag_wrong_detect = True
                        else:
                            for True_index in range(QP_pool_index, len(QP_pool[0])):
                                QP_True = QP_pool[0][True_index]
                                if (signal[QP] - signal[QP_True] > 3*(QP-QP_True)):
                                    QP = QP_True
                            if (QP_pool[0].index(QP) != len(QP_pool[0]) - 1):
                                QP_pool_index=QP_pool[0].index(QP)
                                redirect_possible = True
                            extrema_Q = np.insert(extrema_Q, 0, QP)
                            flag_wrong_detect = False
                    except ValueError:
                        if (len(QP_pool[0]) != 0):
                            QP = QP_pool[0][0]
                            for True_index in range(0, len(QP_pool[0])):
                                QP_True = QP_pool[0][True_index]
                                if (signal[QP] - signal[QP_True] > 20):
                                    QP = QP_True
                            flag_wrong_detect = True
                            extrema_Q = np.insert(extrema_Q, 0, QP)
                    cal_flag = False
                    if (len(extrema_Q) == 0):
                        cal_flag = True
                        signal_rejudge = signal[QP:rpeak]
                        QP = np.argmin(signal_rejudge) + QP
                        flag_QP = find_Concave_Convex2(signal[QP:rpeak])
                        Q_slope = 1 / 2 * (signal[rpeak] - signal[int((QP + rpeak) / 2)]) / (rpeak - QP)
                        Q_slope = 1 / 2 * (signal[rpeak] - signal[QP]) / (rpeak - QP)
                        if (Q_slope < 7):
                            Q_slope = 7
                    else:
                        if (flag_wrong_detect):
                            Q_slope = 1 / 3 * (signal[rpeak] - signal[int((QP + rpeak) / 2)]) / (rpeak - QP)
                        else:
                            Q_slope = 7 / 12 * (signal[rpeak] - signal[int((QP + rpeak) / 2)]) / (rpeak - QP)

                            if (Q_slope > 7):
                                Q_slope = 7
                    if (cal_flag):
                        signal_Q2 = signal[rpeak - select_area1 + np.argmin(signal[rpeak - select_area1:rpeak]):rpeak]
                    else:
                        signal_Q2 = signal[QP:rpeak]
                    signal_Q2 = signal_Q2[::-1]
                    wrong2 = find_abrupt_point(signal_Q2, 'min', Q_slope, abss=True)
                    if (wrong2 == -1):  # 需要考虑必要性，如果条件成立，可认为R峰不存在
                        pass
                    else:
                        QP = rpeak - wrong2
                    # 校准QP
                    signal_cal_QP = signal[QP - 3:QP + 1]
                    cal_bra = find_extrema(signal_cal_QP, 'min')
                    signal_cal_QP = signal_cal_QP.tolist()
                    if (len(cal_bra) == 0):
                        QP = signal_cal_QP.index(min(signal_cal_QP)) + QP - 3
                    else:
                        QP = cal_bra[0] + QP - 3
                    START = find_extrema(signal[QP - select_area2:QP], 'max')
                    if (len(START) == 0):
                        signal_Q_START = signal[QP - select_area2:QP]
                        signal_Q_START = signal_Q_START[::-1]
                        STARTP = QP - find_Concave_Convex(signal[QP - select_area2:QP])
                        # 可能性不大，需测试
                        if (STARTP == QP):
                            QP_JUDGE = False
                        elif ((signal[STARTP] - signal[QP]) / (QP - STARTP) > Q_limit0 and signal[STARTP] - signal[
                            QP] > Q_limit1 and QP - STARTP > Q_limit2):
                            QP_JUDGE = True
                        else:
                            QP_JUDGE = False
                    else:  # 仿照SP处理增加循环
                        # 抗锯齿方案二
                        i = len(START) - 1
                        # i=0
                        signal_Q_START = signal[QP - select_area2:QP]
                        signal_Q_START = signal_Q_START[::-1]
                        while (QP_JUDGE == False and i >= 0):
                            STARTP = START[i]
                            STARTP = STARTP + QP - select_area2
                            if (STARTP == QP):
                                QP_JUDGE = False
                            elif ((signal[STARTP] - signal[QP]) / (QP - STARTP) > Q_limit0 and signal[STARTP] - signal[
                                QP] > Q_limit1 and QP - STARTP > Q_limit2):
                                QP_JUDGE = True
                            else:
                                QP_JUDGE = False
                            i = i - 1
                if(redirect_possible):
                    QP_pool_index=QP_pool_index+1
                    QP_possible=QP_pool[0][QP_pool_index]
                    if(QP_possible>=QP):
                        break
                    if(max(signal[QP_possible:QP])-signal[QP]>0.4*(signal[rpeak]-signal[QP]) and max(signal[QP_possible:QP])-signal[QP]>20):
                        if((signal[QP_possible]-min(signal[QP_possible-int(0.05*sampling_rate):QP_possible]))>0.3*(signal[rpeak]-signal[QP])):
                            QP_JUDGE=False
                            rpeak=STARTP
                            redirect_flag=True
            if(QP_JUDGE):
                pass
            else:
                #方便S波检测预测基线
                STARTP=QP
            # SP
            S_limit0 = 1.2  # slope
            END_limit0 = 2.0  # slope
            S_END_limit0 = 1.0  # slope
            S_END_limit1 = 20  # amplitude
            SBP_limit0 = 1.5  # slope
            SBP_END_limit0 = 4  # slope
            SBP_END_limit1 = 20  # amplitude
            SP = 0
            extrema_S = find_extrema(signal[rpeak:rpeak + select_area1], 'min')
            extrema_S = extrema_S.tolist()
            if (len(extrema_S) == 0):
                # print('S_staus1', rpeak)
                signal_S0 = signal[rpeak: rpeak + select_area1]
                # signal_S0 = signal_Q0[::-1]
                wrong0 = find_abrupt_point(signal_S0, 'min', -1, abss=False)
                if (wrong0 == -1):  # R峰基本没有幅度，排除
                    continue
                SP = rpeak + wrong0
                # # 校准位置
                SP_slope = 0.5 * (signal[rpeak] - signal[int((rpeak + SP) / 2)]) / (rpeak - SP)
                if (SP_slope < -40):
                    SP_slope = -20
                elif (SP_slope > -4):
                    SP_slope = -2
                wrong0 = find_abrupt_point(signal_S0, 'min', SP_slope, abss=False)
                if (wrong0 == -1):  # R峰基本没有幅度，排除
                    continue
                if (SP_slope < -2):
                    SP = rpeak + wrong0
                    signal_cal_SP = signal[SP - 1:SP + 3]
                    cal_bra = find_extrema(signal_cal_SP, 'min')
                    signal_cal_SP = signal_cal_SP.tolist()
                    if (len(cal_bra) == 0):
                        SP = signal_cal_SP.index(min(signal_cal_SP)) + SP - 1
                    else:
                        SP = cal_bra[0] + SP - 1
                SP_JUDGE = False
            else:
                # # 可分辨出双峰R波
                S_slope = 1
                SP_pool = [[], []]
                while (len(extrema_S) > 0):
                    flag_wrong_detect = False
                    SP_Index = 0
                    SP = extrema_S[SP_Index] + rpeak
                    # 0.6为双峰与S波区分阈值
                    baseline = signal[STARTP]+0.6*(signal[rpeak]-signal[STARTP])
                    # 抗双峰
                    if (signal[SP] > baseline):
                        signal_Judge_Double_R = signal[SP:SP + select_area3]
                        diff_Double_R = max(signal_Judge_Double_R) - signal[SP]
                        if (diff_Double_R > 0.5 * (signal[rpeak] - signal[SP]) and diff_Double_R > 15 and abs(
                                SP - rpeak) < 0.02 * sampling_rate):
                            Double_R_flag = True
                            Double_R_indice = np.argmax(signal_Judge_Double_R) + SP
                        if (signal[extrema_S[SP_Index]]):
                            pass
                        extrema_S = np.delete(extrema_S, SP_Index)
                    else:
                        # 抗锯齿
                        signal_sawtooth = signal[SP:SP + 5]
                        judge_sawtooth = find_extrema(signal=signal_sawtooth, mode='max')
                        signal_sawtooth_judge = signal[SP:SP + 10]
                        judge_sawtooth = find_extrema(signal=signal_sawtooth, mode='max')
                        judge__sawtooth_judge = min(signal_sawtooth_judge)
                        if (max(signal_sawtooth_judge) - signal[SP] > SBP_END_limit1):
                            SP_pool[0].append(SP)
                            SP_pool[1].append(flag_wrong_detect)
                            extrema_S = np.delete(extrema_S, SP_Index)
                            break
                        if (len(judge_sawtooth) == 0):

                            if ((max(signal_sawtooth) - signal[SP]) < 2):
                                flag_wrong_detect = True
                            SP_pool[0].append(SP)
                            SP_pool[1].append(flag_wrong_detect)
                            extrema_S = np.delete(extrema_S, SP_Index)
                        else:

                            a = max(signal_sawtooth)
                            b = np.argmin(signal_sawtooth) + SP
                            if (SP - b > 3):
                                SP_pool[0].append(SP)
                                SP_pool[1].append(flag_wrong_detect)
                                extrema_S = np.delete(extrema_S, SP_Index)
                            elif (a - signal[SP] > 1 / 2 * (a - judge__sawtooth_judge)):
                                SP_pool[0].append(SP)
                                SP_pool[1].append(flag_wrong_detect)
                                extrema_S = np.delete(extrema_S, SP_Index)
                            elif (a - signal[QP] < 2):
                                flag_wrong_detect = True
                                SP_pool[0].append(SP)
                                SP_pool[1].append(flag_wrong_detect)
                                extrema_S = np.delete(extrema_S, SP_Index)
                            # 若幅度极低则认为其符合要求，只是误检为锯齿
                            elif ((max(signal_sawtooth) - signal[SP]) < 2):
                                flag_wrong_detect = True
                                SP_pool[0].append(SP)
                                SP_pool[1].append(flag_wrong_detect)
                                extrema_S = np.delete(extrema_S, SP_Index)
                                # break
                            else:
                                extrema_S = np.delete(extrema_S, SP_Index)
                try:
                    SP_pool_index = SP_pool[1].index(False)
                    SP = SP_pool[0][SP_pool_index]
                    flag_tns = False
                    if (SP_pool_index > 0):
                        for True_index in range(SP_pool_index):
                            SP_True_index = SP_pool_index - True_index - 1
                            SP_True = SP_pool[0][SP_True_index]
                            if ((signal[SP_True] - signal[SP]) < 20):
                                flag_tns=True
                                SP = SP_True
                    if (flag_tns):
                        extrema_S = np.insert(extrema_S, 0, SP)
                        flag_wrong_detect = True
                    else:
                        for True_index in range(SP_pool_index, len(SP_pool[0])):
                            SP_True = SP_pool[0][True_index]
                            if (signal[SP] - signal[SP_True] > 20):
                                SP = SP_True
                        extrema_S = np.insert(extrema_S, 0, SP)
                        flag_wrong_detect = False
                except ValueError:
                    if (len(SP_pool[0]) != 0):
                        SP = SP_pool[0][0]
                        for True_index in range(0, len(SP_pool[0])):
                            SP_True = SP_pool[0][True_index]
                            if (signal[SP] - signal[SP_True] > 20):
                                SP = SP_True
                        flag_wrong_detect = True
                        extrema_S = np.insert(extrema_S, 0, SP)
                cal_flag = False
                if (len(extrema_S) == 0):
                    cal_flag = True
                    signal_rejudge = signal[rpeak:SP]
                    SP = np.argmin(signal_rejudge) + rpeak
                    if(SP==rpeak):
                        pass
                    else:
                        S_slope = 1 / 2 * (signal[rpeak] - signal[int((SP + rpeak) / 2.0)]) / (rpeak - SP)
                else:
                    if (flag_wrong_detect):
                        S_slope = 1 / 3 * (signal[rpeak] - signal[int((SP + rpeak) / 2)]) / (rpeak - SP)
                    else:
                        S_slope = 7 / 12 * (signal[rpeak] - signal[int((SP + rpeak) / 2)]) / (rpeak - SP)
                        if (S_slope > 7):
                            S_slope = 7
                if (cal_flag):
                    signal_S2 = signal[rpeak:rpeak + np.argmin(signal[rpeak:rpeak + select_area1])]
                else:
                    signal_S2 = signal[rpeak:SP]
                wrong2 = find_abrupt_point(signal_S2, 'min', S_slope, abss=True)
                if (wrong2 == -1):  # 需要考虑必要性，如果条件成立，可认为R峰不存在
                    pass
                else:
                    SP = rpeak + wrong2
                # 校准QP
                signal_cal_SP = signal[SP - 3:SP + 1]
                cal_bra = find_extrema(signal_cal_SP, 'min')
                signal_cal_SP = signal_cal_SP.tolist()
                if (len(cal_bra) == 0):
                    SP = signal_cal_SP.index(min(signal_cal_SP)) + SP - 3
                else:
                    SP = cal_bra[0] + SP - 3
                END = find_extrema(signal[SP:SP + select_area2], 'max')
                if (len(END) == 0):
                    END = find_abrupt_point(signal[SP:SP + select_area2], 'max', slope=END_limit0)
                    if (END == -1):
                        SP_JUDGE = False
                    else:
                        SP_JUDGE = True
                        ENDP = SP + END
                else:
                    i = 0
                    baseline_END=signal[STARTP]
                    aml_END=1/5*(signal[STARTP]-signal[SP])
                    while (len(END) > 0 and SP_JUDGE == False):
                        ENDP = END[0]
                        ENDP = ENDP + SP
                        # 抗锯齿
                        signal_sawtooth = signal[ENDP:ENDP + 5]
                        judge_sawtooth = find_extrema(signal=signal_sawtooth, mode='min')
                        if (len(judge_sawtooth) == 0):
                            pass
                        else:
                            # 若幅度极低则认为其符合要求，只是误检为锯齿
                            if ((signal[ENDP] - min(judge_sawtooth)) < 2 and baseline_END-signal[ENDP]>aml_END):
                                END = np.delete(END, 0)
                                continue
                        if (ENDP == SP):
                            SP_JUDGE = False
                        elif ((signal[ENDP] - signal[SP]) / (ENDP - SP) > S_END_limit0 and (
                                signal[ENDP] - signal[SP]) > S_END_limit1):
                            SP_JUDGE = True
                        else:
                            SP_JUDGE = False
                        if (SP_JUDGE == False):
                            END = np.delete(END, 0)
                if (SP_JUDGE):
                    RBP=ENDP
                    S_Second = find_extrema(signal[ENDP:ENDP + select_area3], 'min')
                    if (len(S_Second) == 0):
                        S_Second = find_abrupt_point(signal[ENDP:ENDP + select_area3], 'min', slope=END_limit0)
                        if (S_Second == -1):
                            ENDP_JUDGE = False
                        else:
                            ENDP_JUDGE = True
                            SBP = ENDP + S_Second
                    else:
                        while (len(S_Second) > 0 and ENDP_JUDGE == False):
                            SBP = S_Second[0]
                            SBP = SBP + ENDP
                            # 抗锯齿
                            signal_sawtooth = signal[SBP:SBP + 5]
                            judge_sawtooth = find_extrema(signal=signal_sawtooth, mode='max')
                            if (len(judge_sawtooth) == 0):
                                pass
                            else:
                                # 若幅度极低则认为其符合要求，只是误检为锯齿
                                if (abs(signal[SBP] - max(judge_sawtooth)) < 2):
                                    S_Second = np.delete(S_Second, 0)
                                    continue
                            if (SBP == ENDP):
                                ENDP_JUDGE = False
                            elif (((signal[ENDP] - signal[SBP]) / (SBP - ENDP) > SBP_END_limit0 and signal[ENDP] -
                                   signal[SBP] > SBP_END_limit1) and (signal[ENDP] - signal[SBP]) > 0):
                                ENDP_JUDGE = True
                            else:
                                ENDP_JUDGE = False
                            if (ENDP_JUDGE == False):
                                S_Second = np.delete(S_Second, 0)
                    if (ENDP_JUDGE):
                        limited0=1
                        limited1=10
                        limited2=2
                        if (QP_JUDGE):
                            ENDP=RBP
                        else:
                            END1 = find_extrema(signal=signal[SBP:SBP + select_area3], mode='max')
                            if (len(END1) == 0):
                                ENDP = SBP+select_area4 - find_Concave_Convex(signal[SBP:SBP + select_area3])
                                if (ENDP == SBP):
                                    ENDP=ENDP+int(0.5*select_area3)
                                if ((signal[ENDP] - signal[SBP]) / (ENDP - SBP) > limited0 and signal[ENDP] -
                                      signal[SBP] > limited1 and ENDP - SBP > limited2):
                                    slope = (signal[ENDP] - signal[SBP]) / (ENDP - SBP)
                                    if (slope < 10):
                                        slope = 10
                                    # 计量范围内幅度最大的满足Q波判别条件的波
                                    judge_True = find_abrupt_point(signal[SBP:SBP + select_area3], 'max', slope=0.1 * slope,
                                                                   abss=False)
                                    judge_True = SBP+judge_True
                                    if (judge_True <= ENDP):
                                        pass
                                    else:

                                        if ((signal[judge_True] - signal[ENDP]) / (judge_True-ENDP) >= 0.1 * slope):
                                            if ((signal[judge_True] - signal[SBP]) / (judge_True - SBP) > limited0 and signal[
                                                judge_True] -signal[SBP] > limited1 and judge_True - SBP > limited2):
                                                 ENDP = judge_True
                            else:
                                while (len(END1) > 0):
                                    # print('循环中')
                                    ENDP = END1[0]
                                    ENDP = ENDP + SBP
                                    # 抗锯齿
                                    signal_sawtooth = signal[ENDP:ENDP + 5]
                                    judge_sawtooth = find_extrema(signal=signal_sawtooth, mode='min')
                                    if (len(judge_sawtooth) == 0):
                                        break
                                    else:
                                        # 若幅度极低则认为其符合要求，只是误检为锯齿
                                        if ((signal[ENDP] - min(judge_sawtooth)) < 2):
                                            END1 = np.delete(END1, 0)
                                            continue
                                        else:
                                            break
        if(pov_flag==False):
            qrs_Wave_Feature_list.append(parsam)
        elif (QP_JUDGE):
            if (SP_JUDGE):
                if (ENDP_JUDGE):
                    Q_Wave_amplitude = signal[STARTP] - signal[QP]
                    R1_Wave_amplitude = signal[rpeak] - signal[STARTP]
                    S_Wave_amplitude = signal[STARTP] - signal[SP]
                    R2_Wave_amplitude = signal[RBP] - signal[SBP]
                    if (R1_Wave_amplitude > 3 * Q_Wave_amplitude):
                        if (S_Wave_amplitude < 1 / 3 * R1_Wave_amplitude):
                            if (R2_Wave_amplitude > 3 * S_Wave_amplitude):
                                qrs_Wave_Feature_list.append([(rpeak, 'qRsR', STARTP, QP, rpeak, SP, RBP, SBP)])
                            else:
                                qrs_Wave_Feature_list.append([(rpeak, 'qRsr', STARTP, QP, rpeak, SP, RBP, SBP)])
                        else:
                            if (R2_Wave_amplitude > 3 * S_Wave_amplitude):
                                qrs_Wave_Feature_list.append([(rpeak, 'qRSR', STARTP, QP, rpeak, SP, RBP, SBP)])
                            else:
                                qrs_Wave_Feature_list.append([(rpeak, 'qRSr', STARTP, QP, rpeak, SP, RBP, SBP)])
                    else:
                        if (S_Wave_amplitude < 1 / 3 * R1_Wave_amplitude):
                            if (R2_Wave_amplitude > 3 * S_Wave_amplitude):
                                qrs_Wave_Feature_list.append([(rpeak, 'qrsR', STARTP, QP, rpeak, SP, RBP, SBP)])
                            else:
                                qrs_Wave_Feature_list.append([(rpeak, 'qrsr', STARTP, QP, rpeak, SP, RBP, SBP)])
                        else:
                            if (R2_Wave_amplitude > 3 * S_Wave_amplitude):
                                qrs_Wave_Feature_list.append([(rpeak, 'qrSR', STARTP, QP, rpeak, SP, RBP, SBP)])
                            else:
                                qrs_Wave_Feature_list.append([(rpeak, 'qrSr', STARTP, QP, rpeak, SP, RBP, SBP)])
                else:
                    Q_Wave_amplitude = signal[STARTP] - signal[QP]
                    R_Wave_amplitude_L = signal[rpeak] - signal[STARTP]
                    R_Wave_amplitude_R = signal[rpeak] - signal[ENDP]
                    S_Wave_amplitude = signal[ENDP] - signal[SP]
                    if (Q_Wave_amplitude < 1 / 3 * R_Wave_amplitude_L):
                        if (S_Wave_amplitude < 1 / 3 * R_Wave_amplitude_R):
                            qrs_Wave_Feature_list.append([(rpeak, 'qRs', STARTP, QP, rpeak, SP, ENDP)])
                        else:
                            qrs_Wave_Feature_list.append([(rpeak, 'qRS', STARTP, QP, rpeak, SP, ENDP)])
                    elif (Q_Wave_amplitude > R_Wave_amplitude_L and S_Wave_amplitude > R_Wave_amplitude_R):
                        qrs_Wave_Feature_list.append([(rpeak, 'QrS', STARTP, QP, rpeak, SP, ENDP)])
                    else:
                        if (S_Wave_amplitude < 1 / 3 * R_Wave_amplitude_R):
                            qrs_Wave_Feature_list.append([(rpeak, 'QRs', STARTP, QP, rpeak, SP, ENDP)])
                        else:
                            qrs_Wave_Feature_list.append([(rpeak, 'QRS', STARTP, QP, rpeak, SP, ENDP)])
            else:
                Q_Wave_amplitude = signal[STARTP] - signal[QP]
                R_Wave_amplitude = signal[rpeak] - signal[STARTP]
                if (R_Wave_amplitude < 1 / 2 * Q_Wave_amplitude):
                    qrs_Wave_Feature_list.append([(rpeak, 'Qr', STARTP, QP, rpeak, SP)])
                elif (Q_Wave_amplitude < 1 / 3 * R_Wave_amplitude):
                    qrs_Wave_Feature_list.append([(rpeak, 'qR', STARTP, QP, rpeak, SP)])
                else:
                    qrs_Wave_Feature_list.append([(rpeak, 'QR', STARTP, QP, rpeak, SP)])
        else:
            if (SP_JUDGE):
                if (ENDP_JUDGE):
                    R1_Wave_amplitude = signal[rpeak] - signal[QP]
                    S1_Wave_amplitude = signal[QP] - signal[SP]
                    R2_Wave_amplitude = signal[RBP] - signal[SBP]
                    S2_Wave_amplitude = signal[ENDP] - signal[SBP]
                    if (R1_Wave_amplitude > 3 * S1_Wave_amplitude):
                        if (S1_Wave_amplitude < 1 / 3 * R2_Wave_amplitude):
                            if (R2_Wave_amplitude > 3 * S2_Wave_amplitude):
                                qrs_Wave_Feature_list.append([(rpeak, 'RsRs', QP, rpeak, SP, RBP, SBP, ENDP)])
                            else:
                                qrs_Wave_Feature_list.append([(rpeak, 'RsRS', QP, rpeak, SP, RBP, SBP, ENDP)])
                        elif (S1_Wave_amplitude > R2_Wave_amplitude):
                            if (R2_Wave_amplitude > 3 * S2_Wave_amplitude):
                                qrs_Wave_Feature_list.append([(rpeak, 'RSrs', QP, rpeak, SP, RBP, SBP, ENDP)])
                            else:
                                qrs_Wave_Feature_list.append([(rpeak, 'RSrS', QP, rpeak, SP, RBP, SBP, ENDP)])
                        else:
                            if (R2_Wave_amplitude > 3 * S2_Wave_amplitude):
                                qrs_Wave_Feature_list.append([(rpeak, 'RSRs', QP, rpeak, SP, RBP, SBP, ENDP)])
                            else:
                                qrs_Wave_Feature_list.append([(rpeak, 'RSRS', QP, rpeak, SP, RBP, SBP, ENDP)])
                    else:
                        if (S1_Wave_amplitude < 1 / 3 * R2_Wave_amplitude):
                            if (R2_Wave_amplitude > 3 * S2_Wave_amplitude):
                                qrs_Wave_Feature_list.append([(rpeak, 'rsRs', QP, rpeak, SP, RBP, SBP, ENDP)])
                            else:
                                qrs_Wave_Feature_list.append([(rpeak, 'rsRS', QP, rpeak, SP, RBP, SBP, ENDP)])
                        elif (S1_Wave_amplitude > R2_Wave_amplitude):
                            if (R2_Wave_amplitude > 3 * S2_Wave_amplitude):
                                qrs_Wave_Feature_list.append([(rpeak, 'rSrs', QP, rpeak, SP, RBP, SBP, ENDP)])
                            else:
                                qrs_Wave_Feature_list.append([(rpeak, 'rSrS', QP, rpeak, SP, RBP, SBP, ENDP)])
                        else:
                            if (R2_Wave_amplitude > 3 * S2_Wave_amplitude):
                                qrs_Wave_Feature_list.append([(rpeak, 'rSRs', QP, rpeak, SP, RBP, SBP, ENDP)])
                            else:
                                qrs_Wave_Feature_list.append([(rpeak, 'rSRS', QP, rpeak, SP, RBP, SBP, ENDP)])
                else:
                    R_Wave_amplitude = signal[rpeak] - signal[ENDP]
                    S_Wave_amplitude = signal[ENDP] - signal[SP]
                    if (R_Wave_amplitude < 1 / 2 * S_Wave_amplitude):
                        qrs_Wave_Feature_list.append([(rpeak, 'rS', QP, rpeak, SP, ENDP)])
                    elif (S_Wave_amplitude < 1 / 3 * R_Wave_amplitude):
                        qrs_Wave_Feature_list.append([(rpeak, 'Rs', QP, rpeak, SP, ENDP)])
                    else:
                        qrs_Wave_Feature_list.append([(rpeak, 'RS', QP, rpeak, SP, ENDP)])
            else:
                qrs_Wave_Feature_list.append([(rpeak, 'R', QP, rpeak, SP)])
        if(pov_flag==False):
            pass
        else:
            if (Double_R_flag):
                qrs_Wave_Feature_list[-1].append((True, Double_R_indice))
            else:
                qrs_Wave_Feature_list[-1].append((False,0))
        # 病理性Q波,宽顿性R波
        RR=-1
        Q_pathologic = False
        R_wide=False
        if(pov_flag==False):
            pass
        elif(QP_JUDGE):
            Q_Wave_End_possible=np.where(abs(signal[QP:rpeak]-signal[STARTP])<20)[0]
            if(len(Q_Wave_End_possible)==0):
                pass
            else:
                Q_Wave_End=Q_Wave_End_possible[int(len(Q_Wave_End_possible)/2)]
                if((Q_Wave_End+QP-STARTP)>0.04*sampling_rate):
                    Q_pathologic=True
                if(SP_JUDGE):
                    S_Wave_START_possible = np.where(abs(signal[rpeak:SP] - signal[ENDP]) < 20)[0]
                    if (len(S_Wave_START_possible) == 0):
                        pass
                    else:
                        S_Wave_START = S_Wave_START_possible[int(len(S_Wave_START_possible) / 2)]
                        RR=S_Wave_START+rpeak-QP-Q_Wave_End
                else:
                    RR=SP-Q_Wave_End-QP
        else:
            if (SP_JUDGE):
                S_Wave_START_possible = np.where(abs(signal[rpeak:SP] - signal[ENDP]) < 20)[0]
                if (len(S_Wave_START_possible) == 0):
                    pass
                else:
                    S_Wave_START = S_Wave_START_possible[int(len(S_Wave_START_possible) / 2)]
                    RR = S_Wave_START + rpeak - QP
            else:
                RR = SP  - QP
        if(RR>0.09*sampling_rate):
            R_wide=True
        qrs_Wave_Feature_list[-1].append((Q_pathologic,R_wide,RR))
    qrs_Wave_Feature_lists = np.array(qrs_Wave_Feature_list)
    return qrs_Wave_Feature_lists

def cut_ends_Of_QRSWave(signal=None,qrs_Wave_Feature_list=None):

    """    Detach Qrs wave Endpoints and types
                ----------
                signal : numpy.array
                    Input signal.
                qrs_Wave_Feature_list:
                    The result of Classfiy_QRS
                Returns
                -------
                qrs_range: array
                    A collection of sampling points belonging to QRS waves
                qrs_y:array
                    corresponding amplitude
                qrs_type:array
                    type of QRS wave
                Email：
                ------
                XiaoXiao.TM@outlook.com
                """
    if signal is None:
        raise TypeError("Please specify an input signal.")
    qrs_range = []
    qrs_y = []
    qrs_type = []
    for i in qrs_Wave_Feature_list:
        # print(i)
        y = []
        start = i[0][2]
        end = i[0][len(i[0]) - 1]
        temp = range(int(start), int(end) + 1)
        qrs_type.append(i[0][1])
        qrs_range.append(temp)
        for x in temp:
            y.append(signal[x])
        qrs_y.append(y)
    return qrs_range, qrs_y, qrs_type

def find_extrema(signal=None, mode='min'):
    '''利用费马定理找极值
    :param signal: 输入信号
    :param mode: min表示极小值、max表示极大值
    :return: 极值点的位置
    '''
    # check inputs
    if signal is None:
        raise TypeError("Please specify an input signal.")
    if mode not in ['max', 'min']:
        raise ValueError("Unknwon mode %r." % mode)
    aux = np.diff(np.sign(np.diff(signal)))
    if mode == 'max':
        extrema = np.nonzero(aux < 0)[0] + 1
        extrema1 = np.nonzero(aux == -1)[0] + 1
    elif mode == 'min':
        extrema = np.nonzero(aux > 0)[0] + 1
        extrema1 = np.nonzero(aux == 1)[0] + 1
    values = signal[extrema1]
    wrong = []
    if (len(values) > 1):
        temp_value = values[0]
        temp = 0
        sum = 0
        for index in range(1, len(values)):
            if (values[index] == temp_value):
                sum = sum + 1
            elif (sum == 0):
                wrong.append(temp)
                temp_value = values[index]
                temp = index
                sum = 0
            else:
                temp_value = values[index]
                temp = index
                sum = 0
        if (values[len(values) - 1] != values[len(values) - 2]):
            wrong.append(len(values) - 1)
        extrema = np.delete(extrema, wrong)
    return extrema

def plot_qrs_wave(ori_data, signal, p_range, y_val, r_peaks, qrs_type):
    # 测试用程序
    # 主要功能：显示小波变换后波形，显示原波形，标记QRS波群
    fig, ax = plt.subplots()
    ax.plot(range(0, len(ori_data)), ori_data, 'b', label='EKG')
    p_len = len(p_range)
    for i in range(0, p_len):
        ax.plot(p_range[i], y_val[i], 'r', label='P peaks')
    for i in range(len(r_peaks)):
        ax.plot(r_peaks[i], ori_data[r_peaks[i]], 'X')
        ax.text(r_peaks[i], ori_data[r_peaks[i]] + 10, qrs_type[i])
    for i in range(0, len(signal)):
        signal[i] = signal[i]
    for i in range(0, p_len):
        indices = []
        for j in range(len(p_range[i])):
            indices.append([signal[p_range[i][j]]])
    plt.show()

def QS_judge(signal=None, sampling_rate=500, r_beats=None, neg_r_beats=None):
    '''
    批量鉴定是否为QS波
    :param signal:波形讯号
    :param sampling_rate:float，int，double取样率
    :param r_beats: list or ndarray正向峰值时间轴坐标
    :param neg_r_beats: list or ndarray负向峰值时间轴坐标
    :return:
    '''
    neg_peaks = []
    QS_WAVE = []

    area0=int(0.10*sampling_rate)
    area1=int(0.05*sampling_rate)
    for neg_peak in neg_r_beats:
        JUDGER=False
        JUDGEL=False
        baseline_R=np.mean(signal[neg_peak:neg_peak+area0])
        baseline_L = np.mean(signal[neg_peak-area0:neg_peak])
        right_list = find_extrema(signal[neg_peak:neg_peak+area0], 'max')
        left_list = find_extrema(signal[neg_peak-area0:neg_peak], 'max')
        #print(left_list,right_list)
        if (len(right_list) == 0):
            right_list = find_abrupt_point(signal[neg_peak:neg_peak+area0], 'max', slope=5,abss=False)
            right_max=right_list+neg_peak
            JUDGER=True
        else:
            i = 0
            aml_END = 1 / 5 * (baseline_R - signal[neg_peak])
            while (len(right_list) > 0 and JUDGER == False):
                # print('循环中')
                right_max = right_list[0] + neg_peak
                # 抗锯齿
                signal_sawtooth = signal[right_max:right_max + 5]
                judge_sawtooth = find_extrema(signal=signal_sawtooth, mode='min')
                if (len(judge_sawtooth) == 0):
                    pass
                else:
                    # 若幅度极低则认为其符合要求，只是误检为锯齿
                    if ((signal[right_max] - min(judge_sawtooth)) < 2 and baseline_R - signal[right_max] > aml_END):
                        right_list = np.delete(right_list, 0)
                        continue
                if (right_max == neg_peak):
                    JUDGER = False
                elif (signal[right_max]>baseline_R):
                    JUDGER = True
                else:
                    JUDGER = False
                if (JUDGER == False):
                    right_list = np.delete(right_list, 0)
        if(JUDGER):
            pass
        else:
            right_min=np.argmin(signal[right_max:right_max+int(1/2*area1)])+right_max
            right_max=find_abrupt_point(signal[right_min:right_min+area1],'max',slope=0.75*(signal[right_min+int(1/2*area1)]-signal[right_min])/int(1/2*area1),abss=False)+right_min
            #print('123',(signal[right_min+int(1/2*area1)]-signal[right_min])/int(1/2*area1),'jujguyfgvuy',signal[right_max]-signal[right_max-1],(signal[right_min+int(1/2*area1)]-signal[right_min])/int(1/2*area1))

        if (len(left_list) == 0):
            left_list = find_abrupt_point(signal[neg_peak-area0:neg_peak], 'max', slope=5)
            left_max =  neg_peak-area0+left_list
        else:
            i = 0
            aml_END = 1 / 5 * (baseline_L - signal[neg_peak])
            while (len(left_list) > 0 and JUDGEL == False):
                # print('循环中')
                left_max =   neg_peak-area0+left_list[len(left_list)-1]
                # 抗锯齿
                signal_sawtooth = signal[left_max-5:right_max]
                judge_sawtooth = find_extrema(signal=signal_sawtooth, mode='min')
                if (len(judge_sawtooth) == 0):
                    pass
                else:
                    # 若幅度极低则认为其符合要求，只是误检为锯齿
                    if ((signal[left_max] - min(judge_sawtooth)) < 2 and baseline_L - signal[
                        left_max] > aml_END):
                        left_list = np.delete(left_list, 0)
                        continue
                if (left_max == neg_peak):
                    JUDGEL = False
                elif (signal[left_max] > baseline_L):
                    JUDGEL = True
                else:
                    JUDGEL = False
                if (JUDGEL == False):
                    left_list = np.delete(left_list, 0)
        if (JUDGEL):
            pass
        else:
            left_min = np.argmin(signal[left_max- int(1 / 2 * area1):left_max ]) + left_max- int(1 / 2 * area1)
            left_max = find_abrupt_point(signal[left_max- area1:left_max ], 'max', slope=0.75 * (
                        signal[left_min - int(1 / 2 * area1)] - signal[left_min]) / int(1 / 2 * area1),
                                          abss=False) + left_max- area1
        left_min=min(signal[left_max-area1:left_max])
        right_min=min(signal[right_max:right_max+area1])
        if((signal[right_max]-right_min)>(signal[left_max]-left_min)):
            if((signal[right_max]-right_min)<0.1*(signal[right_max]-signal[neg_peak])):
                QS_WAVE.append([(-1, 'QS', left_max, neg_peak, right_max),(False,0)])
                #print([(7, 'QS', left_max, neg_peak, right_max), (False, 0)])
            else:
                r_beats.append(right_max)
        else:
            if ((signal[left_max] - left_min) < 0.1 * (signal[left_max] - signal[neg_peak])):
                QS_WAVE.append([(-1, 'QS', left_max, neg_peak, right_max), (False, 0)])
                #print([(7, 'QS', left_max, neg_peak, right_max), (False, 0)])
            else:
                r_beats.append(left_max)
    rpeaks = sorted(list(set(r_beats)))
    return rpeaks, neg_peaks, QS_WAVE

def single_QS_judge(signal=None, sampling_rate=500, neg_peak=None):
    #QS波判定检测程序
    neg_peaks = []
    QS_WAVE = []
    area0=int(0.10*sampling_rate)
    area1=int(0.05*sampling_rate)
    pov_flag=False
    JUDGER=False
    JUDGEL=False
    baseline_R=np.mean(signal[neg_peak:neg_peak+area0])
    baseline_L = np.mean(signal[neg_peak-area0:neg_peak])
    right_list = find_extrema(signal[neg_peak:neg_peak+area0], 'max')
    left_list = find_extrema(signal[neg_peak-area0:neg_peak], 'max')
    #print(left_list,right_list)
    if (len(right_list) == 0):
        right_list = find_abrupt_point(signal[neg_peak:neg_peak+area0], 'max', slope=5,abss=False)
        right_max=right_list+neg_peak
        JUDGER=True
    else:
        i = 0
        aml_END = 1 / 5 * (baseline_R - signal[neg_peak])
        while (len(right_list) > 0 and JUDGER == False):
            # print('循环中')
            right_max = right_list[0] + neg_peak
            # 抗锯齿
            signal_sawtooth = signal[right_max:right_max + 5]
            judge_sawtooth = find_extrema(signal=signal_sawtooth, mode='min')
            if (len(judge_sawtooth) == 0):
                pass
            else:
                # 若幅度极低则认为其符合要求，只是误检为锯齿
                if ((signal[right_max] - min(judge_sawtooth)) < 2 and baseline_R - signal[right_max] > aml_END):
                    right_list = np.delete(right_list, 0)
                    continue
            if (right_max == neg_peak):
                JUDGER = False
            elif (signal[right_max]>baseline_R):
                JUDGER = True
            else:
                JUDGER = False
            if (JUDGER == False):
                right_list = np.delete(right_list, 0)
    if(JUDGER):
        pass
    else:
        right_min=np.argmin(signal[right_max:right_max+int(1/2*area1)])+right_max
        right_max=find_abrupt_point(signal[right_min:right_min+area1],'max',slope=0.75*(signal[right_min+int(1/2*area1)]-signal[right_min])/int(1/2*area1),abss=False)+right_min
        #print('123',(signal[right_min+int(1/2*area1)]-signal[right_min])/int(1/2*area1),'jujguyfgvuy',signal[right_max]-signal[right_max-1],(signal[right_min+int(1/2*area1)]-signal[right_min])/int(1/2*area1))

    if (len(left_list) == 0):
        left_list = find_abrupt_point(signal[neg_peak-area0:neg_peak], 'max', slope=5)
        left_max =  neg_peak-area0+left_list
    else:
        i = 0
        aml_END = 1 / 5 * (baseline_L - signal[neg_peak])
        while (len(left_list) > 0 and JUDGEL == False):
            # print('循环中')
            left_max =   neg_peak-area0+left_list[len(left_list)-1]
            # 抗锯齿
            signal_sawtooth = signal[left_max-5:right_max]
            judge_sawtooth = find_extrema(signal=signal_sawtooth, mode='min')
            if (len(judge_sawtooth) == 0):
                pass
            else:
                # 若幅度极低则认为其符合要求，只是误检为锯齿
                if ((signal[left_max] - min(judge_sawtooth)) < 2 and baseline_L - signal[
                    left_max] > aml_END):
                    left_list = np.delete(left_list, 0)
                    continue
            if (left_max == neg_peak):
                JUDGEL = False
            elif (signal[left_max] > baseline_L):
                JUDGEL = True
            else:
                JUDGEL = False
            if (JUDGEL == False):
                left_list = np.delete(left_list, 0)
    if (JUDGEL):
        pass
    else:
        left_min = np.argmin(signal[left_max- int(1 / 2 * area1):left_max ]) + left_max- int(1 / 2 * area1)
        left_max = find_abrupt_point(signal[left_max- area1:left_max ], 'max', slope=0.75 * (
                    signal[left_min - int(1 / 2 * area1)] - signal[left_min]) / int(1 / 2 * area1),
                                      abss=False) + left_max- area1

    left_min=min(signal[left_max-area1:left_max])
    right_min=min(signal[right_max:right_max+area1])
    if((signal[right_max]-right_min)>(signal[left_max]-left_min)):
        if((signal[right_max]-right_min)<0.1*(signal[right_max]-signal[neg_peak])):
            QS_WAVE=[(-1, 'QS', left_max, neg_peak, right_max),(False,0)]
            #print([(7, 'QS', left_max, neg_peak, right_max), (False, 0)])
        else:
            pov_flag=True
            r_beat=right_max
    else:
        if ((signal[left_max] - left_min) < 0.1 * (signal[left_max] - signal[neg_peak])):
            QS_WAVE=[(-1, 'QS', left_max, neg_peak, right_max), (False, 0)]
            #print([(7, 'QS', left_max, neg_peak, right_max), (False, 0)])
        else:
            pov_flag=True
            r_beat=left_max
    if(pov_flag):
        return pov_flag,r_beat
    else:
        return pov_flag,QS_WAVE

def Re_Calibration_Major_Wave(signal=None, beats=None, flag_break=True):
    '''校准R波：
            parameter：signal：ECG信号
            parameter：beats：12导联所有心拍位置索引
            return：校正后的心拍、？
    '''
    e = []
    redirect_length = 25
    limit_length = 50
    for j in range(0, 12):
        ECG_SIGNER = signal[j]

        d = findMajorPeaks(signal=ECG_SIGNER, beats=beats[j], sampling_rate=500)  #  更正主播的位置
        # d = sorted(set(d) - b)
        e.append(d)
    for i, d in enumerate(e):
        for xc, xz in enumerate(d):
            d[xc] = int(xz)
    mode = []#每个导联中波个数
    for i in e:
        mode.append(len(i))
    if (len(list(set(mode))) == 1):
        pass
    else:
        j = 0#第几个波
        flag = False
        while j < max(mode):
            if (flag):
                break
            col = []
            weight_flag = False
            weight_flag_sum = 0
            if (j == min(mode)):
                for min_index, min_list in enumerate(mode):#min_index导联序号
                    if (min_list == j):
                        e[min_index].append(-1)
                        weight_flag_sum = weight_flag_sum + 1
                if (weight_flag_sum == 6):
                    weight_flag = True
            for i in range(12):
                col.append(e[i][j])
            median = np.median(col)
            median = int(median)
            mean = np.mean(col)
            if (weight_flag_sum > 0 and weight_flag_sum != 12):#有导联进行补波，但不是所有导联都补波
                mean = (12 * mean + weight_flag_sum) / (12 - weight_flag_sum)
            if (weight_flag):
                median = 2 * median + 1
            if (abs(mean - median) < 0.5 and weight_flag_sum == 0):
                j = j + 1
                # 加一组flag判定信息，如果投票正反双方导联数相等，此处判定False
                continue
            else:
                for x, y in enumerate(col):
                    if (median == -1):
                        back = []
                        for end in e:
                            back.append(end[0:j])
                        e = back
                        flag = True
                        break
                    elif (median < redirect_length or (median + redirect_length) > len(signal[x])):
                        e[x].insert(j, median)
                        flag_break = False
                        #print('wrong,边界未去除')
                    elif (y == -1):
                        e[x][len(e[x]) - 1] = median
                        pridect = median
                        e[x][j] = pridect
                        flag_break = False
                    elif (abs(y - median) > limit_length):
                        pridect = median
                        e[x].insert(j, pridect)
                        flag_break = False

                    while (j < len(e[x]) - 1 and (e[x][j + 1] - e[x][j]) <= limit_length):
                        if (abs(e[x][j + 1] - median) < abs(e[x][j] - median)):
                            del e[x][j]
                        else:
                            del e[x][j + 1]
            mode = []
            for k in e:
                mode.append(len(k))
            j = j + 1
    e_finally = []
    for e_value in e:
        e_finally.append(sorted(set(e_value)))
    return e_finally, flag_break

def Calibration_Major_Wave(signal=None,strong_verification=False,sampling_rate=500):  #可用
    '''R波校准
        return：返回12导联的所有心拍beats【就是R波的位置】
    '''
    flag = False
    sum = 0
    beats = []

    for i in range(12):
        #beat为通过hamilton_segmenter算法得到的心拍
        beat = hamilton_segmenter(signal[i], sampling_rate)
        beats.append(beat)

    while (flag == False):
        last_beats = beats
        beats, flag = Re_Calibration_Major_Wave(signal, beats, True)  # 校准波形位置
        #重新校正的心拍位置与原来相同
        if (last_beats == beats):
            flag = True
            peaks = []
            for i in range(12):
                peak = findMajorPeaks(signal[i], beats=beats[i], sampling_rate=sampling_rate)
                peaks.append(peak)
            beats = peaks
        sum = sum + 1
        if (sum > 6):
            break

    if(strong_verification):
        lens = []
        for beat in beats:
            lens.append(len(beat))
        if (len(sorted(set(lens))) != 1):
            beats, flag = Re_Calibration_Major_Wave(signal, beats, True)
            return beats

    return beats

def hamilton_segmenter(signal=None, sampling_rate=1000.):  # 可用
    '''参考BiosPPy工具包中的简单接口算法hamilton_segmenter。
        parameter signal：ECG信号序列、
        parameter sampling_rate：采样率(每秒采集多少个样本点)
        return：ECG的心拍beat（先定位到R波，再通过R波截取心拍）具体包含
            rpeaks：R波位置索引
            neg_peaks：QS波谷指数QS-wave wave trough indices
            QS_WAVE：QS波形元组列表
    '''

    # check inputs
    if signal is None:
        raise TypeError("Please specify an input signal.")
    sampling_rate = float(sampling_rate)
    length = len(signal)
    dur = length / sampling_rate

    # algorithm parameters
    v1s = int(1. * sampling_rate)
    v100ms = int(0.1 * sampling_rate)

    TH_elapsed = np.ceil(0.36 * sampling_rate)  # ceil:向上取整
    sm_size = int(0.08 * sampling_rate)
    init_ecg = 8  # 用于初始化的秒速
    if dur < init_ecg:
        init_ecg = int(dur)
    # filtering
    filtered, _, _ = st.filter_signal(signal=signal,
                                      ftype='butter',
                                      band='lowpass',
                                      order=4,
                                      # frequency=25.,
                                      frequency=40.,
                                      sampling_rate=sampling_rate)
    filtered, _, _ = st.filter_signal(signal=filtered,
                                      ftype='butter',
                                      band='highpass',
                                      order=4,
                                      frequency=3.,
                                      sampling_rate=sampling_rate)
    # diff
    dx = np.abs(np.diff(filtered, 1) * sampling_rate)
    # smoothing 使用N点移动平均[MAvg]滤波器平滑信号。
    dx, _ = st.smoother(signal=dx, kernel='hamming', size=sm_size, mirror=True)
    # buffers
    qrspeakbuffer = np.zeros(init_ecg)
    noisepeakbuffer = np.zeros(init_ecg)
    peak_idx_test = np.zeros(init_ecg)
    noise_idx = np.zeros(init_ecg)
    # rrinterval = sampling_rate * np.ones(init_ecg)
    rrinterval = np.zeros(init_ecg)
    # print('rrrrrr',rrinterval)
    a, b = 0, v1s
    all_peaks, _ = st.find_extrema(signal=dx, mode='max')

    for i in range(init_ecg):
        peaks, values = st.find_extrema(signal=dx[a:b], mode='max') # 定位信号中的局部极大值点（索引，和值）。
        try:
            ind = np.argmax(values)  # 返回values的最大值
        except ValueError:
            pass
        else:
            # peak amplitude 峰值振幅
            qrspeakbuffer[i] = values[ind]
            # peak location 峰值位置
            peak_idx_test[i] = peaks[ind] + a
        a += v1s
        b += v1s
    # thresholds
    ANP = np.median(noisepeakbuffer)
    AQRSP = np.median(qrspeakbuffer)
    TH = 0.475
    DT = ANP + TH * (AQRSP - ANP)
    DT_vec = []
    indexqrs = 0
    indexnoise = 0
    indexrr = 0
    npeaks = 0
    offset = 0
    beats = []
    tfs = []
    # detection rules
    # 1 - ignore all peaks that precede or follow larger peaks by less than 200ms
    lim = int(np.ceil(0.2 * sampling_rate))  # 向上取整
    diff_nr = int(np.ceil(0.045 * sampling_rate))
    bpsi, bpe = offset, 0
    for f in all_peaks:
        DT_vec += [DT]
        # 1 - Checking if f-peak is larger than any peak following or preceding it by less than 200 ms
        peak_cond = np.array((all_peaks > f - lim) * (all_peaks < f + lim) * (all_peaks != f))
        peaks_within = all_peaks[peak_cond]
        if peaks_within.any() and (max(dx[peaks_within]) > dx[f]):
            continue
        # 4 - If the peak is larger than the detection threshold call it a QRS complex, otherwise call it noise
        if dx[f] > DT:
            # 2 - look for both positive and negative slopes in raw signal
            if f < diff_nr:
                diff_now = np.diff(signal[0:f + diff_nr])
            elif f + diff_nr >= len(signal):
                diff_now = np.diff(signal[f - diff_nr:len(dx)])
            else:
                diff_now = np.diff(signal[f - diff_nr:f + diff_nr])
            diff_signer = diff_now[diff_now > 0]
            if len(diff_signer) == 0 or len(diff_signer) == len(diff_now):
                continue
            # RR INTERVALS
            if npeaks > 0:
                # 3 - in here we check point 3 of the Hamilton paper
                # that is, we check whether our current peak is a valid R-peak.
                prev_rpeak = beats[npeaks - 1]
                elapsed = f - prev_rpeak
                # if the previous peak was within 360 ms interval
                if elapsed < TH_elapsed:
                    # check current and previous slopes
                    if prev_rpeak < diff_nr:
                        diff_prev = np.diff(signal[0:prev_rpeak + diff_nr])
                    elif prev_rpeak + diff_nr >= len(signal):
                        diff_prev = np.diff(signal[prev_rpeak - diff_nr:len(dx)])
                    else:
                        diff_prev = np.diff(signal[prev_rpeak - diff_nr:prev_rpeak + diff_nr])
                    slope_now = max(diff_now)
                    slope_prev = max(diff_prev)

                    if (slope_now < 0.5 * slope_prev):
                        # if current slope is smaller than half the previous one, then it is a T-wave
                        continue
                if dx[f] < 5 * np.median(qrspeakbuffer):  # avoid retarded noise peaks
                    # sometimes dx[f]>3*np.median(qrspeakbuffer) is not noise peaks
                    beats += [int(f) + bpsi]
                else:
                    continue
                if bpe == 0:
                    rrinterval[indexrr] = beats[npeaks] - beats[npeaks - 1]
                    indexrr += 1
                    if indexrr == init_ecg:
                        indexrr = 0
                else:
                    if beats[npeaks] > beats[bpe - 1] + v100ms:
                        rrinterval[indexrr] = beats[npeaks] - beats[npeaks - 1]
                        indexrr += 1
                        if indexrr == init_ecg:
                            indexrr = 0
            elif dx[f] < 3. * np.median(qrspeakbuffer):
                beats += [int(f) + bpsi]
            else:
                continue
            npeaks += 1
            qrspeakbuffer[indexqrs] = dx[f]
            peak_idx_test[indexqrs] = f
            indexqrs += 1
            if indexqrs == init_ecg:
                indexqrs = 0

        if dx[f] <= DT:
            # 4 - not valid
            # 5 - If no QRS has been detected within 1.5 R-to-R intervals,
            # there was a peak that was larger than half the detection threshold,
            # and the peak followed the preceding detection by at least 360 ms,
            # classify that peak as a QRS complex
            tf = f + bpsi
            tfs.append(tf)
        else:
            invalid_rrinterval = rrinterval[np.where(rrinterval != 0)]
            if (len(invalid_rrinterval) == 0):
                RRM = sampling_rate
            else:
                RRM = np.mean(rrinterval[np.where(rrinterval != 0)])  # initial values are good?
            for tf in tfs:
                if len(beats) >= 2:

                    elapsed = f - beats[npeaks - 2]
                    elapsed1 = tf - beats[npeaks - 2]
                    if elapsed >= 1.5 * RRM and elapsed > TH_elapsed and elapsed1 > TH_elapsed:
                        if dx[tf] > 0.5 * DT:
                            temp_beats = beats[npeaks - 1]
                            beats[npeaks - 1] = int(tf) + offset
                            beats += [temp_beats]
                            # beats += [int(f) + offset]
                            # RR INTERVALS
                            if npeaks > 0:
                                rrinterval[indexrr] = beats[npeaks] - beats[npeaks - 2]
                                indexrr += 1
                                if indexrr == init_ecg:
                                    indexrr = 0
                            npeaks += 1
                            qrspeakbuffer[indexqrs] = dx[tf]
                            peak_idx_test[indexqrs] = tf
                            indexqrs += 1
                            if indexqrs == init_ecg:
                                indexqrs = 0
                    else:
                        noisepeakbuffer[indexnoise] = dx[tf]
                        noise_idx[indexnoise] = tf
                        indexnoise += 1
                        if indexnoise == init_ecg:
                            indexnoise = 0
                else:
                    noisepeakbuffer[indexnoise] = dx[tf]
                    noise_idx[indexnoise] = tf
                    indexnoise += 1
                    if indexnoise == init_ecg:
                        indexnoise = 0
            tfs = []
        ANP = np.median(noisepeakbuffer)
        AQRSP = np.median(qrspeakbuffer)
        DT = ANP + 0.475 * (AQRSP - ANP)
    return beats

def findMajorPeaks(signal=None,beats=None,sampling_rate=500):
    """
    重新更正主波的位置
    :param signal:
    :param beats:
    :param sampling_rate:
    :return:
    """
    lim = int(np.ceil(0.2 * sampling_rate))
    length = len(signal)
    r_peaks=[]
    neg_r_peaks=[]  #有的导联QRS波主波方向向下
    r_beats = []
    neg_r_beats = []
    conclution_peaks = []
    AA=[]
    BB=[]
    waitlist=[]
    waitlist1=[]
    window=[]
    judge_window=[]
    sum_pos=0
    sum_neg=0
    sum_beats=0
    thres_ch = 0.85
    thres_s_r = 0.15
    adjacency = 0.05 * sampling_rate
    caiculus_area = int(0.04 * sampling_rate)
    if(caiculus_area<=3):
        caiculus_area=int(4)

    for i in beats:
        beatnow=i
        error = [False, False]

        if i - lim-caiculus_area < 0:
            window = signal[0:i + lim]
            add = 0
            add_judge=0
            judge_window=signal[0:i+lim+caiculus_area]

        elif i+lim+caiculus_area>length:
            window = signal[i - lim:length]
            add = i - lim
            add_judge=caiculus_area
            judge_window=signal[i-lim-caiculus_area:length]

        else:
            window = signal[i - lim:i + lim]
            judge_window = signal[i-lim-caiculus_area:i+lim+caiculus_area]
            add = i - lim
            add_judge=caiculus_area
        '''find_extrema()是common/tools.py的1065行函数。作用：找到信号的极值点
        '''
        w_peaks, _ = st.find_extrema(signal=window, mode='max')
        w_negpeaks, _ = st.find_extrema(signal=window, mode='min')
        zerdiffs = np.where(np.diff(window) == 0)[0]
        w_peaks = np.concatenate((w_peaks, zerdiffs))
        w_negpeaks = np.concatenate((w_negpeaks, zerdiffs))#,key=lambda x:[x[0]-abs(x[1]+add-beatnow)]
        try:
            POS_X_WEIGHT=(np.max(window[w_peaks])-np.min(window[w_peaks]))/100
            NEG_X_WEIGHT=(np.min(window[w_negpeaks])-np.max(window[w_negpeaks]))/100#,key=lambda x:[x[0]-POS_X_WEIGHT*abs(x[1]+add-beatnow)]
        except:
            POS_X_WEIGHT =0
            NEG_X_WEIGHT =0
        #,key=lambda x:[x[0]-NEG_X_WEIGHT*abs(x[1]+add-beatnow)]
        pospeaks = sorted(zip(window[w_peaks], w_peaks),key=lambda x:[x[0]-POS_X_WEIGHT*abs(x[1]+add-beatnow)], reverse=True)
        negpeaks = sorted(zip(window[w_negpeaks], w_negpeaks),key=lambda x:[x[0]-NEG_X_WEIGHT*abs(x[1]+add-beatnow)])
        pos_judge_flag=True
        sum_cir=0
        #将window改为judge_window
        #使用add_judge作相对坐标求取
        #问题样本有D2数据集2,16,预设解决方案有二，
        # 方案一：验证监测点附近是否出现连续多个点幅值与监测点一致的情况，设阈值为5，超过5则抛弃该监测点
        #方案二：调大监测域（高风险，低收益）
        while(pos_judge_flag):
            sum_cir+=1
            if(len(pospeaks)==0):
                break
            judge_area=[]
            if(pospeaks[0][1]-caiculus_area<0-add_judge):
                judge_area=judge_window[0:pospeaks[0][1]+caiculus_area+add_judge]
            elif(pospeaks[0][1]+caiculus_area+add_judge>=len(judge_window)):
                judge_area=judge_window[add_judge+pospeaks[0][1]-caiculus_area:]
            else:
                judge_area=judge_window[pospeaks[0][1]-caiculus_area+add_judge:pospeaks[0][1]+caiculus_area+add_judge]
            if(np.max(judge_area)>pospeaks[0][0]):
                pospeaks=pospeaks[1:]
                continue
            break
        sum_cir = 0
        neg_judge_flag = True
        while (neg_judge_flag):
            sum_cir =sum_cir+ 1
            if (len(negpeaks) == 0):
                break
            judge_area=[]
            if (negpeaks[0][1] - caiculus_area < 0):
                judge_area = window[0:negpeaks[0][1] + caiculus_area]
            elif (negpeaks[0][1] + caiculus_area >= len(judge_window)):
                judge_area = window[negpeaks[0][1] - caiculus_area:]
            else:
                judge_area = window[negpeaks[0][1] - caiculus_area:negpeaks[0][1] + caiculus_area]
            if (np.min(judge_area) < negpeaks[0][0]):
                negpeaks=negpeaks[1:]
                continue
            break
        try:
            twopeaks = [pospeaks[0]]
        except IndexError:
            twopeaks = []
        try:
            twonegpeaks = [negpeaks[0]]
        except IndexError:
            twonegpeaks = []
        pospeaks=sorted(pospeaks, reverse=True)
        negpeaks=sorted(negpeaks)
        sum_base_line = []
        sum_num = 0
        for i in range(len(pospeaks) - 1):
            if abs(beatnow-add - pospeaks[i + 1][1]) > adjacency:
                sum_num=sum_num+1
                sum_base_line.append(pospeaks[i+1][0])
        if (sum_num != 0):
            twopeaks.append((np.median(sum_base_line),0))
        try:
            posdiv = abs(twopeaks[0][0] - twopeaks[1][0])
        except IndexError:
            error[0] = True
        sum_base_line=[]
        sum_num=0.0
        for i in range(len(negpeaks) - 1):
            if abs(beatnow-add - negpeaks[i + 1][1]) > adjacency:
                sum_base_line.append(negpeaks[i + 1][0])
                sum_num=sum_num+1
        if(sum_num!=0):
            twonegpeaks.append((np.median(sum_base_line),0))
        try:
            negdiv = abs(twonegpeaks[0][0] - twonegpeaks[1][0])
        except IndexError:
            error[1] = True
        n_errors = sum(error)

        try:
            r_peaks.append(twopeaks[0][1]+add)
            AA.append(twopeaks[0][1] + add)
        except IndexError:
            try:
                r_peaks.append(twonegpeaks[0][1] + add)
            except IndexError:
                pass
        try:
            neg_r_peaks.append(twonegpeaks[0][1]+add)
            BB.append(twonegpeaks[0][1] + add)
        except IndexError:
            try:
                neg_r_peaks.append(twopeaks[0][1]+add)
            except IndexError:
                pass
        try:
            sum_beats=sum_beats+1
            if not n_errors:
                if posdiv > thres_ch * negdiv:
                    r_beats.append(twopeaks[0][1] + add)
                    sum_pos +=  1
                    if (negdiv <= 0 or negdiv < 0.5 * posdiv):
                        neg_r_peaks[-1] = twopeaks[0][1] + add
                elif(posdiv<=0 or posdiv<thres_s_r*negdiv):
                    sum_neg=sum_neg+1
                    r_peaks[-1]=twonegpeaks[0][1] + add
                    neg_r_beats.append(twonegpeaks[0][1] + add)
                else:
                    if(caiculus_area<2):
                        pass
                    else:
                        temp=np.max(window[twopeaks[0][1]:twopeaks[0][1]+caiculus_area])
                        if(window[twopeaks[0][1]]>=temp):
                            if(posdiv>0.5*negdiv):
                                waitlist.append((len(r_peaks)-1,twopeaks[0][1]+add,twonegpeaks[0][1]+add))
                                sum_pos=sum_pos+1
                            else:
                                sum_neg=sum_neg+1
                                r_peaks[-1]=twonegpeaks[0][1]+add
                                waitlist.append((len(r_peaks) - 1, twopeaks[0][1] + add, twonegpeaks[0][1] + add))
                        else:
                           r_peaks[-1]=twonegpeaks[0][1]+add
                    neg_r_beats.append(twonegpeaks[0][1] + add)
            elif n_errors == 2:
                if abs(twopeaks[0][1]) > abs(twonegpeaks[0][1]):
                    sum_pos += 1
                    r_beats.append(twopeaks[0][1] + add)
                else:
                    sum_neg = sum_neg+1
                    neg_r_beats.append(twonegpeaks[0][1] + add)
                    pass
            elif error[1]:
                sum_neg = sum_neg + 1
                neg_r_beats.append(twonegpeaks[0][1] + add)
            else:
                sum_pos += 1
                r_beats.append(twopeaks[0][1] + add)
                pass
        except IndexError:
            continue
    if(sum_pos>=sum_neg):
        for waittuple in waitlist:
            r_peaks[waittuple[0]]=waittuple[1]
        conclution_peaks=r_peaks
    else:
        for waittuple in waitlist:
            neg_r_peaks[waittuple[0]]=waittuple[2]
        conclution_peaks=neg_r_peaks
    return conclution_peaks

def judge_Bigeminy_Trigeminy(rpeaks=None):
    """ 二联律、三联律检验程序
          parameter：rpeaks:list
    """
    str=""
    diff1_peak=np.diff(rpeaks)
    diff2_peak=np.diff(diff1_peak)
    #limit=0.2
    limit=np.mean(diff2_peak)*0.2
    #print(diff2_peak)
    extrema = np.nonzero(diff2_peak < -limit)[0]
    extrema1 = np.nonzero(diff2_peak>limit)[0]
    extrema2 = np.nonzero(abs(diff2_peak)<=limit)[0]
    for index in extrema:
        diff2_peak[index]=-1
    for index in extrema1:
        diff2_peak[index]=1
    for index in extrema2:
        diff2_peak[index]=0
    for index in diff2_peak:
        str=str+np.str(diff2_peak[index])
    #print(str)
    result20=re.findall(r'0-11-11',str)
    result21=re.findall(r'-1-11-1-1',str)
    result30=re.findall(r'0-11-10',str)
    if(len(result30)!=0):#三联律
        return 3
    elif(len(result20)!=0 or len(result21)!=0):#二联律
        return 2
    return 1

def detect_test(rpeaks):
    #完全间尝代谢测试
    diff_peak1=np.diff(rpeaks)
    avg=np.mean(diff_peak1)
    for i in range(len(diff_peak1)-1):
        diff_peak1[i]=diff_peak1[i]+diff_peak1[i+1]
    test_set=np.where(diff_peak1<0.7*avg)
    if(len(test_set)==0):
        return False
    else:
        return True
def Translate_To_R_S(signal=None, peaks=None):
    '''区分R波的方向：
        :param signal: ECG信号
        :param peaks: Calibration_Major_Wave（）函数 ‘波校准’的返回值
        :return:    pos_peaks：波峰向上；
                    neg_peaks：波峰向下
    '''
    pos_peaks = []
    neg_peaks = []
    for peak in peaks:
        if (signal[peak] > np.mean(signal[peak - 5:peak + 5])):
            pos_peaks.append(peak)
        else:
            neg_peaks.append(peak)
    return pos_peaks, neg_peaks
def calc_corr(A, B): # 计算两个序列的相关系数
    lag = []
    pearsonrs = []
    pvalues = []
    result = pearsonr(A, B)
    lag.append(0)
    pearsonrs.append(result[0])
    pvalues.append(result[1])
    ###############不断进行右移，并记录所有参数
    C = B.copy()
    for i in range(20):
        C.insert(0, C.pop())
        result = pearsonr(A, C)
        lag.append(i + 1)
        pearsonrs.append(result[0])
        pvalues.append(result[1])
    ###############不断进行左移，并记录所有参数
    D = B.copy()
    for i in range(20):
        D.insert(len(D), D[0])
        D.remove(D[0])
        result = pearsonr(A, D)
        lag.append(-(i + 1))
        pearsonrs.append(result[0])
        pvalues.append(result[1])
    # print(max(pearsonrs))
    return max(pearsonrs)
def cluster(X):
    # 二维列表samples，内部还是列表
    def find_neighbor(j, x, eps):
        N = list()
        for i in range(x.shape[0]):
            # temp = np.sqrt(np.sum(np.square(x[j] - x[i])))  # 计算欧式距离,效果不好
            temp = calc_corr(x[j],x[i])
            # 如果距离小于eps
            if temp <= eps:
                # append用于在列表末尾添加新的对象
                N.append(i)
        # 返回邻居的索引
        return set(N)
    def DBSCAN(X, eps, min_Pts):
        k = -1 # 簇内核心样本4个，其实就是
        neighbor_list = []  # 用来保存每个数据的邻域
        omega_list = []  # 核心对象集合
        gama = set([x for x in range(len(X))])  # 初始时将所有点标记为未访问
        cluster = [-1 for _ in range(len(X))]  # 聚类
        for i in range(len(X)):
            neighbor_list.append(find_neighbor(i, X, eps))
            # 取倒数第一个进行if，如果大于设定的样本数，即为核心点
            if len(neighbor_list[-1]) >= min_Pts:
                omega_list.append(i)  # 将样本加入核心对象集合
        omega_list = set(omega_list)  # 转化为集合便于操作
        while len(omega_list) > 0:
            # 深复制gama
            gama_old = copy.deepcopy(gama)
            j = random.choice(list(omega_list))  # 随机选取一个核心对象
            # k计数，从0开始为第一个
            k = k + 1
            # 初始化Q
            Q = list()
            # 记录访问点
            Q.append(j)
            # 从gama中移除j,剩余未访问点
            gama.remove(j)
            while len(Q) > 0:
                # 将第一个点赋值给q
                q = Q[0]
                Q.remove(q)
                if len(neighbor_list[q]) >= min_Pts:
                    # &按位与运算符：参与运算的两个值,如果两个相应位都为1,则该位的结果为1,否则为0
                    delta = neighbor_list[q] & gama
                    deltalist = list(delta)
                    for i in range(len(delta)):
                        # 在Q中增加访问点
                        Q.append(deltalist[i])
                        # 从gama中移除访问点,剩余未访问点
                        gama = gama - delta
            # 原始未访问点-剩余未访问点=访问点
            Ck = gama_old - gama
            Cklist = list(Ck)
            for i in range(len(Ck)):
                # 类型为k
                cluster[Cklist[i]] = k
            # 剩余核心点
            omega_list = omega_list - Ck
        return cluster
# def read(filepath):
#     path_list = os.listdir(filepath)
#     path_list.sort()
#     first=[]
#     second=[]
#     third=[]
#     fourth=[]
#     i = -1
#     for name in path_list:
#         i = i+1
#         if i == 30:
#             break
#         batch = int(re.search(r"[D]\d+",name).group(0)[1:])
#         person = int(re.search(r"(_\d+)",name).group(1)[1:])
#         lead = int(re.search(r"(_\d+)(_\d+)",name).group(2)[1:])
#         wave = int(re.search(r"(_\d+)(_\d+)(_\d+)",name).group(3)[1:])
#         res=get_waveband(batch,person,lead,wave)
#         if len(res)>0:
#             path = data + 'D{}_{}.npy'.format(batch, person)
#             numpy_file = np.load(path, allow_pickle=True)[0]
#             peaks = Calibration_Major_Wave(numpy_file)
#             ECG_SIGNER = numpy_file[lead]
#             dec = wave_decom("Symmlets" + str(lead))
#             clearSignal = dec.plot_I(ECG_SIGNER)
#             clearSignal = baseline_lowpass(clearSignal)
#             y = []
#             for i in range(peaks[lead][wave] - 50, peaks[lead][wave] + 50, 1):
#                 y.append(clearSignal[i])
#             for i in range(len(res)):
#                 if i == 0 and len(res) >= 1:
#                     for v in res[0]:
#                         first.append(y[v])
#                 if i == 1 and len(res) >= 2:
#                     for v in res[1]:
#                         second.append(y[v])
#
class HMM:# 废弃了，直接使用hmmlearn库
    def forward(self,Q,V,A,B,O,PI): # 前向算法
        N = len(Q) # 状态序列大小
        M = len(O) # 观测序列大小
        alphas = np.zeros((N,M))
        T = M # 有几个观测序列就有几个时刻
        for t in range(T):
            indexOfO = V.index(O[t]) # 找出序列对应的索引
            for i in range(N):
                if t == 0: # 计算初值
                    alphas[i][t] = PI[t][i] * B[i][indexOfO] # P176(10.15)
                    # print('alpha1(%d)=p%db%db(o1)=%f' % (i, i, i, alphas[i][t]))
                else:
                    alphas[i][t] = np.dot([alpha[t-1] for alpha in alphas],[a[i] for a in A]) * B[i][indexOfO]
                    # print('alpha%d(%d)=[sigma alpha%d(i)ai%d]b%d(o%d)=%f' % (t, i, t - 1, i, i, t, alphas[i][t]))
        P = np.sum([alpha[M-1] for alpha in alphas])
    def backward(self,Q,V,A,B,O,PI): # 后向
        N = len(Q)
        M = len(O)
        betas = np.ones((N,M))
        for i in range(N):
            print('beta%d(%d)=1' % (M, i))
        for t in range(M-2,-1,-1):
            indexOfO = V.index(O[t+1])
            for i in range(N):
                betas[i][t] = np.dot(np.multiply(A[i],[b[indexOfO] for b in B]) , [beta[t+1] for beta in betas])
                realT = t+1
                realI = i+1
                # print('beta%d(%d)=[sigma a%djbj(o%d)]beta%d(j)=(' % (realT, realI, realI, realT + 1, realT + 1),
                #       end='')
                for j in range(N):
                    print("%.2f*%.2f*%.2f+" % (A[i][j], B[j][indexOfO], betas[j][t + 1]), end='')
                print("0)=%.3f" % betas[i][t])

        indexOfO = V.index(O[0])
        P = np.dot(np.multiply(PI,[b[indexOfO] for b in B]),[beta[0] for beta in betas])
        # print("P(O|lambda)=", end="")
        for i in range(N):
            print("%.1f*%.1f*%.5f+" % (PI[0][i], B[i][indexOfO], betas[i][0]), end="")
        print("0=%f" % P)
    def viterbi(self,Q,V,A,B,O,PI):
        N = len(Q)
        M = len(O)
        deltas = np.zeros((N,M))
        psis = np.zeros((N,M))
        I = np.zeros((1,M))
        for t in range(M):
            realT = t+1
            indexOfO = V.index(O[t]) # 找出序列对应的索引
            for i in range(N):
                realI = i+1
                if t == 0:
                    deltas[i][t] = PI[0][i] * B[i][indexOfO]
                    psis[i][t] = 0
                    print('delta1(%d)=pi%d * b%d(o1)=%.2f * %.2f=%.2f'
                          %(realI, realI, realI, PI[0][i], B[i][indexOfO], deltas[i][t]))
                    print('psis1(%d)=0' % (realI))
                else:
                    deltas[i][t] = np.max(np.multiply([delta[t-1] for delta in deltas], [ a[i] for a in A])) * B[i][indexOfO]
                    print('delta%d(%d)=max[delta%d(j)aj%d]b%d(o%d)=%.2f*%.2f=%.5f'
                          % (realT, realI, realT - 1, realI, realI, realT,
                             np.max(np.multiply([delta[t - 1] for delta in deltas], [a[i] for a in A])), B[i][indexOfO],deltas[i][t]))
                    psis[i][t] = np.argmax(np.multiply([delta[t - 1] for delta in deltas], [a[i] for a in A]))
                    # print('psis%d(%d)=argmax[delta%d(j)aj%d]=%d' % (realT, realI, realT - 1, realI, psis[i][t]))
        print(deltas)
        print(psis)
        I[0][M-1] = np.argmax([delta[M-1] for delta in deltas])
        print('i%d=argmax[deltaT(i)]=%d' % (M, I[0][M-1]+1))
        for t in range(M-2, -1, -1):
            I[0][t] = psis[int(I[0][t+1])][t+1]
            print('i%d=psis%d(i%d)=%d' % (t+1, t+2, t+2, I[0][t]+1))
        print(I)