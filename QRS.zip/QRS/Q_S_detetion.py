#Q\S波检测
from common import *
from extract_wave.QRS_Classfiy import *
import numpy as np
from scipy import signal
import time
import matplotlib.pyplot as plt
import os
from sympy.stats import Rayleigh,density
import math
from sklearn.metrics import mean_squared_error

# str1表示数据文件路径，通过index修改对应数据文件
index=1

str1 = 'C:/Users/Laplace/Desktop/data/generated_data/datas123/D1_1.npy'

numpy_file = np.load(str1,allow_pickle=True)[0]   #list列表，12导联的ECG信号  allow_pickle:允许使用pickles保存对象数组，pickle 用于在保存到磁盘文件或从磁盘文件读取之前，对对象进行序列化和反序列化。
sampling_rate=float(500)

peaks=Calibration_Major_Wave(numpy_file)    #12导联的心拍位置索引
# print('I导联心拍位置索引',peaks[0])

list1 = QRS_Classfiy_new(numpy_file)
# print(list1)

def show(array,q_s):
    """

    :param array: 信号
    :param q_s: q和s点的横坐标
    :return:
    """
    for i in range(0,12):   # i 表示导联
        print(f'{index}.npy | 第{i+1}导联')
        list_temp = []  # 用于存储一个导联的所有数据
        ECG_SIGNER = array[i]
        ori_data = ECG_SIGNER
        dec = wave_decom("Symmlets" + str(1))
        clearSignal = dec.plot_I(ori_data)  # 去噪

        # subplot一次显示多张图：subplot(numRows行数, numCols列数, plotNum索引值)
        plt.subplot(2,1,1)
        plt.title("NO." + str(index) + "." + str(i+1))
        plt.plot(range(0, len(ori_data)), ori_data, 'b', label='EKG')
        # for flag in list1[i]:
        #     plt.plot(flag[0][4],ori_data[flag[0][4]],'.')

        for flag in peaks[i]:
            plt.plot(flag, ori_data[flag], '.')

        plt.subplot(2,1,2)
        plt.plot(range(0,len(clearSignal)),clearSignal)

        for flag in peaks[i]:
            plt.plot(flag, clearSignal[flag], '.')


        for flag1 in q_s[i]:

            plt.plot(flag1[0], clearSignal[flag1[0]], '.')
            plt.plot(flag1[1], clearSignal[flag1[1]], '.')
        # for flag in list1[i]:
        #     plt.plot(flag[0][4], clearSignal[flag[0][4]], '.')  # R点
        #     # plt.plot(flag[0][3],clearSignal[flag[0][3]],'.')   # Q 点
        #     # plt.plot(flag[0][-1], clearSignal[flag[0][-1]], '.')  #  S 点
        plt.show()

def Q_S_pos(array,peaks):
    """
    求Q和S点可能位置
    :param array:
    :param peaks:
    :return:
    """
    Q_temp = []  #  存放Q点索引
    for i in range(12):

        ECG_SIGNER = array[i]
        dec = wave_decom("Symmlets" + str(1))
        ECG_SIGNER = dec.plot_I(ECG_SIGNER)  # 去噪

        q_s_temp = []
        for num in peaks[i]:
            temp_q = []
            temp_s = []
            if num >0:  # 正向

                q_pos = signal.argrelextrema(ECG_SIGNER[num-50:num-15], np.less)  # 求R点前50个到R点的极小值，返回的是此序列的索引值
                if len(q_pos[0])==0:
                    p = num-50
                    while ECG_SIGNER[p] == ECG_SIGNER[p+1]:
                        p +=1
                    temp_q.append(p) # 要加上初始点的索引
                else:
                    for j in q_pos[0]:
                        temp_q.append(j+num-50) # 要加上初始点的索引

                s_pos = signal.argrelextrema(ECG_SIGNER[num+20:num+100], np.less)  # 求R点后50个到R点的极小值，返回的是此序列的索引值

                if len(s_pos[0])==0:
                    q = num+100
                    while ECG_SIGNER[q]== ECG_SIGNER[q-1]:
                        q -=1
                    temp_s.append(q) # 要加上初始点的索引
                else:
                    for j in s_pos[0]:
                        if (ECG_SIGNER[j + num + 25] - ECG_SIGNER[j + num + 20] > 0.001):
                            temp_s.append(j+num+20) # 要加上初始点的索引
                    if len(temp_s)==0:
                        q = num + 100
                        while ECG_SIGNER[q] == ECG_SIGNER[q - 1]:
                            q -= 1
                        temp_s.append(q)  # 要加上初始点的索引

            else:  # 负向

                q_pos = signal.argrelextrema(ECG_SIGNER[num - 50:num-15], np.greater)  # 求R点前30个到R点的极小值，返回的是此序列的索引值
                if len(q_pos[0]) == 0:
                    p = num - 50
                    while ECG_SIGNER[p] == ECG_SIGNER[p + 1]:
                        p += 1
                    temp_q.append(p)  # 要加上初始点的索引
                else:
                    for j in q_pos[0]:
                        temp_q.append(j + num - 50)  # 要加上初始点的索引

                s_pos = signal.argrelextrema(ECG_SIGNER[num+20 :num+100], np.greater)  # 求R点前30个到R点的极小值，返回的是此序列的索引值
                if len(s_pos[0]) == 0:
                    q = num + 100
                    while ECG_SIGNER[q] == ECG_SIGNER[q - 1]:
                        q -= 1
                    temp_s.append(q)  # 要加上初始点的索引
                else:
                    for j in s_pos[0]:
                        if (ECG_SIGNER[j + num + 25] - ECG_SIGNER[j + num + 20] < -0.001):
                            temp_s.append(j + num+20)  # 要加上初始点的索引
                    if len(temp_s)==0:
                        q = num + 100
                        while ECG_SIGNER[q] == ECG_SIGNER[q - 1]:
                            q -= 1
                        temp_s.append(q)  # 要加上初始点的索引

            q_s_temp.append([temp_q,temp_s])
        Q_temp.append(q_s_temp)
    return Q_temp

def detect_Q_S(array):
    """
    :param array: 输入包含Q和S 点的序列
    :return: q点和s点横坐标
    """
    Q_S_position = []
    for i in range(12):
        q_s_pos = []
        for array1 in array[i]:
            if len(array1[0])==0:  # 如果没有q点，即集合为空，将其设为0
                q_pos = 0
            else:
                q_pos = max(array1[0])

            if len(array1[1])==0:
                s_pos = 0
            else:
                s_pos = min(array1[1])

            q_s_pos.append([q_pos,s_pos])

        Q_S_position.append(q_s_pos)

    return Q_S_position



if __name__ == '__main__':
    q_position = Q_S_pos(numpy_file,peaks)
    q_s = detect_Q_S(q_position)
    print(q_s)
    print(len(q_s))
    print(q_s[0][1])


