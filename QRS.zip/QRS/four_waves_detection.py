from QRS_Classfiy import *
import numpy as np
import matplotlib.pyplot as plt
import math
from sklearn.metrics import mean_squared_error
import os
import re
data = r'data/generated_data/datas123/'
# data = 'E:\ECG\\related_QRS\data\\batch_source_data\data123\\4000_第二批_204\\'
sampling_rate=float(500)
def Gaussian(x,u,sigma2):
    """
    :param data: 输入
    :param u: 位置参数
    :param sigma2: 方差
    :return: 高斯分布
    """
    prob = 1/np.power(2*math.pi*sigma2,1/2)
    ret=prob*np.exp(-(x-u)**2)/(2*sigma2)

    return ret
def Rayleigh_(x,lameda):
    """
    :param x: 输入
    :param lameda: 位置参数
    :return:
    """
    tem = x/(lameda**2)
    tem2 = (-x**2)/(2*lameda**2)
    ret = np.exp(tem2)
    ret = tem*ret
    return ret
def Mexican_Hat(x,sigma):
    """
    :param x: 输入
    :param sigma: 位置参数
    :return:
    """
    tem = (-x ** 2) / (2 * sigma ** 2)

    tem2 = 1-(x/sigma)**2
    tem3 = 2/(((3*sigma)**(1/2))*((math.pi)**1/4))

    ret = tem3*tem2*np.exp(tem)
    return ret
# def normalize(array):
#     """
#     :param list1: 列表
#     :return: 归一化的列表
#     """
#     ret = []
#     if array is not None:
#         max_num = max(array)
#         min_num = min(array)
#         if max_num == min_num:
#             return array
#         else:
#             for num in array:
#                 ret.append((num - min_num)/(max_num-min_num))
#     return ret
def normalize(array):
    """
    :param list1: 列表
    :return: 归一化的列表
    """
    ret = []
    if array is not None:
        max_num = max(array)
        min_num = min(array)
        if max_num == min_num:
            return array
        else:
            for num in array:
                ret.append(2*(num - min_num)/(max_num-min_num)-1)
    return ret
def modelI(fun_len_A,fun_len_B,u,sigma2_A,sigma2_B):
    """
    画图出来就像是R波
    :param fun_len_A: A函数的长度
    :param fun_len_B: B函数的长度
    :param u:  位置参数，默认为0
    :param sigma2_A: 函数A的sigma2
    :param sigma2_B: 函数B的sigma2
    :return: 组合后的y值。
    """
    x_A = []
    y_A = []
    x_B = []
    y_B = []
    adsfa = []
    for i in range(-int(fun_len_A / 2), int(fun_len_A / 2)):
        x_A.append(i)
        y_A.append(Gaussian(i, u, sigma2_A))

    for i in range(-int(fun_len_B / 2), int(fun_len_B / 2)):
        x_B.append(i)
        y_B.append(Gaussian(i, u, sigma2_B))

    for i, num in enumerate(y_B):
        y_B[i] = num * (max(y_A) / max(y_B))
    max_index_A = y_A.index(max(y_A))
    max_idnex_B = y_B.index(max(y_B))

    model_ret = y_A[:max_index_A]
    model_ret += y_B[max_idnex_B:]
    model_ret = normalize(model_ret)

    # 测试波形
    # for i in range(int(fun_len_A / 2) + int(fun_len_B / 2)):
    #     adsfa.append(i)
    # plt.plot(adsfa, model_ret)
    # plt.show()
    return model_ret,max_index_A
# modelI(40,70,0,10,7)
def modelII(fun_len_A, fun_len_B, lameda_A, lameda_B):
    """
    qRs
    :param fun_len_A: A函数的长度
    :param fun_len_B: B函数的长度
    :param lameda_A: 函数A的lameda
    :param lameda_B: 函数B的lameda
    :return: 组合后的y值。
    """
    x_A = []
    y_A = []
    x_B = []
    y_B = []
    adsfa = []
    for i in range(-int(fun_len_A / 2), int(fun_len_A / 2)):
        x_A.append(i)
        y_A.append(Mexican_Hat(i, lameda_A))

    for i in range(-int(fun_len_B / 2), int(fun_len_B / 2)):
        x_B.append(i)
        y_B.append(Mexican_Hat(i,lameda_B))


    for i, num in enumerate(y_B):
        y_B[i] = num * (max(y_A) / max(y_B))
    max_index_A = y_A.index(max(y_A))
    max_idnex_B = y_B.index(max(y_B))

    model_ret = y_A[:max_index_A]
    model_ret+=y_B[max_idnex_B:]
    model_ret = normalize(model_ret)

   # 测试波形
   #  for i in range(len(model_ret)):
   #      adsfa.append(i)
   #  plt.plot(adsfa, model_ret)
   #  plt.show()
    return model_ret,max_index_A
# modelII(50,50,5,7)
def model_III(fun_len_A, fun_len_B, lameda_A,lameda_B):
    """
    RS
    :param fun_len_A:
    :param fun_len_B:
    :param lameda_A:
    :param lameda_B:
    :return:
    """
    x_A = []
    y_A = []
    x_B = []
    y_B = []
    adsfa = []

    for i in range(fun_len_A):
        x_A.append(i)
        y_A.append(Rayleigh_(i, lameda_A**2))

    for i in range(fun_len_B):
        x_B.append(i)
        y_B.append((-1)*Rayleigh_(i, lameda_B**2))

    max_A_index = y_A.index(max(y_A))
    min_B_index = y_B.index(min(y_B))

    model_ret = y_A[:max_A_index]

    for k in range(max_A_index,fun_len_A):
        if(y_A[k]!=0):
            model_ret.append(y_A[k])
        else:
            break


    for k in range(min_B_index):
        if(y_B[k]!=0):
            model_ret.append(y_B[k])

    model_ret+=y_B[min_B_index:]

    model_ret = normalize(model_ret)
    # 打印图形
    # for i in range(len(model_ret)):
    #     adsfa.append(i)
    # plt.plot(adsfa, model_ret)
    # plt.show()
    # print(model_ret)
    return model_ret,max_A_index
# model_III(40,70,3,5)
def model_IV(fun_len_A, fun_len_B, lameda_A,lameda_B):
    """
    QR
    :param fun_len_A:
    :param fun_len_B:
    :param lameda_A:
    :param lameda_B:
    :return:
    """
    x_A = []
    y_A = []
    x_B = []
    y_B = []
    adsfa = []

    for i in range(fun_len_A):
        x_A.append(i)
        y_A.append((-1)*Rayleigh_(i, lameda_A ** 2))

    for i in range(fun_len_B):
        x_B.append(i)
        y_B.append(Rayleigh_(i, lameda_B ** 2))

    min_A_index = y_A.index(min(y_A))
    max_B_index = y_B.index(max(y_B))

    model_ret = y_A[:min_A_index]
    for k in range(min_A_index, fun_len_A):
        if (y_A[k] != 0):
            model_ret.append(y_A[k])
        else:
            break
    for k in range(max_B_index):
        if (y_B[k] != 0):
            model_ret.append(y_B[k])

    model_ret += y_B[max_B_index:]
    model_ret = normalize(model_ret)
    # for i in range(len(model_ret)):
    #     adsfa.append(i)
    # plt.plot(adsfa, model_ret)
    # plt.show()
    # print(model_ret)
    return model_ret,max_B_index
# model_IV(40,70,3,5)
def model_V(fun_len_A, fun_len_B, lameda_A,lameda_B):
    """
    RSR`
    :param fun_len_A:
    :param fun_len_B:
    :param lameda_A:
    :param lameda_B:
    :return:
    """
    x_A = []
    y_A = []
    x_B = []
    y_B = []
    adsfa = []

    for i in range(fun_len_A):
        x_A.append(i)
        y_A.append(Rayleigh_(i, lameda_A ** 2))

    for i in range(fun_len_B):
        x_B.append(i)
        y_B.append(Rayleigh_(i, lameda_B ** 2))

    max_A_index = y_A.index(max(y_A))
    max_B_index = y_B.index(max(y_B))
    model_ret = y_A[:max_A_index]

    for k in range(max_A_index, fun_len_A):
        if (y_A[k] != 0):
            model_ret.append(y_A[k])
        else:
            break

    for k in range(max_B_index):
        if (y_B[k] != 0):
            model_ret.append(y_B[k])

    model_ret += y_B[max_B_index:]
    model_ret = normalize(model_ret)
    # for i in range(len(model_ret)):
    #     adsfa.append(i)
    # plt.plot(adsfa, model_ret)
    # plt.show()
    # print(model_ret)
    if max_B_index>max_A_index:
        max_A_index = max_B_index
    return model_ret, max_A_index
# model_V(40,60,3,5)
def Morphological_Classification(nun1=0,nun2=0,nun3=0,nun4=0,nun5=0,file=r'data/generated_data/datas123/',
                                 name=0,batch=1 , person=1 , lead=0, wave=4, sample_frequency=500):
    """
    :param array: 信号
    :param q_s: q和s点的横坐标
    :param peaks: R点的横坐标
    :param lead: 第几个导联
    :param wave: 第几个波
    :param sample_frequency: 采样率
    :return:
    """

    # path = file  + 'D{}_{}.npy'.format(batch,person)

    path = file  + 'D{}_{}.npy'.format(batch,person)
    numpy_file = np.load(path, allow_pickle=True)[0]

    peaks = Calibration_Major_Wave(numpy_file)  # 所有导联的R波位置，第一个和最后一个不要

    R_index = peaks[lead][wave]  # R波位置
    cut_len = sample_frequency*0.2  # 取一百个点
    R_form_num = cut_len*0.45  #  向前取45个
    R_last_num = cut_len*0.55  # 向后取55个
    min_Init = 10  # 均方误差最小值
    min_flag = -1  # 最小均方误差标志位

    ECG_SIGNER = numpy_file[lead]
    dec = wave_decom("Symmlets" + str(1))
    clearSignal = dec.plot_I(ECG_SIGNER)  # 去噪

    data = clearSignal[R_index-int(R_form_num):R_index+int(R_last_num)]
    w = len(data)  # w长度
    # w_range = [0.5*w,0.7*w,1.1*w,1.3*w,1.5*w,1.7*w,1.9*w,2*w]  # 函数A,B所取的长度
    w_range = [0.7*w,1.1*w,1.4*w,1.7*w,2*w]  # 函数A,B所取的长度
    # para = list(np.arange(0.5,10.5,0.5))  # sigma2的取值 和 lameda的取值
    # para.insert(0, 0.1)
    para = list(np.arange(5,8,0.6))  # sigma2的取值 和 lameda的取值
    u = 0  #  u的取值

    for fun_len_A in w_range:
        for fun_len_B in w_range:
            for sigma2_A in para:
                lameda_A = sigma2_A
                for sigma2_B in para:
                    lameda_B = sigma2_B
                    min_temp= []  #  临时存储均方误差
                    QRS_Test = []
                    model1_temp,max_index = modelI(fun_len_A,fun_len_B,u,sigma2_A,sigma2_B)
                    for k in range(len(model1_temp)):
                        QRS_Test.append(clearSignal[R_index-max_index+k])
                        QRS_Test = normalize(QRS_Test)
                    model_I_mse = mean_squared_error(model1_temp, QRS_Test)
                    min_temp.append(model_I_mse)
                    QRS_Test.clear()

                    model2_temp, max_index =  modelII(int(fun_len_A), int(fun_len_B), lameda_A, lameda_B)
                    for k in range(len(model2_temp)):
                        QRS_Test.append(clearSignal[R_index - max_index + k])
                        QRS_Test = normalize(QRS_Test)
                    model_II_mse = mean_squared_error(model2_temp, QRS_Test)
                    min_temp.append(model_II_mse)
                    QRS_Test.clear()

                    model3_temp,max_index = model_III(int(fun_len_A),int(fun_len_B),lameda_A,lameda_B)
                    for k in range(len(model3_temp)):
                        QRS_Test.append(clearSignal[R_index - max_index + k])
                        QRS_Test = normalize(QRS_Test)
                    model_III_mse = mean_squared_error(model3_temp, QRS_Test)
                    min_temp.append(model_III_mse)
                    QRS_Test.clear()

                    model4_temp, max_index = model_IV(int(fun_len_A), int(fun_len_B), lameda_A, lameda_B)
                    for k in range(len(model4_temp)):
                        QRS_Test.append(clearSignal[R_index - max_index + k])
                        QRS_Test = normalize(QRS_Test)
                    model_IV_mse = mean_squared_error(model4_temp, QRS_Test)
                    min_temp.append(model_IV_mse)
                    QRS_Test.clear()

                    model5_temp, max_index = model_V(int(fun_len_A), int(fun_len_B), lameda_A, lameda_B)
                    for k in range(len(model5_temp)):
                        QRS_Test.append(clearSignal[R_index - max_index + k])
                        QRS_Test = normalize(QRS_Test)
                    model_V_mse = mean_squared_error(model5_temp, QRS_Test)
                    min_temp.append(model_V_mse)

                    if(min_Init>min(min_temp)):
                        min_Init = min(min_temp)
                        min_flag = min_temp.index(min(min_temp))

    # print(min_flag,min_Init)
    if(min_flag==0):
        nun1+=1
        print("波形为R波，均方误差为：{}".format(min_Init))
    elif min_flag==1:
        nun2+=1
        print("波形为qRs波，均方误差为：{}".format(min_Init))
    elif min_flag==2:
        nun3+=1
        print("波形为RS，均方误差为：{}".format(min_Init))
    elif min_flag == 3:
        nun4+=1
        print("波形为QR，均方误差为：{}".format(min_Init))
    elif min_flag == 4:
        nun5+=1
        print("波形不确定，均方误差为：{}".format(min_Init))
    # plt.plot(range(0, w), data,label=name)
    # plt.show()
    return nun1,nun2,nun3,nun4,nun5

def batch_test(path):
    nun1 = 0
    nun2 = 0
    nun5 = 0
    nun3 = 0
    nun4 = 0
    path_list = os.listdir(path)
    path_list.sort()
    # num = 134
    for name in path_list:
    # for i in range(110):
    #     name = path_list[num+i]
        res0 = int(re.search(r"[D]\d+",name).group(0)[1:])
        res1 = int(re.search(r"(_\d+)", name).group(1)[1:])
        res2 = int(re.search(r"(_\d+)(_\d+)", name).group(2)[1:])
        res3 = int(re.search(r"(_\d+)(_\d+)(_\d+)", name).group(3)[1:])
        nun1,nun2,nun3,nun4,nun5, = Morphological_Classification(nun1,nun2,nun3,nun4,nun5,data,name,res0,res1,res2,res3)
        # print(name,res0,res1,res2,res3
    print("R波数量：",nun1,"qRs波数量：",nun2,"RS波数量：",nun3,"QR波数量：",nun4,"波形不确定：",nun5)

def read_npy(path):
    qRs_data = np.load(path)
    print(qRs_data.shape)
    x= []
    for i in range(100):
        x.append(i)
    for y in qRs_data:
        plt.plot(x,y)
        plt.show()
    print(qRs_data)

def Morphological_Classification2(nun1,nun2,nun3,nun4,nun5,file,name, sample_frequency=500):
    """
    :param array: 信号
    :param q_s: q和s点的横坐标
    :param peaks: R点的横坐标
    :param lead: 第几个导联
    :param wave: 第几个波
    :param sample_frequency: 采样率
    :return:
    """
    R_index = 150  # R波位置
    min_Init = 10  # 均方误差最小值
    min_flag = -1  # 最小均方误差标志位

    clearSignal = file
    data = clearSignal[400:500]
    w = len(data)  # w长度
    # w_range = [0.5*w,0.7*w]  # 函数A,B所取的长度
    w_range = [0.7*w,1.1*w,1.4*w,1.7*w,2*w]  # 函数A,B所取的长度
    # para = list(np.arange(0.5,10.5,0.5))  # sigma2的取值 和 lameda的取值
    # para.insert(0, 0.1)
    para = list(np.arange(2,8,0.6))  # sigma2的取值 和 lameda的取值
    u = 0  #  u的取值

    for fun_len_A in w_range:
        for fun_len_B in w_range:
            for sigma2_A in para:
                lameda_A = sigma2_A
                for sigma2_B in para:
                    lameda_B = sigma2_B
                    min_temp= []  #  临时存储均方误差
                    QRS_Test = []
                    model1_temp,max_index = modelI(fun_len_A,fun_len_B,u,sigma2_A,sigma2_B)
                    for k in range(len(model1_temp)):
                        QRS_Test.append(clearSignal[R_index-max_index+k])
                        QRS_Test = normalize(QRS_Test)
                    model_I_mse = mean_squared_error(model1_temp, QRS_Test)
                    min_temp.append(model_I_mse)
                    QRS_Test.clear()

                    model2_temp, max_index =  modelII(int(fun_len_A), int(fun_len_B), lameda_A, lameda_B)
                    for k in range(len(model2_temp)):
                        QRS_Test.append(clearSignal[R_index - max_index + k])
                        QRS_Test = normalize(QRS_Test)
                    model_II_mse = mean_squared_error(model2_temp, QRS_Test)
                    min_temp.append(model_II_mse)
                    QRS_Test.clear()

                    model3_temp,max_index = model_III(int(fun_len_A),int(fun_len_B),lameda_A,lameda_B)
                    for k in range(len(model3_temp)):
                        QRS_Test.append(clearSignal[R_index - max_index + k])
                        QRS_Test = normalize(QRS_Test)
                    model_III_mse = mean_squared_error(model3_temp, QRS_Test)
                    min_temp.append(model_III_mse)
                    QRS_Test.clear()

                    model4_temp, max_index = model_IV(int(fun_len_A), int(fun_len_B), lameda_A, lameda_B)
                    for k in range(len(model4_temp)):
                        QRS_Test.append(clearSignal[R_index - max_index + k])
                        QRS_Test = normalize(QRS_Test)
                    model_IV_mse = mean_squared_error(model4_temp, QRS_Test)
                    min_temp.append(model_IV_mse)
                    QRS_Test.clear()

                    model5_temp, max_index = model_V(int(fun_len_A), int(fun_len_B), lameda_A, lameda_B)
                    for k in range(len(model5_temp)):
                        QRS_Test.append(clearSignal[R_index - max_index + k])
                        QRS_Test = normalize(QRS_Test)
                    model_V_mse = mean_squared_error(model5_temp, QRS_Test)
                    min_temp.append(model_V_mse)

                    if(min_Init>min(min_temp)):
                        min_Init = min(min_temp)
                        min_flag = min_temp.index(min(min_temp))

    # print(min_flag,min_Init)
    if(min_flag==0):
        nun1+=1
        print(name,":波形为R波，均方误差为：{}".format(min_Init))
    elif min_flag==1:
        nun2+=1
        print(name,":波形为qRs波，均方误差为：{}".format(min_Init))
    elif min_flag==2:
        nun3+=1
        print(name,":波形为RS，均方误差为：{}".format(min_Init))
    elif min_flag == 3:
        nun4+=1
        print(name,":波形为QR，均方误差为：{}".format(min_Init))
    elif min_flag == 4:
        nun5+=1
        print(name,":波形不确定，均方误差为：{}".format(min_Init))
    # plt.plot(range(0, w), data,label=name)
    # plt.show()
    return nun1,nun2,nun3,nun4,nun5
def batch_test2(path):
    nun1 = 0
    nun2 = 0
    nun5 = 0
    nun3 = 0
    nun4 = 0
    path_list = np.load(path)
    for name,file in enumerate(path_list):
        file = list(file)
        for i in range(400):
            file.insert(0,file[0])
            file.append(file[-1])
        nun1,nun2,nun3,nun4,nun5, = Morphological_Classification2(nun1,nun2,nun3,nun4,nun5,file,name)
        # print(name,res0,res1,res2,res3
    print("R波数量：",nun1,"qRs波数量：",nun2,"RS波数量：",nun3,"QR波数量：",nun4,"波形不确定：",nun5)

# if __name__ == '__main__':
#     # Morphological_Classification(data,"D1_14_4_6",1,61,7,2)
#     batch_test(r"D:\心电图项目\Realize_QRS\result\Rs")
#
#     # batch_test2(r"E:\ECG\\related_QRS\\test_case\波形\Rs.npy")
#     # read_npy(read_npy("E:\ECG\\related_QRS\\test_case\波形\qRs.npy"))
#     pass

