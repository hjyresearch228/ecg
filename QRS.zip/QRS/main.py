import numpy as np
import random
from numpy.linalg import *
from common import *
from scipy import signal
import pandas as pd
import copy
from QRS_Analysis import FSM_QRS
from QRS_Classfiy import *
import matplotlib.pyplot as plt
from pyts.transformation import ShapeletTransform
from four_waves_detection import Morphological_Classification
from sklearn.svm import LinearSVC
from sklearn.pipeline import make_pipeline
from QRS_Analysis import fitting_curve
import networkx as nx
from plot import plot_QRS
from hmmlearn import hmm
from scipy.stats import pearsonr
import re
import os
from sklearn.cluster import DBSCAN
import warnings
warnings.filterwarnings("ignore")
plt.rcParams['font.sans-serif'] = ['SimHei']	# 显示中文
plt.rcParams['axes.unicode_minus'] = False		# 显示负号
data = r'data/generated_data/datas123/'

def dtw(s1 , s2): # s1和s2序列的相似性，没有互相关系数效果好
    l1 = len(s1)
    l2 = len(s2)
    paths = np.full((l1 + 1, l2 + 1), np.inf)  # 全部赋予无穷大
    paths[0, 0] = 0
    for i in range(l1):
        for j in range(l2):
            d = s1[i] - s2[j]
            cost = d ** 2
            paths[i + 1, j + 1] = cost + min(paths[i, j + 1], paths[i + 1, j], paths[i, j])
    paths = np.sqrt(paths)
    s = paths[l1, l2]
    return s # 相似性
def fitting_curve(X , Y):
    '''
    最小二乘法拟合抛物线
    :param X: 5个值的一维列表，以极值点为中心
    :param Y: 点对应的电压
    '''
    n = len(X)
    m = 2  # 求m次方多项式, m<=n
    A = np.zeros((m + 1, m + 1))  # 创建零数组
    B = np.zeros((m + 1, 1))
    for i in range(m + 1):
        y = 0
        for j in range(m + 1):
            if i == 0 and j == 0:
                A[0][0] = n
            else:
                x = 0
                for s in range(n):
                    x += X[s] ** (i + j)
                A[i][j] = x
        for s in range(n):
            y += X[s] ** (i) * Y[s]
        B[i][0] = y
    result = solve(A, B)

    # print('X^2项的系数：', result[2][0])
    # print('X项的系数：', result[1][0])
    # print('常数项系数：',result[0][0])

    # print('拟合曲线方程为：y = {} * x^2 + {} * x + {}'.format(result[2][0] , result[1][0] , result[0][0]))

    # 计算曲率 K = abs(y'') / (1+y'^2)^1.5
    firstDerivative = 2 * result[2][0] * X[2] + result[1][0]   # 一阶导数 y' = 2ax + b
    secondDerivative = 2 * result[2][0]  # 二阶导数 y'' = 2a
    k = abs(secondDerivative) / math.pow( (1+firstDerivative * firstDerivative), 1.5)
    # print('曲率k为：',k)
def get_probalities():
    # 基于统计求出 初始分布PI、转移概率A
    # RS波350个；qRs波300个；qRsr'和rSr'波各200个；Qr，QS，R和rS波各150个；qR，Rs和qrs波各100个，总计1950条
    # 初始状态只有Q、q、Nq三种
    Q_pro = 300 / 1950  # 最后Qr、QS波形效果不是很好
    q_pro = 700 / 1950
    Nq_pro = 950 / 1950

    # 状态转移
    Q_r=0.5
    Q_Nr=0.5
    q_R=6/7
    q_r=1/7
    Nq_R=600/950
    Nq_r=350/950
    R_S=350/1150
    R_s=650/1150
    R_Ns=150/1150
    r_S=350/600
    r_s=100/600
    r_Ns=150/600
    # S到r'有200/850  S到Nr'有650/850
    # s到r'有200/700  s到Nr'有500/700
    # networkx画的带权有向图无法显示权重
    # nodes = ['A','B','C','D','E','F','G']
    # G=nx.DiGraph()
    # for node in nodes:
    #     G.add_node(node)
    # G.add_weighted_edges_from([('A', 'B', 0.5), ('B','C', 0.5)])
    # nx.draw(G, with_labels=True)
    # plt.show()
def get_waveband(batch = 1 ,person = 1 , lead = 0 , wave = 4):
    path = data + 'D{}_{}.npy'.format(batch, person)
    numpy_file = np.load(path, allow_pickle=True)[0]
    peaks = Calibration_Major_Wave(numpy_file)  # 所有导联的R波位置，第一个和最后一个不要
    R_index = peaks[lead][wave]  # R波位置
    # print('R波位置：', R_index)
    ECG_SIGNER = numpy_file[lead]
    dec = wave_decom("Symmlets" + str(lead))
    clearSignal = dec.plot_I(ECG_SIGNER)  # 去噪
    clearSignal = baseline_lowpass(clearSignal)
    x = []
    y = []
    Q_V = []
    R_V=[]
    S_V=[]
    RR_V=[]
    res=[] #总结果
    for i in range(peaks[lead][wave] - 50, peaks[lead][wave] + 50, 1):
        x.append(i)
        y.append(clearSignal[i])
    voltages = np.asarray(y)
    if y[50] > 0:
        minValue = find_extrema(voltages, mode='min')

        Q_index = 0
        for i in range(len(minValue)):
            if abs(minValue[i] - 50) <= 2 or minValue[i] > 50:
                Q_index = minValue[i - 1]
                break
        # 取Q前后0.04秒作为Q波段
        if Q_index < 50 and Q_index > 25:
            # print(y[Q_index], y[Q_index-10])
            if math.fabs(y[Q_index]-y[Q_index-10]) < 0.05:
                for i in range(5):
                    Q_V.append(0)
            else:
                for i in range(Q_index - 10, Q_index + 11, 1):
                    Q_V.append(y[i])
        else: #没有Q，表现为Nq
            # print('Nq')
            for i in range(5):
                Q_V.append(0)
        res.append(Q_V)

        # 取R前后0.02秒作为R段
        for i in range(45, 55):
            R_V.append(y[i])
        res.append(R_V)

        # 取S前后0.02秒作为S段
        S_index = 0
        for i in range(len(minValue)):
            if minValue[i] > 50:
                S_index = minValue[i]
                break
        if S_index > 75 or S_index < 55:
            for i in range(5):
                S_V.append(0)
            res.append(S_V)
            for i in range(5):
                RR_V.append(0)
            res.append(RR_V)
            return res
        else:
            print(y[S_index] , y[S_index+5])
            if math.fabs(y[S_index]-y[S_index+5]) < 0.05:
                for i in range(5):
                    S_V.append(0)
            else:
                for i in range(S_index-5, S_index+8):
                    S_V.append(y[i])
            res.append(S_V)
            maxValue = find_extrema(voltages, mode='max')
            rr_index = 0
            for i in range(len(minValue)):
                if minValue[i] > S_index:
                    rr_index = minValue[i]
                    break
            if rr_index == 0 or rr_index > 85:
                for i in range(5):
                    RR_V.append(0)
                res.append(RR_V)
                return res
            else:
                for i in range(rr_index-5,rr_index+5):
                    RR_V.append(y[i])

                res.append(RR_V)
                return res
    else:
        res=[]
        res.append([0,0,0,0,0])
        #左边找极大值
        maxValue = find_extrema(voltages, mode='max')
        r_index = 0
        rr = []
        for i in maxValue:
            if i < 50:
                r_index = i
        if r_index == 0 or r_index < 30:
            for i in range(5):
                rr.append(y[0])
            res.append(rr)
        else:
            for i in range(r_index-5,r_index+5):
                rr.append(y[i])
            res.append(rr)

        ss=[]
        for i in range(45,55):
            ss.append(y[i])
        res.append(ss)

        rrr_index=0
        rrr=[]
        for i in maxValue:
            if i > 50:
                rrr_index = i
                break
        if rrr_index == 0 or rrr_index > 80:
            for i in range(5):
                rrr.append(0)
            res.append(rrr)
        else:
            for i in range(rrr_index-5,rrr_index+5):
                rrr.append(y[i])
            res.append(rrr)
        return res
def sliding(res):
    wiondow = 5
    length = len(res)
    wiondowSamples=[]

    for i in range(0,length):
        list = res[i]
        if list[2] == 0:
            wiondowSamples.append(list)
            continue
        sequence = []
        for j in range(0,len(list)-wiondow):
            l =[]
            l.append(res[i][j:j+wiondow])
            L = len(list)
            C = L/2
            D = j + 2
            weight = math.exp(-1 * (2 * math.fabs(D-C) / L))
            # print(weight)
            l.append(weight)
            sequence.append(l)
        wiondowSamples.append(sequence)
    # print(len(wiondowSamples))
    return wiondowSamples
def calc_corr(A, B): # 计算两个序列的相关系数
    lag = []
    pearsonrs = []
    pvalues = []
    result = pearsonr(A, B)
    lag.append(0)
    pearsonrs.append(result[0])
    pvalues.append(result[1])
    ###############不断进行右移，并记录所有参数
    C = B.copy()
    for i in range(20):
        C.insert(0, C.pop())
        result = pearsonr(A, C)
        lag.append(i + 1)
        pearsonrs.append(result[0])
        pvalues.append(result[1])
    ###############不断进行左移，并记录所有参数
    D = B.copy()
    for i in range(20):
        D.insert(len(D), D[0])
        D.remove(D[0])
        result = pearsonr(A, D)
        lag.append(-(i + 1))
        pearsonrs.append(result[0])
        pvalues.append(result[1])
    # print(max(pearsonrs))
    return max(pearsonrs)
def SWVHMM(batch=1 , person=13 , lead=10, wave=1):
    res = get_waveband(batch, person, lead, wave)
    windowSamples = sliding(res)
    wavebands = len(windowSamples)
    Q_W = []
    R_W = []
    S_W = []
    RR_W = []
    for i in range(0, wavebands):
        if i == 0:
            Q_windows = len(windowSamples[0])
            for i in range(Q_windows):
                # print(windowSamples[0][i])
                Q_W.append(windowSamples[0][i])
        if i == 1:
            R_windows = len(windowSamples[1])
            for i in range(R_windows):
                R_W.append(windowSamples[1][i])
        if i == 2:
            S_windows = len(windowSamples[2])
            for i in range(S_windows):
                S_W.append(windowSamples[2][i])
        if i == 3:
            RR_windows = len(windowSamples[3])
            for i in range(RR_windows):
                RR_W.append(windowSamples[3][i])

    if RR_W[2] == 0:
        RR_W = [[[0, 0, 0, 0, 0], 1]]
    if S_W[2] == 0:
        S_W = [[[0, 0, 0, 0, 0], 1]]
    if Q_W[2] == 0:
        Q_W = [[[0, 0, 0, 0, 0], 1]]
    if R_W[2] == 0:
        R_W = [[[0, 0, 0, 0, 0], 1]]
    dic = {}
    tt=0
    for i in Q_W:
        for j in R_W:
            for m in S_W:
                for n in RR_W:
                    tt = tt + 1
                    weight = i[1] * j[1] * m[1] * n[1]
                    x = i[0]
                    y = j[0]
                    z = m[0]
                    k = n[0]
                    box = train(x, y, z, k)
                    if box in dic:
                        dic[box] = dic[box] + weight
                    else:
                        dic[box] = weight

    # print('窗口样本个数:{}'.format(tt))
    # 投票表决
    z = sorted(dic.items(), key=lambda kv: (kv[1], kv[0]), reverse=True)
    # print('sorted: ',z)
    length = len(z)
    jieguo = ""
    # 先统计Q波段
    Q_wave = 0
    q_wave=0
    Nq_wave=0
    for i in range(length):
        if z[i][0][0] == 0:
            Q_wave = Q_wave+z[i][1]
        if z[i][0][0] == 1:
            q_wave=q_wave+z[i][1]
        if z[i][0][0] == 2:
            Nq_wave=Nq_wave+z[i][1]
    # print('Q_wave: {} , q_wave: {} , Nq_wave: {}'.format(Q_wave,q_wave,Nq_wave))

    if Q_wave > q_wave:
        if Q_wave > Nq_wave:
            jieguo += "Q"
    else:
        if q_wave > Nq_wave:
            jieguo += 'q'

    # 统计R波段
    R_wave = 0
    r_wave = 0
    Nr_wave = 0
    for i in range(length):
        if z[i][0][1] == 3:
            R_wave = R_wave + z[i][1]
        if z[i][0][1] == 4:
            r_wave = r_wave + z[i][1]
        if z[i][0][1] == 5:
            Nr_wave = Nr_wave + z[i][1]
    # print('R_wave: {} , r_wave: {} , Nr_wave: {}'.format(R_wave, r_wave, Nr_wave))

    if R_wave > r_wave:
        if R_wave > Nr_wave:
            jieguo += "R"
    else:
        if r_wave > Nr_wave:
            jieguo += 'r'

    # 统计S波段
    S_wave = 0
    s_wave = 0
    Ns_wave = 0
    for i in range(length):
        if z[i][0][2] == 6:
            S_wave = S_wave + z[i][1]
        if z[i][0][2] == 7:
            s_wave = s_wave + z[i][1]
        if z[i][0][2] == 8:
            Ns_wave = Ns_wave + z[i][1]
    # print('S_wave: {} , s_wave: {} , Ns_wave: {}'.format(S_wave, s_wave, Ns_wave))
    if S_wave > s_wave:
        if s_wave > Ns_wave:
            jieguo += "S"
    else:
        if s_wave > Ns_wave:
            jieguo += 's'

    # 统计R'波段
    rr_wave = 0 # r'
    rrr_wave = 0 # Nr'
    for i in range(length):
        if z[i][0][3] == 9:
            S_wave = S_wave + z[i][1]
        if z[i][0][3] == 10:
            s_wave = s_wave + z[i][1]
    # print('rr_wave: {} , rrr_wave: {} '.format(rr_wave, rrr_wave))
    if math.fabs(res[1][len(res[1])//2]) >= 0.45:
        jieguo = jieguo.replace("r","R")
    if math.fabs(res[2][len(res[2])//2]) >= 0.45:
        jieguo = jieguo.replace('s',"S")
    t = len(res[3]) // 2
    if math.fabs(res[3][t]-res[3][t-3]) >= 0.01:
        jieguo += "r'"
    print("波形预测：",jieguo)
def train(x,y,z,k):
    states = ["Q", "q", "Nq", "R", "r", "Nr", "S", "s", "Ns", "r'", "Nr'"]
    n_states = len(states)
    observations=np.load(r'data/generated_data/center.npy')
    observations=list(observations)
    n_observations = len(observations)
    start_probability = np.array([300 / 1950, 700 / 1950, 950 / 1950, 0, 0, 0, 0, 0, 0, 0, 0])  # 初始状态分布
    transition_probability = np.array([  # 状态转移
        [0, 0, 0, 0.5, 0.5, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 6 / 7, 1 / 7, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 600 / 950, 350 / 950, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 350 / 1150, 650 / 1150, 150 / 1150, 0, 0],
        [0, 0, 0, 0, 0, 0, 350 / 600, 100 / 600, 150 / 600, 0, 0],
        [0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 200 / 850, 650 / 850],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 2 / 7, 5 / 7],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1]
    ])
    emission_probability = np.load(r'data/generated_data/pro.npy')
    model = hmm.MultinomialHMM(n_components=n_states)
    model.startprob_ = start_probability
    model.transmat_ = transition_probability
    model.emissionprob_ = emission_probability
    # 训练完成，下面使用维特比解码
    # 根据拼接，找得到对应下标，作为seen预测
    max_x_corr = -100
    max_x_index = -1
    if x == [0,0,0,0,0]:
        max_x_index=2
    else:
        for i in range(0,3):
            cor = calc_corr(observations[i],x)
            if cor > max_x_corr:
                max_x_corr = cor
                max_x_index = i
    # print('与x最相似的为：',max_x_index)
    max_y_corr = -100
    max_y_index = -1
    if y == [0,0,0,0,0]:
        max_y_index=5
    else:
        for i in range(3, 6):
            cor = calc_corr(observations[i], y)
            if cor > max_y_corr:
                max_y_corr = cor
                max_y_index = i
    # print('与y最相似的为：', max_y_index)
    max_z_corr = -100
    max_z_index = -1
    if z == [0,0,0,0,0]:
        max_z_index=8
    else:
        for i in range(6, 9):
            cor = calc_corr(observations[i], z)
            if cor > max_z_corr:
                max_z_corr = cor
                max_z_index = i
    # print('与z最相似的为：', max_z_index)
    max_k_corr = -100
    max_k_index = -1
    if k == [0,0,0,0,0]:
        max_k_index=10
    else:
        for i in range(9, 11):
            cor = calc_corr(observations[i], k)
            if cor > max_k_corr:
                max_k_corr = cor
                max_k_index = i
    # print('与k最相似的为：', max_k_index)
    seen = np.array([[max_x_index, max_y_index, max_z_index, max_k_index]]).T
    logprob, box = model.decode(seen, algorithm="viterbi")
    box=tuple(box)
    return box

if __name__ == '__main__':
    # 绘制某个人第lead导联上的第wave个波形，该波形为滤波去噪后的波形
    plot_QRS(batch=1 , person=1, lead=0, wave=4)
    # 中文对比实验
    print('---------------------中文对比实验结果--------------')
    FSM_QRS(batch=1 , person=1, lead=0, wave=4)
    # 英文对比实验，只能识别少数波形
    print('---------------------英文对比实验结果--------------')
    Morphological_Classification(batch=1 , person=1, lead=0, wave=4)
    # 本实验
    print('---------------------本实验结果--------------')
    SWVHMM(batch=1 , person=1, lead=0, wave=4)
