# "一种心电信号QRS复杂形态自动分析算法" 论文

import numpy as np
from numpy.linalg import  *
from common import *
from QRS_Classfiy import *
import ast
import math
import matplotlib.pyplot as plt
from enum import Enum
plt.rcParams['font.sans-serif'] = ['SimHei']	# 显示中文
plt.rcParams['axes.unicode_minus'] = False		# 显示负号

#样本位置
data =  r'data/generated_data/datas123/'

# 没用了，废弃方法
def QRS_classification(person = 1 , k = 5 , errorThreshold = 0.01 ,
                       gradThreshold = 0.004 , Beta = 0.02 ,alpha = 0.05):
    '''
    :param person: 第几个人
    :param k: 连续取k个点
    :param errorThreshold: 拟合曲线预测值和真实值的绝对值误差阈值
    :param gradThreshold: 分段阈值thr，认为只有超过该值，才判定为QRS波群组成成分
    :param Beta: 对于QRS波群的起始和终止分段，认为只有超过该阈值，才是关键点
    :param alpha: 两个相邻分段的角度差如果超过该值，认为该交点是关键点
    :return:
    '''
    # 论文里面是选取QRS波群定位点前后各0.2秒，这里直接取R点前后
    path = data + 'D1_{}.npy'.format(person)
    numpy_file = np.load(path, allow_pickle=True)[0]
    info = QRS_Classfiy_new(numpy_file)  # 得到QRS等信息

    for lead in range(0, 12):  # lead 表示导联
        # ECG_SIGNER是样本的原始信号  ； clearSignal是去噪后信号
        ECG_SIGNER = numpy_file[lead]
        dec = wave_decom("Symmlets" + str(lead))
        clearSignal = dec.plot_I(ECG_SIGNER)  # 去噪

        print('-----------第{}个人的第{}导联--------------'.format(person, lead + 1))
        number = 1  # 第几个QRS波群
        for QRS_index in info[lead]:  # 每个导联上的若干QRS波群
            print('=====第{}个QRS波群====='.format(number))
            number = number + 1

            R_index = QRS_index[0][4]  # R点横坐标
            print('R波位置：',R_index)
            distance = 500 * 0.2
            start = R_index - distance
            end = R_index + distance

            #----------------------第一步：为QRS波群 ECG分段------------------------#
            '''使用列表存储QRS波形的每个ECG分段的曲线信息，而每个分段信息也是个列表
            即[ [left , right , a , b , c , Mono ,Grad , SAngle , EAngle]  , [] ]
            列表中:
                left , right表示该分段的起始和终止位置；
                a、b、c表示抛物线系数；
                Mono表示该抛物线的单调性（0表示单调，如果非0，则是转折点）
                Grad表示该抛物线的陡峭程度
                SAngle和EAngle表示方向特征
            '''
            QRS_info = []
            # 从start-end即为一个检测区域
            left = int(start)
            right = int(start + k) #连续取k=5个点
            while right < end:
                X = []
                Y = []
                for i in range(left , right + 1):
                    X.append(i)
                    Y.append(clearSignal[i])
                equation = fitting_curve(X , Y)
                #计算每个点真实值和预测值的绝对值误差，并找到最大值
                maxValue = -1
                for i in range(0 , len(X) , 1):
                    Y_predict = equation[0] * X[i] * X[i] + equation[1] * X[i] + equation[2]
                    maxValue = max(abs(Y[i] - Y_predict) , maxValue)

                if maxValue < errorThreshold:
                    # print('继续向后搜索一个数据点')
                    right = right + 1
                else:
                    # 当前ECG分段结束，去除最后一点，重新拟合曲线并作为最终结果
                    # print('当前ECG分段结束，去除最后一点，重新拟合曲线并作为最终结果')
                    X = []
                    Y = []
                    for i in range(left , right):
                        X.append(i)
                        Y.append(clearSignal[i])
                    equation = fitting_curve(X , Y)
                    value = []

                    value.append(left)
                    value.append(right-1)
                    value.append(equation[0])
                    value.append(equation[1])
                    value.append(equation[2])

                    '''使用单调性、陡峭程度、和曲线方向三个角度描述曲线C
                    '''
                    #1、单调性判断：核心在于抛物线对称轴是 -b/2a
                    Mono = 0 #如果非0，即为转折点
                    axis = (-1) * equation[1] / (2 * equation[0])
                    if left < axis < (right-1):
                        #对称轴axis即为转折点
                        Mono = int(axis)
                        if Mono == left: #防止后面除法异常
                            Mono = left + 1
                        # print('{}到{} 分段不单调，转折点为：'.format(left , right-1), Mono)
                    # else:
                    #     print('{}到{} 分段是单调的'.format(left , right-1))

                    value.append(Mono) #添加该分段的单调性

                    #2、陡峭程度判断
                    Grad = 0
                    y_start = equation[0] * left * left + equation[1] * left + equation[2]
                    y_end = equation[0] * (right-1) * (right-1) + equation[1] * (right-1) + equation[2]
                    if Mono == 0: #单调情况下，取终点和起始点的斜率作为陡峭程度
                        Grad = abs( (y_end - y_start) / (right-1 - left) )
                        # print('单调且陡峭程度为：',Grad)
                    else:
                        former = abs( (clearSignal[Mono] - y_start) / (Mono - left) )
                        latter = abs( (y_end - clearSignal[Mono]) / (right-1 - Mono) )
                        Grad = max(former , latter)
                        # print('不单调，陡峭程度：', Grad)
                    value.append(Grad) #添加该分段的陡峭性

                    #3、方向特征判断: 如果值是正数，说明上升方向；否则下降方向
                    SAngle = math.atan( 2 * equation[0] * left + equation[1])
                    EAngle = math.atan( 2 * equation[0] * (right-1) + equation[1])
                    value.append(SAngle)
                    value.append(EAngle)

                    QRS_info.append(value)
                    #新的分段开始，起点为前一段的终点
                    left = right-1
                    right = left + k

            #--------------------------第二步：ECG分段完成，开始提取关键点和属性------------------------#
            # print('所有ECG分段信息',QRS_info)
            #1、找出分段中不是QRS波群的组成. 论文中是所有分段都要判断，其实没必要，只要开头结尾判断即可
            #先从前往后扫描分段
            indexing = 0
            while indexing < len(QRS_info):
                if QRS_info[indexing][6] < gradThreshold:
                    del QRS_info[indexing] #删除之后后面会前进
                    indexing = indexing
                else:
                    break
            #再从后往前扫描分度
            for i in range(len(QRS_info)-1 , -1 , -1):
                if QRS_info[i][6] < gradThreshold:
                    del QRS_info[i]
                else:
                    break
            print('QRS波群分段曲线确定：',QRS_info)

            #2、关键点检测 , 字典存储中间关键点的左侧、右侧曲线方向
            keyPoints = []
            keyPointsInfo = {}

            if abs(QRS_info[0][7]) > Beta:
                print('{}起始位置是关键点'.format(QRS_info[0][0]))
                keyPoints.append(QRS_info[0][0])
            for i in range(1 , len(QRS_info) , 1):
                #先确定自己分段有没有转折点
                if QRS_info[i][5] != 0: #非单调，存在转折点
                    turingPoint = QRS_info[i][5] #转折点
                    LD_turingPoint = QRS_info[i][7] #左侧曲线
                    RD_turingPoint = QRS_info[i][8] #右侧曲线

                    print('{}是转折点'.format(QRS_info[i][5]))
                    keyPoints.append(QRS_info[i][5])
                    keyPointsInfo[QRS_info[i][5]] = [LD_turingPoint , RD_turingPoint]

            # 这个for循环是可以和上面合并的，主要是针对交点和转折点距离接近情况设置的，目的为去除交点
            for i in range(1 , len(QRS_info) , 1):
                #再与前一个分段确定有没有交点
                if abs(QRS_info[i][7] - QRS_info[i-1][8]) > alpha: # QRS_info[i-1][8] 前一分段的终末方向; QRS_info[i][7] 后一分段的起始方向
                    isDelete = False
                    for j in range(len(keyPoints)):
                        #交点与某个转折点距离小于k，去除交点
                        if abs(QRS_info[i][0] - keyPoints[j]) < k:
                            isDelete = True
                            break;
                    if isDelete :
                        continue
                    else:
                        LD_intersection = QRS_info[i-1][8]
                        RD_intersection = QRS_info[i][7]

                        print('{}是交点'.format(QRS_info[i][0]))
                        keyPoints.append(QRS_info[i][0])  # 交点
                        keyPointsInfo[QRS_info[i][0]] = [LD_intersection , RD_intersection]

            if abs(QRS_info[len(QRS_info)-1][8]) > Beta:
                print('{}终末位置是关键点'.format(QRS_info[len(QRS_info)-1][0]))
                keyPoints.append(QRS_info[len(QRS_info)-1][0])




            keyPoints = sorted(keyPoints)
            print('关键点排序后: ',keyPoints)

            #3、对关键点提取出Lab、Amp、Time三个属性，并存入字典qrsProperties中
            '''
            qrsProperties中键是关键点的横坐标；值是一个列表，分别存Amp、Time、Lab
            '''
            qrsProperties = {}
            startKeyPoint_X = keyPoints[0] #QRS波群起点的横坐标
            startKeyPoint_Y = clearSignal[keyPoints[0]] #纵坐标
            for i in range(1 , len(keyPoints)-1 , 1):
                Amp = clearSignal[keyPoints[i]] - startKeyPoint_Y  #相对幅值
                Time = keyPoints[i] - startKeyPoint_X #相对时刻
                # 关键点类型Lab有8种情况
                LD = keyPointsInfo[keyPoints[i]][0]
                RD = keyPointsInfo[keyPoints[i]][1]
                if Amp > 0:
                    if LD > 0 and RD > 0:
                        qrsProperties[keyPoints[i]] = [Amp , Time , 'A+']
                        # print('A+')
                    elif LD > 0 and RD < 0:
                        qrsProperties[keyPoints[i]] = [Amp, Time, 'P+']
                        # print('P+')
                    elif LD < 0 and RD > 0:
                        qrsProperties[keyPoints[i]] = [Amp, Time, 'V+']
                        # print('V+')
                    elif LD < 0 and RD < 0:
                        qrsProperties[keyPoints[i]] = [Amp, Time, 'F+']
                        # print('F+')
                else:
                    if LD > 0 and RD > 0:
                        qrsProperties[keyPoints[i]] = [Amp, Time, 'A-']
                        # print('A-')
                    elif LD > 0 and RD < 0:
                        qrsProperties[keyPoints[i]] = [Amp, Time, 'P-']
                        # print('P-')
                    elif LD < 0 and RD > 0:
                        qrsProperties[keyPoints[i]] = [Amp, Time, 'V-']
                        # print('V-')
                    elif LD < 0 and RD < 0:
                        qrsProperties[keyPoints[i]] = [Amp, Time, 'F-']
                        # print('F-')
            #最后一个点单独处理
            endNodeAmp = clearSignal[keyPoints[len(keyPoints)-1]] - startKeyPoint_Y
            endNodeTime = keyPoints[len(keyPoints)-1] - startKeyPoint_X
            qrsProperties[keyPoints[len(keyPoints)-1]] = [endNodeAmp , endNodeTime , 'OFF']

            print('关键点的属性集：',qrsProperties)

            #-----------------------第三步：QRS形态识别-------------------------------------#
            que = ""
            #这里的FSM用 条件判断方式 可能更好，因为要拼接字符串

        break


def FSM_QRS( batch = 1 ,person = 1 , lead = 0 , wave = 1 , k = 5 , errorThreshold = 0.01 ,
                       gradThreshold = 0.004 , Beta = 0.02 ,alpha = 0.03):
    '''
    :param person: 第几个人，从1开始 ，默认读取 D1_person.npy文件
    :param lead: 第几导联，范围0-11
    :param wave: 第几个波，从0开始，但是第一个和最后一个波不要，一般取1-8，没有健壮性判断
    :param k: 连续取k个点
    :param errorThreshold: 拟合曲线预测值和真实值的绝对值误差阈值
    :param gradThreshold: 分段阈值thr，认为只有超过该值，才判定ECG分段为QRS波群组成成分
    :param Beta: 对于QRS波群的起始和终止分段，认为只有超过该阈值，才是关键点
    :param alpha: 两个相邻分段的角度差如果超过该值，认为该交点是关键点
    :return: QRS形态
    '''
    # 论文里面是选取QRS波群定位点前后各0.2秒，这里直接取R点前后
    path = data + 'D{}_{}.npy'.format(batch , person)
    numpy_file = np.load(path, allow_pickle=True)[0]
    peaks = Calibration_Major_Wave(numpy_file) #所有导联的R波位置，第一个和最后一个不要
    R_index = peaks[lead][wave] #R波位置
    # print('R波位置：', R_index)

    ECG_SIGNER = numpy_file[lead]
    dec = wave_decom("Symmlets" + str(lead))
    clearSignal = dec.plot_I(ECG_SIGNER)  # 去噪
    clearSignal = baseline_lowpass(clearSignal)

    distance = 500 * 0.2
    start = int(R_index - distance)
    end = int(R_index + distance)


    # ----------------------第一步：为QRS波群 ECG分段------------------------#
    '''使用列表存储QRS波形的每个ECG分段的曲线信息，而每个分段信息也是个列表
    即[ [left , right , a , b , c , Mono ,Grad , SAngle , EAngle]  , [] ]
    列表中:
        left , right表示该分段的起始和终止位置；
        a、b、c表示抛物线系数；
        Mono表示该抛物线的单调性（0表示单调，如果非0，则是转折点）
        Grad表示该抛物线的陡峭程度
        SAngle和EAngle表示方向特征
    '''
    QRS_info = []
    # 从start-end即为一个检测区域
    left = int(start)
    right = int(start + k)  # 连续取k=5个点
    while right < end:
        X = []
        Y = []
        for i in range(left, right + 1):
            X.append(i)
            Y.append(clearSignal[i])
        equation = fitting_curve(X, Y)
        # 计算每个点真实值和预测值的绝对值误差，并找到最大值
        maxValue = -1
        for i in range(0, len(X), 1):
            Y_predict = equation[0] * X[i] * X[i] + equation[1] * X[i] + equation[2]
            maxValue = max(abs(Y[i] - Y_predict), maxValue)

        if maxValue < errorThreshold:
            # print('继续向后搜索一个数据点')
            right = right + 1
        else:
            # 当前ECG分段结束，去除最后一点，重新拟合曲线并作为最终结果
            # print('当前ECG分段结束，去除最后一点，重新拟合曲线并作为最终结果')
            X = []
            Y = []
            for i in range(left, right):
                X.append(i)
                Y.append(clearSignal[i])
            equation = fitting_curve(X, Y)
            value = []

            value.append(left)
            value.append(right - 1)
            value.append(equation[0])
            value.append(equation[1])
            value.append(equation[2])

            '''使用单调性、陡峭程度、和曲线方向三个角度描述曲线C
            '''
            # 1、单调性判断：核心在于抛物线对称轴是 -b/2a
            Mono = 0  # 如果非0，即为转折点
            axis = (-1) * equation[1] / (2 * equation[0])
            if left < axis < (right - 1):
                # 对称轴axis即为转折点
                Mono = int(axis)
                if Mono == left:  # 防止后面除法异常
                    Mono = left + 1
                # print('{}到{} 分段不单调，转折点为：'.format(left , right-1), Mono)
            # else:
            #     print('{}到{} 分段是单调的'.format(left , right-1))

            value.append(Mono)  # 添加该分段的单调性

            # 2、陡峭程度判断
            Grad = 0
            y_start = equation[0] * left * left + equation[1] * left + equation[2]
            y_end = equation[0] * (right - 1) * (right - 1) + equation[1] * (right - 1) + equation[2]
            if Mono == 0:  # 单调情况下，取终点和起始点的斜率作为陡峭程度
                Grad = abs((y_end - y_start) / (right - 1 - left))
                # print('单调且陡峭程度为：',Grad)
            else:
                former = abs((clearSignal[Mono] - y_start) / (Mono - left))
                latter = abs((y_end - clearSignal[Mono]) / (right - 1 - Mono))
                Grad = max(former, latter)
                # print('不单调，陡峭程度：', Grad)
            value.append(Grad)  # 添加该分段的陡峭性

            # 3、方向特征判断: 如果值是正数，说明上升方向；否则下降方向
            SAngle = math.atan(2 * equation[0] * left + equation[1])
            EAngle = math.atan(2 * equation[0] * (right - 1) + equation[1])
            value.append(SAngle)
            value.append(EAngle)

            QRS_info.append(value)
            # 新的分段开始，起点为前一段的终点
            left = right - 1
            right = left + k

    # --------------------------第二步：ECG分段完成，开始提取关键点和属性------------------------#
    # print('所有ECG分段信息',QRS_info)
    # 1、找出分段中不是QRS波群的组成. 论文中是所有分段都要判断，其实没必要，只要开头结尾判断即可
    # 先从前往后扫描分段
    indexing = 0
    while indexing < len(QRS_info):
        if QRS_info[indexing][6] < gradThreshold:
            del QRS_info[indexing]  # 删除之后后面会前进
            indexing = indexing
        else:
            break
    # 再从后往前扫描分度
    for i in range(len(QRS_info) - 1, -1, -1):
        if QRS_info[i][6] < gradThreshold:
            del QRS_info[i]
        else:
            break
    print('QRS波群分段曲线确定：', QRS_info)

    # 2、关键点检测 , 字典存储中间关键点的左侧、右侧曲线方向
    keyPoints = []
    keyPointsInfo = {}

    if abs(QRS_info[0][7]) > Beta:
        print('{}起始位置是关键点'.format(QRS_info[0][0]))
        keyPoints.append(QRS_info[0][0])

    for i in range(1, len(QRS_info), 1):
        # 先确定自己分段有没有转折点
        if QRS_info[i][5] != 0:  # 非单调，存在转折点
            turingPoint = QRS_info[i][5]  # 转折点
            LD_turingPoint = QRS_info[i][7]  # 左侧曲线
            RD_turingPoint = QRS_info[i][8]  # 右侧曲线

            print('{}是转折点'.format(QRS_info[i][5]))
            keyPoints.append(QRS_info[i][5])
            keyPointsInfo[QRS_info[i][5]] = [LD_turingPoint, RD_turingPoint]

    # 这个for循环是可以和上面合并的，主要是针对交点和转折点距离接近情况设置的，目的为去除交点
    for i in range(1, len(QRS_info), 1):
        # 再与前一个分段确定有没有交点
        if abs(QRS_info[i][7] - QRS_info[i - 1][8]) > alpha:  # QRS_info[i-1][8] 前一分段的终末方向; QRS_info[i][7] 后一分段的起始方向
            isDelete = False
            for j in range(len(keyPoints)):
                # 交点与某个转折点距离小于k，去除交点
                if abs(QRS_info[i][0] - keyPoints[j]) < k:
                    isDelete = True
                    break;
            if isDelete:
                continue
            else:
                LD_intersection = QRS_info[i - 1][8]
                RD_intersection = QRS_info[i][7]

                print('{}是交点'.format(QRS_info[i][0]))
                keyPoints.append(QRS_info[i][0])  # 交点
                keyPointsInfo[QRS_info[i][0]] = [LD_intersection, RD_intersection]

    if abs(QRS_info[len(QRS_info) - 1][8]) > Beta:
        print('{}终末位置是关键点'.format(QRS_info[len(QRS_info) - 1][0]))
        keyPoints.append(QRS_info[len(QRS_info) - 1][0])

    keyPoints = sorted(keyPoints)
    print('关键点排序后: ', keyPoints)


    # 3、对关键点提取出Lab、Amp、Time三个属性，并存入字典qrsProperties中
    '''
    qrsProperties中键是关键点的横坐标；值是一个列表，分别存Amp、Time、Lab
    '''
    qrsProperties = {}
    startKeyPoint_X = keyPoints[0]  # QRS波群起点的横坐标
    startKeyPoint_Y = clearSignal[keyPoints[0]]  # 纵坐标
    for i in range(1, len(keyPoints) - 1, 1):
        Amp = clearSignal[keyPoints[i]] - startKeyPoint_Y  # 相对幅值
        Time = keyPoints[i] - startKeyPoint_X  # 相对时刻
        # 关键点类型Lab有8种情况
        LD = keyPointsInfo[keyPoints[i]][0]
        RD = keyPointsInfo[keyPoints[i]][1]
        if Amp > 0:
            if LD > 0 and RD > 0:
                qrsProperties[keyPoints[i]] = [Amp, Time, 'A+']
                # print('A+')
            elif LD > 0 and RD < 0:
                qrsProperties[keyPoints[i]] = [Amp, Time, 'P+']
                # print('P+')
            elif LD < 0 and RD > 0:
                qrsProperties[keyPoints[i]] = [Amp, Time, 'V+']
                # print('V+')
            elif LD < 0 and RD < 0:
                qrsProperties[keyPoints[i]] = [Amp, Time, 'F+']
                # print('F+')
        else:
            if LD > 0 and RD > 0:
                qrsProperties[keyPoints[i]] = [Amp, Time, 'A-']
                # print('A-')
            elif LD > 0 and RD < 0:
                qrsProperties[keyPoints[i]] = [Amp, Time, 'P-']
                # print('P-')
            elif LD < 0 and RD > 0:
                qrsProperties[keyPoints[i]] = [Amp, Time, 'V-']
                # print('V-')
            elif LD < 0 and RD < 0:
                qrsProperties[keyPoints[i]] = [Amp, Time, 'F-']
                # print('F-')
    # 最后一个点单独处理
    endNodeAmp = clearSignal[keyPoints[len(keyPoints) - 1]] - startKeyPoint_Y
    endNodeTime = keyPoints[len(keyPoints) - 1] - startKeyPoint_X
    qrsProperties[keyPoints[len(keyPoints) - 1]] = [endNodeAmp, endNodeTime, 'OFF']

    print('关键点的属性集：', qrsProperties)

    # -----------------------第三步：QRS形态识别-------------------------------------#
    que = ""
    # key = sorted(qrsProperties.keys())

    qrsList = realize_QRS(qrsProperties)
    if len(qrsList) == 0:
        print('此次波群检测失败')
    else:
        print(qrsList)
        R_count = 0 #记录R波出现次数
        S_count = 0 #记录S波出现次数

        for content in qrsList:
            if content == 'NQ':
                que += '(Q波切迹)'
            if content == 'NR':
                que += '(R波切迹)'
            if content == 'NS':
                que += '(S波切迹)'

            if content == 'FQ':
                que += '(Q波下降顿挫)'
            if content == 'FR':
                que += '(R波下降顿挫)'
            if content == 'FS':
                que += '(S波下降顿挫)'

            if content == 'AQ':
                que += '(Q波上升顿挫)'
            if content == 'AR':
                que += '(R波上升顿挫)'
            if content == 'AS':
                que += '(S波上升顿挫)'

            if content == 'Q' or content == 'q':
                que += content
            if content == 'R' or content == 'r':
                que += content
                R_count = R_count + 1
                if R_count == 2:
                    que  = que + content + "'"
                if R_count == 3:
                    que = que + content + "''"
            if content == 'S' or content == 's':
                que += content
                S_count = S_count + 1
                if S_count == 2:
                    que  = que + content + "'"
                if S_count == 3:
                    que  = que + content + "''"

        print('D{}_{}_{}_{}波形检测结果为：'.format(batch,person,lead,wave),que)
        plt.title('D1_{}_{}_{}波形'.format(person,lead,wave))
        x = []
        y = []
        for i in range(peaks[lead][wave]-50, peaks[lead][wave]+50 , 1):
            x.append(i)
            y.append(clearSignal[i])
        plt.plot(x , y)
        for j in range(1, len(keyPoints), 1):
            plt.plot(keyPoints[j] , clearSignal[keyPoints[j]] ,marker = 'o')
        plt.show()
#最小二乘法拟合曲线
def fitting_curve(X , Y):
    n = len(X)
    m = 2  # 求m次方多项式, m<=n
    A = np.zeros((m + 1, m + 1))  # 创建零数组
    B = np.zeros((m + 1, 1))
    for i in range(m + 1):
        y = 0
        for j in range(m + 1):
            if i == 0 and j == 0:
                A[0][0] = n
            else:
                x = 0
                for s in range(n):
                    x += X[s] ** (i + j)
                A[i][j] = x
        for s in range(n):
            y += X[s] ** (i) * Y[s]
        B[i][0] = y
    result = solve(A, B)

    # print('X^2项的系数：', result[2][0])
    # print('X项的系数：', result[1][0])
    # print('常数项系数：',result[0][0])

    # print('拟合曲线方程为：y = {} * x^2 + {} * x + {}'.format(result[2][0] , result[1][0] , result[0][0]))

    equation = [result[2][0] , result[1][0] , result[0][0]]
    return equation
def operation(AmpPi, op, que, *AmpPi2):
    """
    根据输入的QRS波群关键点的幅值属性，确定QRS形态描述字符，更新存储队列que。
    :param AmpPi: Pi的幅值
    :param op: 需要执行的操作
    :param que: 存储QRS形态识别结果
    :param AmpPi2: P(i-2)的幅值
    :return: 无
    """
    if op == 1:
        if abs(AmpPi) >= 0.5:
            que.append('Q')
        else:
            que.append('q')

    elif op == 2:
        if abs(AmpPi) >= 0.5:
            que.append('R')
        else:
            que.append('r')

    elif op == 3:
        if abs(AmpPi) >= 0.5:
            que.append('S')
        else:
            que.append('s')

    elif op == 4:
        que.append('FQ')

    elif op == 5:
        que.append('NQ')

    elif op == 6:
        if abs(AmpPi) >= abs(AmpPi2) and abs(AmpPi) >= 0.5:
            que[-2] = 'NQ'
            que.append('Q')
        elif abs(AmpPi) >= abs(AmpPi2) and abs(AmpPi) < 0.5:
            que[-2] = 'NQ'
            que.append('q')
        else:
            que.append('NQ')

    elif op == 7:
        que.append('AQ')

    elif op == 8:
        que.append('AR')

    elif op == 9:
        que.append('NR')

    elif op == 10:
        if abs(AmpPi) >= abs(AmpPi2) and abs(AmpPi) >= 0.5:
            que[-2] = 'NR'
            que.append('R')
        elif abs(AmpPi) >= abs(AmpPi2) and abs(AmpPi) < 0.5:
            que[-2] = 'NR'
            que.append('r')
        else:
            que.append('NR')

    elif op == 11:
        que.append('FR')

    elif op == 12:
        que.append('FS')

    elif op == 13:
        que.append('NS')

    elif op == 14:
        if (abs(AmpPi) >= abs(AmpPi2) and abs(AmpPi) >= 0.5):
            que[-2] = 'NS'
            que.append('S')
        elif (abs(AmpPi) >= abs(AmpPi2) and abs(AmpPi) < 0.5):
            que[-2] = 'NS'
            que.append('s')
        else:
            que.append('NS')

    elif op == 15:
        que.append('AS')

    elif op == 16:
        return
# 状态机
def realize_QRS(P_sequence):
    """
    QRS形态识别自动机
    :param P_sequence: QRS波群关键点序列P1, P2, ..., Pt
    :return: que 存储QRS形态识别结果
    """
    # 枚举所有状态
    State = Enum('State', 'start AR FS AS Q R S FQ NQ AQ NR FR NS end')

    # 状态转移表（其中end状态没有状态转移表）
    start = {'P+': (2, State.R), 'A+': (8, State.AR), 'V-': (1, State.Q), 'F-': (4, State.FQ)}
    AR = {'P+': (2, State.R)}
    FS = {'V-': (3, State.S)}
    AS = {'OFF': (16, State.end)}
    Q = {'A+': (8, State.AR), 'P+': (2, State.R), 'A-': (7, State.AQ), 'OFF': (16, State.end), 'P-': (5, State.NQ)}
    R = {'F-': (12, State.FS), 'V-': (3, State.S), 'F+': (11, State.FR), 'OFF': (16, State.end), 'V+': (9, State.NR)}
    S = {'P+': (2, State.R), 'A-': (15, State.AS), 'OFF': (16, State.end), 'V-': (13, State.NS)}
    FQ = {'V-': (1, State.Q)}
    NQ = {'V-': (6, State.Q)}
    AQ = {'P+': (2, State.R), 'OFF': (16, State.end)}
    NR = {'P+': (10, State.R)}
    FR = {'V-': (3, State.S), 'OFF': (16, State.end)}
    NS = {'P-': (14, State.S)}

    # 状态和状态转移表的映射
    states = {State.start: start, State.AR: AR, State.FS: FS, State.AS: AS, State.Q: Q, State.R: R, State.S: S,
              State.FQ: FQ, State.NQ: NQ, State.AQ: AQ, State.NR: NR, State.FR: FR, State.NS: NS}

    # 存储QRS形态识别结果
    que = []

    # 初始化当前状态，从start开始
    cur_state = State.start

    # 列表里面存放元组：（类型Lab，幅值Amp）
    LabAmp = []

    # Python3.6开始字典的遍历是有序的，遍历输出的结果和存储顺序相同。
    for value in P_sequence.values():
        # 取出类型和幅值
        LabAmp.append((value[2], value[0]))
    # print(LabAmp)

    for i in range(len(LabAmp)):
        Lab = LabAmp[i][0]

        # 输入关键点类型可被自动机正确识别
        if Lab in states[cur_state]:
            # 根据关键点属性执行相应操作，同时进行自动机状态转移
            op, cur_state = states[cur_state][Lab]
            if i < 2:
                operation(LabAmp[i][1], op, que)
            else:
                operation(LabAmp[i][1], op, que, LabAmp[i - 2][1])

        else:
            print('QRS波群关键点提取可能存在误检或漏检错误')
            que = []    #清空
            break

    return que



# if __name__ == '__main__':
#     # X = [0, 1, 2, 3, 4]
#     # Y = [1, 2, 5, 10, 17]
#     # fitting_curve(X , Y)
#     FSM_QRS(batch=1 , person = 9 , lead = 10 ,wave = 5)
