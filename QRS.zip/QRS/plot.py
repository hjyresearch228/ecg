import numpy as np
from numpy.linalg import  *
from common import *
from QRS_Classfiy import *
import ast
import math
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = ['SimHei']	# 显示中文
plt.rcParams['axes.unicode_minus'] = False		# 显示负号

#样本位置
data = r'data/generated_data/datas123/'
def plot_QRS(batch = 1 , person = 1 , lead = 0 , wave = 1):

    path = data + 'D{}_{}.npy'.format(batch , person)
    numpy_file = np.load(path, allow_pickle=True)[0]
    peaks = Calibration_Major_Wave(numpy_file) #所有导联的R波位置，第一个和最后一个不要
    R_index = peaks[lead][wave] #R波位置
    # print('R波位置：', R_index)

    ECG_SIGNER = numpy_file[lead]
    dec = wave_decom("Symmlets" + str(lead))
    clearSignal = dec.plot_I(ECG_SIGNER)  # 去噪
    clearSignal = baseline_lowpass(clearSignal)


    plt.title('D{}_{}_{}_{}波形'.format(batch , person, lead, wave))
    x = []
    y = []
    for i in range(peaks[lead][wave]-50, peaks[lead][wave]+50, 1):
        x.append(i)
        y.append(clearSignal[i])
    plt.plot(x, y)
    plt.show()
    y = np.asarray(y)

    # maxVal = find_extrema(y,mode="max")
    # print(maxVal)


# if __name__ == '__main__':
#     # plot_QRS(person = 20, lead = 1, wave = 2)
