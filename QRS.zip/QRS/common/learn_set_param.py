"""
learn_set_param.py用来学习阈值参数
"""

# 下列参数在getBaseFeatures.py中用
G_QRS_WIDTH = 0.12  # 正常的QRS波的最大宽度，大于这个值就是宽大畸形
G_YB_MIN_DIST = 1.15  # 逸搏的最小的比值
# 下列是本模块用的全局变量
# 下列是本模块用的全局变量
G_RPB_RATE_LIMIT = 0.9  # 计算完全性代偿间歇时，针对RR起点或PP起点的比值
G_RPPK_RATE_LIMIT = 0.9  # 计算完全性代偿间歇时，针对RR峰值或PP峰值的比值
G_COMPLETE_REMAINDER = 0.1  # 是否趋于1的残值

G_BEFORE_QRS_WITHOUT_P = 0.66  # without P before QRS

# 下列参数在extract_feature.py中用
G_MODEL_SHAPE_PART_THRD = 0.5  # 一个导联上大于1小于该值
G_MODEL_QRSWIDE = 0.8  # 在提前的QRS波中有多大比例是宽大畸形的，设这个参数是由于误差的原因导致的
G_MODEL_QRSP = 0.8  # 提前QRS前无P波
G_MODEL_QRSCOMPLETE = 0.6  # QRS波完全性代偿间歇，看多大比例的提前QRS波符合完全性代偿间歇
G_MODEL_PCOMPLETE = 0.8  # P波不完全性代偿间歇，看多少提前的P波满足


def set_all_paramters():
    set_norm_QRS_width()
    set_yb_min_dist()
    set_model_part_thrd()


def set_norm_QRS_width():
    global G_QRS_WIDTH
    G_QRS_WIDTH = 0.12


def set_yb_min_dist():
    global G_YB_MIN_DIST
    G_YB_MIN_DIST = 1.15


def set_model_part_thrd():
    global G_MODEL_SHAPE_PART_THRD
    G_MODEL_SHAPE_PART_THRD = 0.5
