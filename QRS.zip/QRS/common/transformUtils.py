from .tools import *


def lowPassDenoise(signal, frequency, sampleRate):
    """
    低通抑噪
    :param signal: 需要抑噪的信号
    :param frequency：可通过的最高频率
    :param sampleRate：取样率
    :return: 抑噪后的信号
    详见 testSignalExact
    """

    lowPassDenoise, sampling_rate, param = filter_signal(
        signal,
        'FIR',
        band='lowpass',
        order=int(0.3 * sampleRate),
        # frequency=10,    # 没有使用 frequency 这个参数
        frequency=frequency,
        sampling_rate=sampleRate
    )
    return lowPassDenoise


def bandPassDenoise(signal, frequencyL, frequencyH, sampleRate):
    """
    带通抑噪
    :param signal: 需要抑噪的信号
    :param frequencyL: 可通过的最低频率
    :param frequencyH：可通过的最高频率
    :param sampleRate：取样率
    :return: 抑噪后的信号
    详见 testSignalExact
    """

    bandPassDenoiseSignal, sampling_rate, param = filter_signal(
        signal,
        'FIR',
        band='bandpass',
        order=int(0.3 * sampleRate),
        frequency=[frequencyL, frequencyH],
        sampling_rate=sampleRate
    )
    return bandPassDenoiseSignal


def medianFiltBaseLine(signal, sampling_rate, windowSize):
    """
    中值基线提取
    :param signal: 需要基线提取的信号
    :param sampling_rate：取样率
    :param windowSize：窗口比例 建议 0.3~1 之间
    :return: 基线
    详见 testSignalExact
    """
    windowLen = int(sampling_rate * windowSize)
    baseLine, param = smoother(
        signal,
        size=windowLen
    )

    return baseLine


def lowpassAndMedianTransform(signal, sampling_rate):
    """
    信号预处理
    :param signal: 需要预处理的信号
    :param sampling_rate：取样率
    :return: 预处理的信号
    详见 testSignalExact
    """
    freq, power = welch_spectrum(
        signal,
        sampling_rate=sampling_rate
    )

    maxFreq = freq[np.argmax(power)]
    freqThereshold = maxFreq + 10

    lowPassDenoiseSignal = lowPassDenoise(
        signal,
        freqThereshold,
        sampling_rate
    )

    medianFiltBaseLineSignal = medianFiltBaseLine(
        signal,
        sampling_rate,
        0.8
    )

    exactedSignal = lowPassDenoiseSignal.copy()
    return exactedSignal - medianFiltBaseLineSignal
