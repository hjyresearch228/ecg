#-*- coding:utf-8 -*-
# Author: XiaoXiao
# @Time    :2019/5/3 15:20
# @Email   : xiaoxiao.tm@outlook.com
# @File    : translate.py
# @Software: PyCharm
import h5py
import numpy as np
import os
def translate(path=None,path_save=None):
    mats=[]
    names=[]
    # path = r'C:\Users\Sky\Desktop\Files\康尚1200个原始数据\康尚1200个原始数据'                         # 设置路径
    # path_save=r'C:\Users\Sky\Desktop\Git repository\ECG\npydatas'
    #path=path.encode('utf-8')
    dirs = os.listdir(path)
    for filename in dirs:
        if(os.path.splitext(filename)[1]=='.mat'):
            mats.append(filename)
            names.append(os.path.splitext(filename)[0])
    for fl,name in zip(mats,names):
        fl=path+'\\'+ fl
        name=path_save+'\\'+name+'.npy'
        ECG = []
        ECG_SIGNER = []
        mat = h5py.File(fl)
        ecgdata = mat['output']
        filename = ''.join(chr(v[0]) for v in ecgdata['filename'])
        sample = ecgdata['Sample'][0][0]
        FS = sample
        age=ecgdata['age'][0][0]
        diagnoisis=''
        for i in range(ecgdata['diagnosis'].shape[1]):
            diagnoisis = diagnoisis + ''.join(chr(v[0]) for v in ecgdata[ecgdata['diagnosis'][0][i]])
            diagnoisis=diagnoisis+''.join(chr(v[0]) for v in ecgdata[ecgdata['diagnosis'][1][i]])
        height=ecgdata['height'][0][0]
        sex=ecgdata['sex'][0][0]
        weight=ecgdata['weight'][0][0]
        utils={'filename':filename,'sample':sample,'age':age,'diagnoisis':diagnoisis,'height':height,'sex':sex,'weight':weight}
        #utils=[filename,sample,age,diagnoisis,height,sex,weight]
        ECG.append(ecgdata['ECG_I'][0])
        ECG.append(ecgdata['ECG_II'][0])
        ECG.append(ecgdata['ECG_III'][0])
        ECG.append(ecgdata['ECG_aVR'][0])
        ECG.append(ecgdata['ECG_aVF'][0])
        ECG.append(ecgdata['ECG_aVL'][0])
        ECG.append(ecgdata['ECG_V1'][0])
        ECG.append(ecgdata['ECG_V2'][0])
        ECG.append(ecgdata['ECG_V3'][0])
        ECG.append(ecgdata['ECG_V4'][0])
        ECG.append(ecgdata['ECG_V5'][0])
        ECG.append(ecgdata['ECG_V6'][0])
        datas=[]
        print(utils)
        datas.append(ECG)
        datas.append(utils)
        np.save(name,datas)
        print('save success'+'    '+name)


def translate2(path=None,path_save=None):
    mats=[]
    names=[]
    dirs = os.listdir(path)
    for filename in dirs:
        if(os.path.splitext(filename)[1]=='.mat'):
            mats.append(filename)
            names.append(os.path.splitext(filename)[0])
    for fl,name in zip(mats,names):
        fl=path+'\\'+ fl
        name=path_save+'\\'+name+'.npy'
        ECG = []
        ECG_SIGNER = []
        mat = h5py.File(fl)
        ecgdata = mat['output']
        filename = ''.join(chr(v[0]) for v in ecgdata['filename'])
        sample = ecgdata['Sample'][0][0]
        FS = sample
        age=ecgdata['age'][0]
        if age != 0:
            age = age[0]
        diagnoisis=''
        for i in range(ecgdata['diagnosis'].shape[1]):
            diagnoisis = diagnoisis + ''.join(chr(v[0]) for v in ecgdata[ecgdata['diagnosis'][0][i]])
            diagnoisis=diagnoisis+''.join(chr(v[0]) for v in ecgdata[ecgdata['diagnosis'][1][i]])
        height=ecgdata['height'][0]
        if height != 0:
            height = height[0]
        sex=ecgdata['sex'][0][0]
        weight=ecgdata['weight'][0]
        if isinstance(weight, np.ndarray) :
            weight = weight[0]

        utils={'filename':filename,'sample':sample,'age':age,'diagnoisis':diagnoisis,'height':height,'sex':sex,'weight':weight}
        for lead in ['ECG_I','ECG_II','ECG_III','ECG_aVR','ECG_aVF','ECG_aVL','ECG_V1','ECG_V2','ECG_V3','ECG_V4','ECG_V5','ECG_V6']:
            temp = np.array(ecgdata[lead])
            temp.shape = (1, 5000)
            ECG.append(temp[0])
        datas=[]
        print(utils)
        datas.append(ECG)
        datas.append(utils)
        np.save(name,datas)
        print('save success'+'    '+name)
