import numpy as np
import os

def translate(sourcePath=None, destPath=None):
    txts = []
    names = []
    dirList = os.listdir(sourcePath)
    num = 1
    for file in dirList:
        if(os.path.splitext(file)[1]=='.txt'):
            txts.append(file)
            names.append(num)
            num += 1
    for f1, name in zip(txts, names):
        fl1 = sourcePath + '\\' + f1
        name = destPath + '\\' + str(name) + '.npy'

        pos = []        # 12导联信息
        lastDic = {}    # 病症说明信息
        lists = []      # 12导联组成的列表
        results = []    # 最终结果

        with open(fl1, 'r') as file_to_read:
            while True:
                lines = file_to_read.readline()
                if not lines:
                    break
                p_tmp = [i for i in lines.split()]
                pos.append(p_tmp)

        last = pos[-1]
        ageIndex = last.index('age:')
        sexIndex = last.index('sex:')
        heightIndex = last.index('height:')
        weightIndex = last.index('weight:')
        SampleIndex = last.index('Sample:')
        diaIndex = last.index('diagnosis:')

        ageItems = ''
        sexItems = ''
        heightItems = ''
        weightItems = ''
        SampleItems = ''
        diaItems = ''

        #age
        for index in range(ageIndex + 1, ageIndex + 2):
            if last[index] == 'sex:':
                ageItems = None
            else:
                ageItems = last[index]

        #sex
        for index in range(sexIndex + 1, sexIndex + 2):
            if last[index] == 'height:':
                sexItems = None
            else:
                sexItems = last[index]

        #height
        for index in range(heightIndex + 1, heightIndex + 2):
            if last[index] == 'weight:':
                heightItems = None
            else:
                heightItems = last[index]

        #weight
        for index in range(weightIndex + 1, weightIndex + 2):
            if last[index] == 'Sample:':
                weightItems = None
            else:
                weightItems = last[index]

        for index in range(SampleIndex + 1, SampleIndex + 2):
            if last[index] == 'diagnosis:':
                SampleItems = None
            else:
                SampleItems = last[index]

        #diagnosis
        for index in range(diaIndex+1, len(last)):
            diaItems += last[index]

        lastDic['age'] = ageItems
        lastDic['sex'] = sexItems
        lastDic['height'] = heightItems
        lastDic['weight'] = weightItems
        lastDic['Sample'] = SampleItems
        lastDic['diagnoisis'] = diaItems


        pos = pos[:-1]
        for i in range(len(pos)):
            pos[i] = np.array(list(map(float, pos[i])))/204
            lists.append(pos[i])

        results.append(lists)
        results.append(lastDic)

        results = np.array(results)  # 将数据从list类型转换为array类型。
        np.save(name, results)
        print('save success: '+ name)

if __name__ == "__main__":
    #translate(r'D:\research\2019\kangshang\数据集\data_machine_labelled', r'G:\data_ks\data_npy')      #第一个参数为源数据路径，第二个参数为转换后数据保存路径
    a = np.load(r'G:\data_ks\data_npy\9.npy')
    print(a)