# -*- coding: utf-8 -*-
# Author: XiaoXiao
# @Time    :2019/4/23 18:01
# @Email   : xiaoxiao.tm@outlook.com
# @File    : dataset_model.py
# @Software: PyCharm


__doc__ = "此文档存放的信息为模型特征服务，必须与实际提取的模型特征中最高维度的特征一一对应"

# 水平取时间（s），纵向取mv
# 每个导联每一个心跳取一个
M_featureShape = {
    'Source_File': 'D_00001',
    'R': 0,
    'RS': 0,
    'QR': 0,
    'QRS': 0,
    'QRSR': 0,
    'RSRS': 0,
    'QS': 0,
    'RSR': 0,
    'R波分裂m型': False,
    # 'Q-R-S宽钝型': False,
    'P波双峰': False,
    '肺型P波': False,
    '切迹P波': False,
    'T波正常': False,
    'T波低平': False,
    '弓背型ST段': False,
    'Q波存在': False,
    '病理性Q波': False,
    'S波宽钝': False,
}

M_featureAmpl = {
    'Source_File': 'D_00001',
    'ST段下移或抬高': 0,  # 是一个数值，可正可负
    'T波幅度/QRS主波幅度': 0,
    'P波幅度': 0,
    'T波幅度': 0,
    'QRS波群幅度': 0,
    'ST斜度': 0
}

# 一个人取一个
M_featureElec = {
    'Source_File': 'D_00001',
    'RV5': 0,
    'RV6': 0,
    'RV5ANDSV1': 0,
    'RV1': 0,
    'RDIVSV1': 0,
    'RDIVSV5': 0,
    'RV1ANDSV5': 0,
    'RAVR': 0,
    '胸导电压': 0,  # 实际对应胸导低电压指标
    '肢导电压': 0,  # 对应肢导低电压指标
    '心室率': 0,  # 对应具体数值，根据QRS波算的
    '心房率': 0,  # 根据P波算的
    '心电轴': 0,
    'SEX': 1
}

# 12导联合并,对应的每一个心跳取一个
M_featureDistance = {
    'Source_File': 'D_00001',
    'R_P': 0,
    'RPE': 0,
    'RTB': 0,
    'RTE': 0,
    'PR段长度': 0,
    'PR间期': 0,
    'QRS波群宽度': 0,
    'R波宽度': 0,
    'QT间期': 0,
    'VAT间期': 0,
    'P波宽度': 0,
    'T波宽度': 0,
    'ST段时长': 0,
    'P/P-R': 0,
    'RR起点间期': 0,
    'RR起点间期比值': 0,
    'RR峰间期': 0,
    'RR峰间期比值': 0,
    'PP峰间期': 0,
    'PP峰间期比值': 0,
    'PP起点间期': 0,
    'PP起点间期比值': 0,

}

# 每个导联只取一个值
M_featureSequence = {
    'Source_File': 'D_00001',
    '提前的QRS前无P波': False,
    '提前的QRS波宽大畸形': False,
    'QRS波完全性代偿间歇': False,
    '二联律QRS波提前': False,
    '三联律QRS波提前': False,
    'P\'波不完全性代偿间歇': False,
    '10秒提前P波数目': False,
    '10秒提前的QRS波数目': False,
    '逸搏': False
}

M_featureDirection = {
    'Source_File': 'D_00001',
    '全部P波向下': False,
    '部分P波向下': False,
    '全部P波向上': False,
    '全部P波双向': False,
    '部分P波双向': False,
    '全部T波与主波方向相反': False,
    '部分T波与主波方向相反': False,
    '所有T波双向': False,
    '部分T波双向': False,
    '全部T波向上': False,
    '部分T波向上': False,
    '全部T波向下': False,
    '部分T波向下': False

}
