# Author:Json Zhang
# -*- coding: utf-8 -*-
# @Time    :2019/3/13 9:16
# @Email   : jsonzb@163.com
# @File    : preprocess.py
# @Software: PyCharm
import matplotlib.pyplot as plt
import pywt
import math
import numpy as np
import scipy.signal as signal


class wave_decom:
    w = 'bior4.4'
    title = ''
    # mode = pywt.Modes.smooth
    mode = pywt.Modes.periodic

    def __init__(self, title):
        self.title = title

    def sgn(self, num):
        if (num > 0.0):
            return 1.0
        elif (num == 0.0):
            return 0.0
        else:
            return -1.0

    def plot_I(self, data):
        """
        去噪
        :param data:
        :return: 去噪后的波形
        """
        appcoef = []
        detcoef = []
        w = pywt.Wavelet(self.w)
        w1 = pywt.Wavelet('bior4.4')
        a = data
        thcoeffs = []
        for i in range(9):
            (a, d) = pywt.dwt(a, self.w, pywt.Modes.smooth)  # 进行8阶离散小波变换
            appcoef.append(a)
            detcoef.append(d)
        for i in range(0, len(detcoef)):
            tmp = detcoef[i].copy()
            if (i >= 2):
                N = len(detcoef[i])
                sigma = (1.0 / 0.6745) * np.median(abs(tmp))
                TH = sigma * math.sqrt(2.0 * math.log(float(N), math.e))
            if (i >= 2 and i < 4):
                tmp = pywt.threshold(data=tmp, value=TH, mode='hard', substitute=0)
            thcoeffs.append(tmp)
        RA8 = pywt.idwt(appcoef[8], thcoeffs[8], w1)
        # RA7 = pywt.idwt(None, thcoeffs[7], w1)
        RA7 = pywt.idwt(RA8[range(0, len(thcoeffs[7]))], thcoeffs[7], w1)
        RA6 = pywt.idwt(RA7[range(0, len(thcoeffs[6]))], thcoeffs[6], w1)
        RA5 = pywt.idwt(RA6[range(0, len(thcoeffs[5]))], thcoeffs[5], w1)
        RA4 = pywt.idwt(RA5[range(0, len(thcoeffs[4]))], thcoeffs[4], w1)
        RA3 = pywt.idwt(RA4[range(0, len(thcoeffs[3]))], thcoeffs[3], w1)
        RA2 = pywt.idwt(RA3[range(0, len(thcoeffs[2]))], thcoeffs[2], w1)
        RA1 = pywt.idwt(RA2[range(0, len(thcoeffs[1]))], None, w1)
        rec = pywt.idwt(RA1[range(0, len(thcoeffs[0]))], None, w1)
        return rec

    def plot_II(self, data):
        appcoef = []
        detcoef = []
        w = pywt.Wavelet(self.w)
        w1 = pywt.Wavelet('bior5.5')
        a = data
        thcoeffs = []
        for i in range(10):
            (a, d) = pywt.dwt(a, w1, pywt.Modes.constant)  # 进行10阶离散小波变换
            appcoef.append(a)
            detcoef.append(d)
        for i in range(0, len(detcoef)):
            tmp = detcoef[i].copy()
            if (i >= 2):
                N = len(detcoef[i])
                sigma = (1.0 / 0.6745) * np.median(abs(tmp))
                TH = sigma * math.sqrt(2.0 * math.log(float(N), math.e))
            if (i >= 2 and i < 4):
                tmp = pywt.threshold(data=tmp, value=TH, mode='hard', substitute=0)
            thcoeffs.append(tmp)

        # RA9 = pywt.idwt(appcoef[9],None, w1)
        # RA8 = pywt.idwt(RA9[range(0, len(thcoeffs[8]))], None, w1)
        RA8 = pywt.idwt(appcoef[8], None, w1)
        RA7 = pywt.idwt(RA8[range(0, len(thcoeffs[7]))], None, w1)
        RA6 = pywt.idwt(RA7[range(0, len(thcoeffs[6]))], None, w1)
        RA5 = pywt.idwt(RA6[range(0, len(thcoeffs[5]))], None, w1)
        RA4 = pywt.idwt(RA5[range(0, len(thcoeffs[4]))], None, w1)
        RA3 = pywt.idwt(RA4[range(0, len(thcoeffs[3]))], None, w1)
        RA2 = pywt.idwt(RA3[range(0, len(thcoeffs[2]))], None, w1)
        RA1 = pywt.idwt(RA2[range(0, len(thcoeffs[1]))], None, w1)
        rec = pywt.idwt(RA1[range(0, len(thcoeffs[0]))], None, w1)
        return rec

    def plot_signal_decomp(self, data, order):
        """Decompose and plot a signal S.
        S = An + Dn + Dn-1 + ... + D1
        """
        w = pywt.Wavelet(self.w)  # 选取小波函数
        a = data
        ca = []  # 近似分量
        cd = []  # 细节分量
        for i in range(order):
            (a, d) = pywt.dwt(a, self.w, self.mode)  # 进行4阶离散小波变换
            ca.append(a)
        rec_a = []
        for i, coeff in enumerate(ca):
            coeff_list = [coeff, None] + [None] * i
            rec_a.append(pywt.waverec(coeff_list, w))  # 重构
        z = rec_a[order - 1]
        result = z
        return result.tolist()


def baseline_lowpass(data=None, sampling_rate=500):
    # 滤波器构造函数(仅介绍Butterworth滤波器)
    # 6: 滤波器的阶数
    # Wn: 归一化截止频率。计算公式 Wn=2*截止频率/采样频率
    # ‘lowpass’: 滤波器类型，即低通滤波
    Wn = (2 * 0.5) / sampling_rate
    b, a = signal.butter(6, Wn, 'lowpass')

    # 滤波函数
    # b: 滤波器的分子系数向量
    # a: 滤波器的分母系数向量
    # data: 要过滤的信号
    baseline = signal.filtfilt(b, a, data)

    return data - baseline
