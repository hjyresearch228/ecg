import pywt
import numpy as np
import math


def _waveletDetailDenoise(d):
    tmp = d.copy()
    N = len(tmp)
    sigma = (1.0 / 0.6745) * np.median(abs(tmp))
    TH = sigma * math.sqrt(2.0 * math.log(float(N), math.e))
    return pywt.threshold(data=tmp, value=TH, mode='hard', substitute=0)


def waveletTransform(signal, reconstructArg=[1, 0, 0, 0], waveName='bior4.4', mode=pywt.Modes.smooth, denoise=True):
    """
    :param signal: 需要小波分解和重构的信号
    :param reconstructArg: 各层小波细节分量重构中的占比，[N,N-1 ... 1 层]
    :param waveName: 使用的小波族名称
    :param mode: 分解模式
    :param denoise: 是否需要抑噪
    :return: 小波分解和重构之后的信号

    请看 testWaveTransform 中的调用示例
    """
    level = len(reconstructArg)
    waveletObj = pywt.Wavelet(waveName)
    coeffs = pywt.wavedec(signal, waveletObj, mode=mode, level=level)
    a, ds = coeffs[0], coeffs[1:]

    if denoise:
        ds = [_waveletDetailDenoise(d) for d in ds]

    for index, d in enumerate(ds):
        rate = reconstructArg[index]
        ds[index] = d * rate

    for d in ds:
        a = pywt.idwt(a[:len(d)], d, waveletObj, mode)

    return a
