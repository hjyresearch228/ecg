1、程序结构说明：

common文件夹：存放各种滤波去噪的工具类方法，如小波变换、低通高通滤波等。

data文件夹：心电原始数据，存储形式为npy文件，每个文件代表一个患者的12导联电压值。

result文件夹：标注的各种QRS波形数据的图片，其命名方式如D1_1_0_4.png图片对应D1_1.npy的第0导联的第4个QRS波形。

由于隐私问题和github上传容量受限，故只上传部分原始数据和图片。

 

2、程序运行说明：main.py为主程序入口，包含四个方法，分别为：

plot_QRS(batch, person, lead, wave)：绘制参数对应的波形。

FSM_QRS(batch, person, lead, wave)：中文对比实验，输出预测波形。
Morphological_Classification(batch, person, lead, wave)：英文对比实验，输出预测波形。
SWVHMM(batch, person, lead, wave)：输出本实验预测波形。

举例batch=1，person=1，lead=0，wave=4对应D1_1_0_4图片。