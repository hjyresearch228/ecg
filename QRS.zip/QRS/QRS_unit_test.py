from common import *
from QRS_Classfiy import *
import numpy as np
import time
import matplotlib.pyplot as plt
import os
plt.rcParams['font.sans-serif'] = ['SimHei']	# 显示中文
plt.rcParams['axes.unicode_minus'] = False		# 显示负号
plt.rcParams['font.size'] = 10


# str1表示数据文件路径，通过index修改对应数据文件
index=1

str1 = r'data/generated_data/datas123/D1_1.npy'
ECG_SIGNER = []
numpy_file = np.load(str1,allow_pickle=True)[0]   #list列表，12导联的ECG信号  allow_pickle:允许使用pickles保存对象数组，pickle 用于在保存到磁盘文件或从磁盘文件读取之前，对对象进行序列化和反序列化。
sampling_rate=float(500)
peaks=Calibration_Major_Wave(numpy_file)    #12导联的心拍位置索引
print('I导联心拍位置索引',peaks[0])

print('*'*80)
qrs_list_person = []

numpy_file = np.load(str1, allow_pickle=True)[0]

qrs_list = []
list1 = QRS_Classfiy_new(numpy_file)
print("list1:",list1)

list_temp = []  # 用于存储一个导联的所有数据
ECG_SIGNER = numpy_file[0]  # 0导联
ori_data = ECG_SIGNER
dec = wave_decom("Symmlets" + str(1))
clearSignal = dec.plot_I(ori_data)  # 去噪

# subplot一次显示多张图：subplot(numRows行数, numCols列数, plotNum索引值)
plt.subplot(3, 1, 1)
plt.title('原始波形')
plt.ylabel('电压(mv)')
plt.xlim(0,5000)
plt.plot(range(0, len(ori_data)), ori_data , 'k')  # 原波形


plt.subplot(3, 1, 2)
plt.title('去噪波形')
plt.ylabel('电压(mv)')
plt.xlim(0,5000)
plt.plot(range(0, len(clearSignal)), clearSignal , 'k')


plt.subplot(3, 1, 3)
plt.title('0.2秒QRS区域')
plt.ylabel('电压(mv)')
plt.xlim(700,800)
X = []
Y = []
for i in range(peaks[0][1]-51 , peaks[0][1]+50):
    X.append(i)
    Y.append(clearSignal[i])
plt.plot(X,Y , 'k')


plt.savefig('Fig1.svg')
plt.subplots_adjust(hspace=0.5)
plt.show()








